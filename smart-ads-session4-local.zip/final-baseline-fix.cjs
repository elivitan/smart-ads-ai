// final-baseline-fix.cjs
// Complete fix for PostgreSQL migration baseline
// 1. Ensures directUrl is in schema.prisma
// 2. Generates migration SQL
// 3. Creates _prisma_migrations table via SQL
// 4. Inserts baseline record
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

console.log("=== Final Baseline Fix ===\n");

// ─── Step 1: Fix schema.prisma ───
console.log("Step 1: Checking schema.prisma for directUrl...");
let schema = fs.readFileSync("schema.prisma", "utf8");
if (!schema.includes("directUrl")) {
  schema = schema.replace(
    'url      = env("DATABASE_URL")',
    'url      = env("DATABASE_URL")\n  directUrl = env("DIRECT_URL")'
  );
  fs.writeFileSync("schema.prisma", schema, "utf8");
  console.log("  Added directUrl to schema.prisma");
  
  // Regenerate client
  console.log("  Regenerating Prisma client...");
  execSync("npx prisma generate --schema schema.prisma", { stdio: "inherit" });
} else {
  console.log("  directUrl already present");
}

// ─── Step 2: Create migration directory ───
console.log("\nStep 2: Creating migration files...");
const MIGRATION_NAME = "20260305000000_init";
const migrDir = path.join("prisma", "migrations", MIGRATION_NAME);
const migrRoot = path.join("prisma", "migrations");

if (fs.existsSync(migrRoot)) {
  fs.rmSync(migrRoot, { recursive: true, force: true });
}
fs.mkdirSync(migrDir, { recursive: true });

// Lock file
fs.writeFileSync(
  path.join(migrRoot, "migration_lock.toml"),
  'provider = "postgresql"\n',
  "utf8"
);

// Generate SQL
const sql = execSync(
  "npx prisma migrate diff --from-empty --to-schema-datamodel schema.prisma --script",
  { encoding: "utf8", maxBuffer: 1024 * 1024 }
);
const cleanSql = sql.charCodeAt(0) === 0xFEFF ? sql.slice(1) : sql;
fs.writeFileSync(path.join(migrDir, "migration.sql"), cleanSql, "utf8");
console.log("  migration.sql written (" + cleanSql.length + " chars)");

// ─── Step 3: Create _prisma_migrations table + baseline record ───
console.log("\nStep 3: Creating _prisma_migrations table in database...");
const checksum = crypto.createHash("sha256").update(cleanSql).digest("hex");

const setupSql = `
CREATE TABLE IF NOT EXISTS "_prisma_migrations" (
    "id"                    VARCHAR(36)  NOT NULL PRIMARY KEY,
    "checksum"              VARCHAR(64)  NOT NULL,
    "finished_at"           TIMESTAMPTZ,
    "migration_name"        VARCHAR(255) NOT NULL,
    "logs"                  TEXT,
    "rolled_back_at"        TIMESTAMPTZ,
    "started_at"            TIMESTAMPTZ  NOT NULL DEFAULT now(),
    "applied_steps_count"   INTEGER      NOT NULL DEFAULT 0
);

DELETE FROM "_prisma_migrations" WHERE "migration_name" = '${MIGRATION_NAME}';

INSERT INTO "_prisma_migrations" ("id", "checksum", "migration_name", "finished_at", "applied_steps_count", "started_at")
VALUES ('${crypto.randomUUID()}', '${checksum}', '${MIGRATION_NAME}', NOW(), 1, NOW());
`;

const tmpFile = path.join("prisma", "_tmp_setup.sql");
fs.writeFileSync(tmpFile, setupSql, "utf8");

try {
  execSync(
    'npx prisma db execute --file "' + tmpFile + '" --schema schema.prisma',
    { encoding: "utf8", stdio: "inherit" }
  );
  console.log("  _prisma_migrations table created and baseline inserted!");
} catch (err) {
  console.error("  ERROR:", err.message);
  console.log("\n  The SQL file is at:", tmpFile);
  console.log("  You can run it manually in Supabase SQL Editor:");
  console.log("  Go to https://supabase.com → SQL Editor → paste contents of " + tmpFile);
  process.exit(1);
}

// Cleanup
fs.unlinkSync(tmpFile);

// ─── Step 4: Verify ───
console.log("\nStep 4: Verifying...");
try {
  const status = execSync("npx prisma migrate status --schema schema.prisma", {
    encoding: "utf8",
  });
  console.log(status);
} catch (err) {
  // migrate status sometimes exits with error even when OK
  const out = (err.stdout || "") + (err.stderr || "");
  if (out.includes("applied") || out.includes("Database schema is up to date")) {
    console.log("  Migration status: OK");
  } else {
    console.log("  Status output:", out.slice(0, 300));
  }
}

console.log("\n=== DONE! Now run: npm run dev ===");
