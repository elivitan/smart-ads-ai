const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "app", "routes", "app._index.jsx");
let c = fs.readFileSync(file, "utf8");

const old = 'window.location.href = "/app";';
const fix = 'var url = new URL(window.location.href); url.searchParams.delete("preview"); window.location.href = url.toString();';

if (c.includes(old)) {
  c = c.replace(old, fix);
  fs.writeFileSync(file, c, "utf8");
  console.log("✅ Fixed onComplete — removes ?preview param and reloads");
} else {
  console.log("⚠️  Pattern not found — already fixed or changed");
}
