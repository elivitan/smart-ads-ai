import { useState, useEffect, useRef, useCallback } from "react";

/**
 * useCampaigns — Server is the source of truth for campaignId.
 *
 * campaignId: fetched from /app/api/campaign-manage on mount.
 *             sessionStorage = fast-start cache only.
 * All other state (status, control) is ephemeral per-session.
 */

const DEFAULT_DAILY_BUDGET = "10"; // Conservative default — user should configure this

export function useCampaigns({ canPublish, triggerConfetti, onUpgradeNeeded, refreshCredits }) {

  // ── Campaign ID — server authoritative ────────────────────────────────────
  // FIX: initialize with null, never with a fake fallback like "sim_001"
  const [campaignId, setCampaignIdRaw] = useState(() => {
    try { return sessionStorage.getItem("sai_campaign_id") || null; } catch { return null; }
  });

  const campaignFetchedRef = useRef(false);

  // On mount: fetch real campaignId from server
  useEffect(() => {
    if (campaignFetchedRef.current) return;
    campaignFetchedRef.current = true;
    (async () => {
      try {
        const form = new FormData();
        form.append("action", "list");
        const res  = await fetch("/app/api/campaign-manage", { method: "POST", body: form });
        const data = await res.json();
        if (data.campaigns?.length > 0) {
          const latest = data.campaigns[0];
          const id = latest.resourceName || String(latest.id) || null;
          if (id) {
            setCampaignIdRaw(id);
            try { sessionStorage.setItem("sai_campaign_id", id); } catch {}
          }
        }
      } catch {
        // Keep cached value — no crash
      }
    })();
  }, []);

  function setCampaignId(id) {
    setCampaignIdRaw(id);
    try {
      if (id) sessionStorage.setItem("sai_campaign_id", id);
      else    sessionStorage.removeItem("sai_campaign_id");
    } catch {}
  }

  // ── Ephemeral state ───────────────────────────────────────────────────────
  const [campaignStatus,        setCampaignStatus]        = useState(null);
  const [campaignControlStatus, setCampaignControlStatus] = useState(null);
  const [realSpend,             setRealSpend]             = useState(null);
  const [confirmRemove,         setConfirmRemove]         = useState(false);
  const [autoLaunching,         setAutoLaunching]         = useState(false);
  const [autoStatus,            setAutoStatus]            = useState(null);
  const [showLaunchChoice,      setShowLaunchChoice]      = useState(false);
  const [googleConnected,       setGoogleConnected]       = useState(false);

  // ── Poll real spend every 60s — with AbortController ─────────────────────
  useEffect(() => {
    if (!campaignId) return;

    // FIX: use AbortController to cancel in-flight requests on cleanup
    const controller = new AbortController();
    let intervalId = null;

    async function fetchSpend() {
      try {
        const form = new FormData();
        form.append("action", "list");
        const res  = await fetch("/app/api/campaign-manage", {
          method: "POST",
          body:   form,
          signal: controller.signal,
        });
        // Stop polling on 401 — session expired, no point retrying
        if (res.status === 401) {
          if (intervalId) clearInterval(intervalId);
          console.warn("[SmartAds] Session expired — stopping spend polling");
          return;
        }
        const data = await res.json();
        if (data.campaigns) {
          const numId = String(campaignId).split("/").pop() || String(campaignId);
          const camp  = data.campaigns.find(
            c => String(c.id) === numId || c.resourceName === campaignId
          );
          if (camp) setRealSpend(parseFloat(camp.cost || 0) || 0);
        }
      } catch (err) {
        if (err.name === "AbortError") return; // expected on cleanup
        console.error("[SmartAds]", err);
      }
    }

    fetchSpend();
    intervalId = setInterval(fetchSpend, 60000);
    return () => { controller.abort(); if (intervalId) clearInterval(intervalId); };
  }, [campaignId]);

  // ── Campaign actions ──────────────────────────────────────────────────────
  const handleCreateCampaign = useCallback(async (product, aiData, finalUrl, dailyBudget) => {
    if (!canPublish) { onUpgradeNeeded?.(); return; }
    setCampaignStatus("creating");
    try {
      const form = new FormData();
      form.append("productTitle",  product.title);
      form.append("headlines",     JSON.stringify(aiData.headlines    || []));
      form.append("descriptions",  JSON.stringify(aiData.descriptions || []));
      form.append("keywords",      JSON.stringify(aiData.keywords     || []));
      form.append("finalUrl",      finalUrl);
      // FIX: use passed budget or fall back to conservative default
      form.append("dailyBudget",   dailyBudget ?? DEFAULT_DAILY_BUDGET);
      const res  = await fetch("/app/api/campaign", { method: "POST", body: form });
      const data = await res.json();
      if (data.success) {
        setCampaignStatus("success");
        setTimeout(() => setCampaignStatus(null), 3000);
        const cid = data.campaignId || data.campaign_id || data.resourceName || null;
        if (cid) setCampaignId(cid);
        refreshCredits?.(); // sync credit balance after campaign creation
      } else {
        setCampaignStatus("error");
        setTimeout(() => setCampaignStatus(null), 3000);
      }
    } catch (err) { console.error("[SmartAds] handleCreateCampaign:", err); setCampaignStatus("error"); setTimeout(() => setCampaignStatus(null), 3000); }
  }, [canPublish, onUpgradeNeeded, refreshCredits]);

  const handleAutoCampaign = useCallback(async (products, getUrl, dailyBudget) => {
    if (!canPublish) { onUpgradeNeeded?.(); return; }
    setAutoLaunching(true);
    let successCount = 0;
    for (const prod of products) {
      const ai = prod.aiAnalysis || {};
      try {
        const form = new FormData();
        form.append("productTitle",  prod.title);
        form.append("headlines",     JSON.stringify(ai.headlines    || []));
        form.append("descriptions",  JSON.stringify(ai.descriptions || []));
        form.append("keywords",      JSON.stringify(ai.keywords     || []));
        form.append("finalUrl",      getUrl(prod));
        // FIX: use passed budget or fall back to conservative default
        form.append("dailyBudget",   dailyBudget ?? DEFAULT_DAILY_BUDGET);
        const res  = await fetch("/app/api/campaign", { method: "POST", body: form });
        const data = await res.json();
        if (data.success) successCount++;
      } catch (err) { console.error("[SmartAds]", err); }
    }
    setAutoLaunching(false);
    setAutoStatus(successCount > 0 ? "success" : "error");
    setTimeout(() => setAutoStatus(null), 3000);
    if (successCount > 0) {
      triggerConfetti?.();
      refreshCredits?.(); // sync credit balance after campaigns created
    }
  }, [canPublish, onUpgradeNeeded, triggerConfetti, refreshCredits]);

  const handlePauseCampaign = useCallback(async () => {
    if (!campaignId) return;
    setCampaignControlStatus("pausing");
    try {
      const form = new FormData();
      form.append("action",     "pause");
      form.append("campaignId", campaignId);
      const res  = await fetch("/app/api/campaign-manage", { method: "POST", body: form });
      const data = await res.json();
      setCampaignControlStatus(data.success ? "paused" : "error");
      if (!data.success) setTimeout(() => setCampaignControlStatus(null), 3000);
    } catch (err) { console.error("[SmartAds] handlePauseCampaign:", err); setCampaignControlStatus("error"); setTimeout(() => setCampaignControlStatus(null), 3000); }
  }, [campaignId]);

  const handleRemoveCampaign = useCallback(async () => {
    if (!campaignId) return;
    setCampaignControlStatus("removing");
    setConfirmRemove(false);
    try {
      const form = new FormData();
      form.append("action",     "remove");
      form.append("campaignId", campaignId);
      const res  = await fetch("/app/api/campaign-manage", { method: "POST", body: form });
      const data = await res.json();
      if (data.success) {
        setCampaignControlStatus("removed");
        setCampaignId(null);
      } else {
        setCampaignControlStatus("error");
        setTimeout(() => setCampaignControlStatus(null), 3000);
      }
    } catch (err) { console.error("[SmartAds] handleRemoveCampaign:", err); setCampaignControlStatus("error"); setTimeout(() => setCampaignControlStatus(null), 3000); }
  }, [campaignId]);

  return {
    campaignId,
    campaignStatus,
    campaignControlStatus,
    realSpend,
    confirmRemove,
    autoLaunching,
    autoStatus,
    showLaunchChoice,
    googleConnected,
    setCampaignId,
    setCampaignStatus,
    setCampaignControlStatus,
    setConfirmRemove,
    setAutoStatus,
    setAutoLaunching,
    setShowLaunchChoice,
    setGoogleConnected,
    handleCreateCampaign,
    handleAutoCampaign,
    handlePauseCampaign,
    handleRemoveCampaign,
  };
}
