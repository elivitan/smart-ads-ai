/**
 * Session 4 — Deploy CollectingDataScreen.jsx
 * 
 * Replaces the old CollectingDataScreen (no autoStart, no pause/cancel)
 * with the fixed version that includes:
 * - autoStart mode: batch analysis loop via /app/api/sync
 * - Pause / Resume / Cancel buttons with confirm dialogs
 * - Real progress tracking (analyzed/total from server)
 * - onComplete callback to reload dashboard when done
 */

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const FIXED = path.join(ROOT, "CollectingDataScreen.fixed.jsx");
const TARGET = path.join(ROOT, "app", "routes", "CollectingDataScreen.jsx");

console.log("═══════════════════════════════════════════");
console.log("  Deploy CollectingDataScreen.jsx");
console.log("═══════════════════════════════════════════\n");

if (!fs.existsSync(FIXED)) {
  console.log("❌ CollectingDataScreen.fixed.jsx not found next to this script!");
  process.exit(1);
}

// Read and convert to Windows line endings
let content = fs.readFileSync(FIXED, "utf8");
content = content.replace(/\r\n/g, "\n").replace(/\n/g, "\r\n");

fs.writeFileSync(TARGET, content, "utf8");
console.log("✅ app/routes/CollectingDataScreen.jsx replaced\n");

// Verify
const final = fs.readFileSync(TARGET, "utf8");
const checks = [
  ["autoStart prop", final.includes("autoStart")],
  ["handlePause", final.includes("handlePause")],
  ["handleResume", final.includes("handleResume")],
  ["handleCancel", final.includes("handleCancel")],
  ["Pause button", final.includes("Pause")],
  ["Resume button", final.includes("Resume")],
  ["analyze_batch loop", final.includes("analyze_batch")],
  ["onComplete callback", final.includes("onComplete")],
  ["pausedRef", final.includes("pausedRef")],
];

let ok = true;
for (const [label, pass] of checks) {
  console.log(`  ${label}: ${pass ? "✅" : "❌"}`);
  if (!pass) ok = false;
}

console.log(`\n${ok ? "✅ All checks passed!" : "⚠️ Some checks failed!"}`);
