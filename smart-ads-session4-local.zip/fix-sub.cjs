const fs = require("fs");
const f = "app/routes/app.api.subscription.js";
let c = fs.readFileSync(f, "utf8");
let fixed = c.replace(
  /export const loader = async \(\{ request \}\) => \{\s*\n\s*const \{ authenticate \}/,
  "export const loader = async ({ request }) => { const { authenticate }"
);
if (fixed !== c) {
  fs.writeFileSync(f, fixed);
  console.log("FIXED!");
} else {
  console.log("Pattern not found. Showing loader:");
  let i = c.indexOf("export const loader");
  console.log(JSON.stringify(c.substring(i, i+200)));
}
