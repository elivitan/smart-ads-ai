const fs = require("fs");
const f = "app/routes/app._index.jsx";
let c = fs.readFileSync(f, "utf8");
c = c.replace(
  /cookie\.match\(\/sai_plan=\(\[\^;\n\]\+\)\/\)/,
  'cookie.match(/sai_plan=([^;]+)/)'
);
fs.writeFileSync(f, c);
console.log("Fixed regex!");
