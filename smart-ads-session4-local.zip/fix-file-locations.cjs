const fs = require("fs");
const path = require("path");

// Files to move from routes/ to components/
const filesToMove = [
  "AdPreviewPanel.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "SmallComponents.jsx",
  "styles.index.js",
];

const routesDir = "app/routes";
const componentsDir = "app/components";

// Move files
let moved = 0;
for (const file of filesToMove) {
  const src = path.join(routesDir, file);
  const dst = path.join(componentsDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, dst);
    fs.unlinkSync(src);
    moved++;
    console.log("MOVED: " + file + " -> components/");
  } else {
    console.log("SKIP: " + file + " (not found in routes/)");
  }
}

// Update imports in app._index.jsx
const indexPath = path.join(routesDir, "app._index.jsx");
let code = fs.readFileSync(indexPath, "utf-8");

// Replace "./" imports to "../components/" for the moved files
const importMap = {
  './styles.index.js': '../components/styles.index.js',
  './SmallComponents.jsx': '../components/SmallComponents.jsx',
  './CollectingDataScreen.jsx': '../components/CollectingDataScreen.jsx',
  './AdPreviewPanel.jsx': '../components/AdPreviewPanel.jsx',
  './CompetitorComponents.jsx': '../components/CompetitorComponents.jsx',
  './DashboardWidgets.jsx': '../components/DashboardWidgets.jsx',
  './LandingComponents.jsx': '../components/LandingComponents.jsx',
  './ProductModal.jsx': '../components/ProductModal.jsx',
};

let fixes = 0;
for (const [old, newPath] of Object.entries(importMap)) {
  if (code.includes(old)) {
    code = code.replace(new RegExp(old.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), newPath);
    fixes++;
    console.log("IMPORT FIX: " + old + " -> " + newPath);
  }
}

// Also check if ProductModal.jsx should be in routes or components
const pmInRoutes = path.join(routesDir, "ProductModal.jsx");
const pmInComponents = path.join(componentsDir, "ProductModal.jsx");
if (fs.existsSync(pmInRoutes) && fs.existsSync(pmInComponents)) {
  // Both exist - remove from routes
  fs.unlinkSync(pmInRoutes);
  console.log("REMOVED duplicate: routes/ProductModal.jsx (keeping components/)");
} else if (fs.existsSync(pmInRoutes)) {
  fs.copyFileSync(pmInRoutes, pmInComponents);
  fs.unlinkSync(pmInRoutes);
  console.log("MOVED: ProductModal.jsx -> components/");
}

fs.writeFileSync(indexPath, code, "utf-8");
console.log("\nTotal files moved: " + moved);
console.log("Total imports fixed: " + fixes);
console.log("DONE!");
