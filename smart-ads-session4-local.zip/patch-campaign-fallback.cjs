/**
 * Patch: campaign-manage API fallback to simulated mode
 * 
 * When Google Ads API call fails (e.g. TEST MODE token), 
 * fall back to simulated data instead of returning an error.
 */

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const FILE = path.join(ROOT, "app", "routes", "app.api.campaign-manage.js");

console.log("═══════════════════════════════════════════");
console.log("  Patch: Campaign API fallback");
console.log("═══════════════════════════════════════════\n");

let content = fs.readFileSync(FILE, "utf8");

const OLD = `  } catch (error) {
    console.error("Campaign management error:", error);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }`;

const NEW = `  } catch (error) {
    console.error("Campaign management error (falling back to simulated):", error.message);
    // Fallback to simulated mode when Google Ads API fails (e.g. TEST MODE token)
    return Response.json(getSimulatedResponse(action, formData));
  }`;

if (content.includes(OLD)) {
  content = content.replace(OLD, NEW);
  fs.writeFileSync(FILE, content, "utf8");
  console.log("✅ Added fallback to simulated mode on API error");
} else if (content.includes("falling back to simulated")) {
  console.log("⏭️  Already patched");
} else {
  console.log("⚠️  Pattern not found — check file manually");
}

// Verify
const final = fs.readFileSync(FILE, "utf8");
console.log("\n🔍 Verifying...");
console.log("  Fallback on error:", final.includes("falling back to simulated") ? "✅" : "❌");
console.log("  getSimulatedResponse in catch:", final.includes("getSimulatedResponse(action, formData)") ? "✅" : "❌");
