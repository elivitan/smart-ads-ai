/**
 * install-market-intel.cjs
 * ════════════════════════
 * Patches app._index.jsx to:
 * 1. Add MarketAlert import
 * 2. Add MarketAlert widget in dashboard (after status row)
 * 3. Add market intel to handleAutoCampaign budget decisions
 *
 * New files (already created, just need to be in place):
 * - app/market-intel.server.js
 * - app/routes/app.api.market-intel.js
 * - app/routes/MarketAlert.jsx
 *
 * Run: node install-market-intel.cjs
 */

const fs = require("fs");
const path = require("path");

const INDEX = path.join(__dirname, "app", "routes", "app._index.jsx");

// Read and normalize
const raw = fs.readFileSync(INDEX, "utf-8");
let src = raw.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
const hadCRLF = raw.includes("\r\n");

let changes = 0;
let errors = 0;

function safeReplace(label, find, replace) {
  if (!src.includes(find)) {
    console.error(`  ✗ ${label}: pattern NOT FOUND`);
    errors++;
    return;
  }
  src = src.replace(find, replace);
  changes++;
  console.log(`  ✓ ${label}`);
}

// ═══════════════════════════════════════════════════
// PATCH 1: Add import for MarketAlert
// ═══════════════════════════════════════════════════
console.log("\n[1/3] Adding MarketAlert import...");

const importAnchor = `import { ProductModal } from "./ProductModal.jsx";`;
const importAdd = `import { ProductModal } from "./ProductModal.jsx";
import { MarketAlert } from "./MarketAlert.jsx";`;

if (src.includes("MarketAlert")) {
  console.log("  ⚠ MarketAlert already imported — skipping");
} else {
  safeReplace("Add MarketAlert import", importAnchor, importAdd);
}

// ═══════════════════════════════════════════════════
// PATCH 2: Add MarketAlert widget in dashboard
// Place it right after the status row, before competitor panel
// ═══════════════════════════════════════════════════
console.log("\n[2/3] Adding MarketAlert widget to dashboard...");

const dashboardAnchor = `          {/* COMPETITOR PANEL */}`;
const dashboardAdd = `          {/* MARKET INTELLIGENCE */}
          <MarketAlert shopDomain={shopDomain}/>

          {/* COMPETITOR PANEL */}`;

if (src.includes("<MarketAlert")) {
  console.log("  ⚠ MarketAlert widget already in dashboard — skipping");
} else {
  safeReplace("Add MarketAlert widget", dashboardAnchor, dashboardAdd);
}

// ═══════════════════════════════════════════════════
// PATCH 3: Add marketIntel state + fetch for use in auto campaigns
// We add a simple state that stores the latest market signal
// and use its budget_multiplier in auto campaign decisions
// ═══════════════════════════════════════════════════
console.log("\n[3/3] Adding market intel state for auto campaigns...");

// Add state variable right before the "ALL HOOKS MUST BE CALLED HERE" comment
const hooksAnchor = `  // ⚠️ ALL HOOKS MUST BE CALLED HERE — before any early returns`;

if (src.includes("marketIntel")) {
  console.log("  ⚠ marketIntel state already exists — skipping");
} else {
  const hooksAdd = `  // Market Intelligence — cached signal for auto campaign budget adjustments
  const [marketIntel, setMarketIntel] = useState(null);
  useEffect(() => {
    async function fetchMarketSignal() {
      try {
        const form = new FormData();
        form.append("mode", "quick");
        form.append("regions", "US");
        const res = await fetch("/app/api/market-intel", { method: "POST", body: form });
        if (!res.ok) return;
        const data = await res.json();
        if (data.success) setMarketIntel(data.intel);
      } catch {}
    }
    fetchMarketSignal();
  }, []);

  // ⚠️ ALL HOOKS MUST BE CALLED HERE — before any early returns`;

  safeReplace("Add marketIntel state + fetch hook", hooksAnchor, hooksAdd);

  // Now patch handleAutoCampaign to use marketIntel.budget_multiplier
  const budgetLine = `      let autoBudget = "50", autoCampaignType = "search", autoBidding = "max_conversions";
      if (cStrategy.includes("defensive") || (cPosition && cPosition <= 5)) {
        autoBudget = "30"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else if (cStrategy.includes("moderate") || (cPosition && cPosition <= 20)) {
        autoBudget = "50"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else {
        autoBudget = "70"; autoCampaignType = "pmax"; autoBidding = "max_clicks";
      }`;

  const budgetWithIntel = `      let autoBudget = "50", autoCampaignType = "search", autoBidding = "max_conversions";
      if (cStrategy.includes("defensive") || (cPosition && cPosition <= 5)) {
        autoBudget = "30"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else if (cStrategy.includes("moderate") || (cPosition && cPosition <= 20)) {
        autoBudget = "50"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else {
        autoBudget = "70"; autoCampaignType = "pmax"; autoBidding = "max_clicks";
      }
      // Apply market intelligence budget multiplier
      if (marketIntel?.budget_multiplier) {
        autoBudget = String(Math.round(Number(autoBudget) * marketIntel.budget_multiplier));
      }
      // If market signal is red, force pause strategy
      if (marketIntel?.signal === "red") {
        autoBudget = "10"; autoCampaignType = "search"; autoBidding = "max_conversions";
      }`;

  // This pattern appears twice (doScan + handleAutoCampaign), replace both
  const budgetCount = src.split(budgetLine).length - 1;
  if (budgetCount >= 2) {
    src = src.split(budgetLine).join(budgetWithIntel);
    changes++;
    console.log(`  ✓ Added market intel budget adjustment (${budgetCount} locations)`);
  } else if (budgetCount === 1) {
    src = src.replace(budgetLine, budgetWithIntel);
    changes++;
    console.log("  ✓ Added market intel budget adjustment (1 location)");
  } else {
    console.error("  ✗ Strategy budget block not found — was fix-ranking-and-strategy.cjs applied?");
    errors++;
  }
}

// ═══════════════════════════════════════════════════
// WRITE
// ═══════════════════════════════════════════════════
console.log("\n" + "═".repeat(44));
if (changes > 0) {
  const output = hadCRLF ? src.replace(/\n/g, "\r\n") : src;
  fs.writeFileSync(INDEX, output);
  console.log(`✅ ${changes} patches applied successfully.`);
  if (errors > 0) console.log(`⚠  ${errors} patterns not found.`);
  console.log("Files updated:");
  console.log("  - app/routes/app._index.jsx");
  console.log("\nNew files (copy these to your project):");
  console.log("  - app/market-intel.server.js");
  console.log("  - app/routes/app.api.market-intel.js");
  console.log("  - app/routes/MarketAlert.jsx");
} else {
  console.log("⚠ No changes made.");
}
console.log("═".repeat(44));
console.log("\nDon't forget to add to .env:");
console.log("  NEWSAPI_KEY=your_key_here");
console.log("\nnpm run validate");
console.log("npm run dev\n");
