// baseline-migration.cjs
// Creates a baseline migration and marks it as applied in the database
// This fixes the P3005 "database schema is not empty" error
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const MIGRATION_NAME = "20260305000000_init";
const migrDir = path.join("prisma", "migrations", MIGRATION_NAME);
const lockFile = path.join("prisma", "migrations", "migration_lock.toml");

console.log("=== Baseline Migration Setup ===\n");

// Step 1: Clean up
console.log("Step 1: Cleaning old migrations...");
const migrRoot = path.join("prisma", "migrations");
if (fs.existsSync(migrRoot)) {
  fs.rmSync(migrRoot, { recursive: true, force: true });
}
fs.mkdirSync(migrDir, { recursive: true });
console.log("  Created:", migrDir);

// Step 2: Write lock file
console.log("\nStep 2: Writing migration_lock.toml...");
fs.writeFileSync(lockFile, 'provider = "postgresql"\n', "utf8");
console.log("  Done");

// Step 3: Generate migration SQL
console.log("\nStep 3: Generating migration SQL...");
try {
  const sql = execSync(
    "npx prisma migrate diff --from-empty --to-schema-datamodel schema.prisma --script",
    { encoding: "utf8", maxBuffer: 1024 * 1024 }
  );
  
  // Remove BOM if present
  const cleanSql = sql.charCodeAt(0) === 0xFEFF ? sql.slice(1) : sql;
  
  const sqlFile = path.join(migrDir, "migration.sql");
  fs.writeFileSync(sqlFile, cleanSql, "utf8");
  console.log("  Written:", sqlFile, "(" + cleanSql.length + " chars)");
  
  // Verify encoding
  const buf = fs.readFileSync(sqlFile);
  console.log("  First bytes:", buf[0].toString(16), buf[1].toString(16), buf[2].toString(16));
  if (buf[0] === 0xFF || buf[0] === 0xFE) {
    console.log("  WARNING: File appears to be UTF-16! Fixing...");
    const text = buf.toString("utf16le");
    fs.writeFileSync(sqlFile, text, "utf8");
    console.log("  Re-written as UTF-8");
  } else {
    console.log("  Encoding: UTF-8 (good)");
  }
} catch (err) {
  console.error("  ERROR generating SQL:", err.message);
  process.exit(1);
}

// Step 4: Mark as applied
console.log("\nStep 4: Marking migration as applied...");
try {
  const result = execSync(
    "npx prisma migrate resolve --applied " + MIGRATION_NAME + " --schema schema.prisma",
    { encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] }
  );
  console.log("  " + result.trim());
  console.log("\n=== SUCCESS! Migration baseline created ===");
  console.log("\nNow run: npm run dev");
} catch (err) {
  const stderr = err.stderr || err.message;
  console.error("  ERROR:", stderr);
  
  // If resolve fails, try alternative approach
  console.log("\n  Trying alternative: direct DB insert...");
  try {
    const insertSql = `INSERT INTO "_prisma_migrations" (id, checksum, migration_name, finished_at, applied_steps_count) VALUES ('baseline-001', 'baseline', '${MIGRATION_NAME}', NOW(), 1) ON CONFLICT DO NOTHING;`;
    const tmpFile = path.join("prisma", "_tmp_baseline.sql");
    fs.writeFileSync(tmpFile, insertSql, "utf8");
    
    const result2 = execSync(
      'npx prisma db execute --file "' + tmpFile + '" --schema schema.prisma',
      { encoding: "utf8", stdio: ["pipe", "pipe", "pipe"] }
    );
    console.log("  " + (result2.trim() || "Done"));
    fs.unlinkSync(tmpFile);
    console.log("\n=== SUCCESS (alternative)! Migration baseline created ===");
    console.log("\nNow run: npm run dev");
  } catch (err2) {
    console.error("  Alternative also failed:", err2.stderr || err2.message);
    console.log("\n  Last resort: trying prisma migrate deploy directly...");
    try {
      execSync("npx prisma migrate deploy --schema schema.prisma", { 
        encoding: "utf8", 
        stdio: "inherit" 
      });
    } catch (err3) {
      console.error("\n  All methods failed. The migration files may have encoding issues.");
      console.error("  Try opening prisma/migrations/20260305000000_init/migration.sql");
      console.error("  in VS Code and saving as UTF-8 encoding manually.");
    }
  }
}
