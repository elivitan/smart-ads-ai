const fs=require("fs"),path=require("path"),ROOT=process.cwd();
const env=fs.readFileSync(path.join(ROOT,".env"),"utf-8");
const req=["SHOPIFY_API_KEY","SHOPIFY_API_SECRET","ANTHROPIC_API_KEY"];
const opt=["GOOGLE_ADS_CLIENT_ID","GOOGLE_ADS_CLIENT_SECRET","GOOGLE_ADS_DEVELOPER_TOKEN","GOOGLE_ADS_CUSTOMER_ID","GOOGLE_ADS_REFRESH_TOKEN","SERPAPI_KEY"];
let m=0;
console.log("Env Check:");
req.forEach(k=>{if(env.includes(k+"=")&&!env.match(new RegExp(k+'=\\s*$','m'))){console.log("  OK: "+k)}else{console.log("  MISSING: "+k);m++}});
opt.forEach(k=>{if(env.includes(k+"=")){console.log("  OK: "+k)}else{console.log("  optional: "+k)}});
console.log(m>0?"\nMISSING "+m+" required keys!":"\nAll required keys present");
