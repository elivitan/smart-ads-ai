// fix-setup-script.cjs
// Changes the "setup" script in package.json from "prisma migrate deploy"
// to "prisma db push" which works without migration history
const fs = require("fs");

const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));

const oldSetup = pkg.scripts.setup;
console.log("Current setup script:", oldSetup);

pkg.scripts.setup = "prisma generate && prisma db push --accept-data-loss";
console.log("New setup script:", pkg.scripts.setup);

fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2) + "\n", "utf8");
console.log("Done — package.json updated");
