/**
 * Fix onboarding flow:
 * 1. selectPlan -> auto-scan (add back setOnboardingPhase scanning)
 * 2. Remove onLaunchChoice from OnboardModal (no launch choice popup)
 * 3. onComplete -> setOnboardingPhase(null) + reload (no /app redirect)
 */

const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "app", "routes", "app._index.jsx");
let c = fs.readFileSync(file, "utf8");
let fixes = 0;

// Fix 1: selectPlan should trigger scanning after plan saved
// Look for the current state (with or without scanning)
if (c.includes('}).then(() => {\r\n      setShowOnboard(false);\r\n    }).catch(() => {\r\n      setShowOnboard(false);\r\n    });')) {
  c = c.replace(
    '}).then(() => {\r\n      setShowOnboard(false);\r\n    }).catch(() => {\r\n      setShowOnboard(false);\r\n    });',
    '}).then(() => {\r\n      setShowOnboard(false);\r\n      setOnboardingPhase("scanning");\r\n    }).catch(() => {\r\n      setShowOnboard(false);\r\n      setOnboardingPhase("scanning");\r\n    });'
  );
  fixes++;
  console.log("✅ Fix 1: selectPlan triggers scanning after plan saved");
} else if (c.includes('}).then(() => {\n      setShowOnboard(false);\n    }).catch(() => {\n      setShowOnboard(false);\n    });')) {
  c = c.replace(
    '}).then(() => {\n      setShowOnboard(false);\n    }).catch(() => {\n      setShowOnboard(false);\n    });',
    '}).then(() => {\n      setShowOnboard(false);\n      setOnboardingPhase("scanning");\n    }).catch(() => {\n      setShowOnboard(false);\n      setOnboardingPhase("scanning");\n    });'
  );
  fixes++;
  console.log("✅ Fix 1: selectPlan triggers scanning after plan saved");
} else if (c.includes('setOnboardingPhase("scanning")') && c.includes('setShowOnboard(false)')) {
  console.log("⏭️  Fix 1: already has scanning in selectPlan");
} else {
  console.log("⚠️  Fix 1: could not find pattern");
}

// Fix 2: Remove onLaunchChoice from OnboardModal props
// Change onLaunchChoice={()=>setShowLaunchChoice(true)} to nothing
var count = 0;
while (c.includes(' onLaunchChoice={()=>setShowLaunchChoice(true)}')) {
  c = c.replace(' onLaunchChoice={()=>setShowLaunchChoice(true)}', '');
  count++;
}
if (count > 0) {
  fixes++;
  console.log("✅ Fix 2: removed onLaunchChoice from " + count + " OnboardModal instances");
} else {
  console.log("⏭️  Fix 2: onLaunchChoice already removed");
}

// Fix 3: onComplete should clear phase and reload (not redirect to /app)
if (c.includes('window.location.href = "/app"')) {
  c = c.replace('window.location.href = "/app"', 'window.location.reload()');
  // Also fix setOnboardingPhase("complete") to null
  fixes++;
  console.log("✅ Fix 3a: onComplete uses reload instead of /app");
}
if (c.includes('var url = new URL(window.location.href); url.searchParams.delete("preview"); window.location.href = url.toString();')) {
  c = c.replace('var url = new URL(window.location.href); url.searchParams.delete("preview"); window.location.href = url.toString();', 'window.location.reload();');
  fixes++;
  console.log("✅ Fix 3b: onComplete uses simple reload");
}

fs.writeFileSync(file, c, "utf8");

// Verify
var final = fs.readFileSync(file, "utf8");
console.log("\n🔍 Verifying...");
console.log("  selectPlan has scanning:", final.includes('setOnboardingPhase("scanning")') ? "✅" : "❌");
console.log("  No onLaunchChoice:", !final.includes("onLaunchChoice") ? "✅" : "❌ still present");
console.log("  onComplete has reload:", final.includes("window.location.reload()") ? "✅" : "❌");

// Balance check
var o = (final.match(/\{/g)||[]).length, cl = (final.match(/\}/g)||[]).length;
var po = (final.match(/\(/g)||[]).length, pc = (final.match(/\)/g)||[]).length;
console.log("  Braces:", o, cl, o===cl ? "✅" : "❌");
console.log("  Parens:", po, pc, po===pc ? "✅" : "❌");

console.log("\nDone:", fixes, "fixes applied");
