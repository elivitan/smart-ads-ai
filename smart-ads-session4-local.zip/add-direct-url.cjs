// add-direct-url.cjs
// Adds directUrl to schema.prisma for Prisma migrations via Supabase
const fs = require("fs");

const file = "schema.prisma";
let content = fs.readFileSync(file, "utf8");

if (content.includes("directUrl")) {
  console.log("directUrl already exists in schema.prisma — nothing to do.");
  process.exit(0);
}

const find = 'url      = env("DATABASE_URL")';
const replace = 'url      = env("DATABASE_URL")\n  directUrl = env("DIRECT_URL")';

if (!content.includes(find)) {
  console.error("ERROR: Could not find DATABASE_URL line in schema.prisma");
  process.exit(1);
}

content = content.replace(find, replace);
fs.writeFileSync(file, content, "utf8");
console.log("Done — added directUrl to schema.prisma");
