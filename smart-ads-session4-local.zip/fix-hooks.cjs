const fs = require("fs");
const f = "app/routes/app._index.jsx";
let code = fs.readFileSync(f, "utf-8");

// Fix 1: sortedProducts - useMemo -> regular const (line ~2158)
code = code.replace(
  /const sortedProducts = useMemo\(\(\) =>\s*\n\s*\[\.\.\.allDbProducts\]\.sort\(\(a,b\)=>\(b\.aiAnalysis\?\.ad_score\|\|0\)-\(a\.aiAnalysis\?\.ad_score\|\|0\)\),\s*\n\s*\[allDbProducts\]\);/,
  `const sortedProducts = [...allDbProducts].sort((a,b)=>(b.aiAnalysis?.ad_score||0)-(a.aiAnalysis?.ad_score||0));`
);

// Fix 2: topCompetitors - useMemo -> regular const (line ~2163)
code = code.replace(
  /const topCompetitors = useMemo\(\(\) => \{\s*\n\s*const allCompetitors = analyzedDbProducts\.flatMap\(p=>p\.aiAnalysis\?\.competitor_intel\?\.top_competitors\|\|\[\]\);\s*\n\s*const competitorMap = \{\};\s*\n\s*allCompetitors\.forEach\(c => \{ if \(!c\.domain\) return; if \(!competitorMap\[c\.domain\]\) competitorMap\[c\.domain\]=\{count:0,strength:c\.strength\|\|"unknown"\}; competitorMap\[c\.domain\]\.count\+\+; \}\);\s*\n\s*return Object\.entries\(competitorMap\)\.sort\(\(a,b\)=>b\[1\]\.count-a\[1\]\.count\)\.slice\(0,5\);\s*\n\s*\}, \[analyzedDbProducts\]\);/,
  `const topCompetitors = (() => {
      const allCompetitors = analyzedDbProducts.flatMap(p=>p.aiAnalysis?.competitor_intel?.top_competitors||[]);
      const competitorMap = {};
      allCompetitors.forEach(c => { if (!c.domain) return; if (!competitorMap[c.domain]) competitorMap[c.domain]={count:0,strength:c.strength||"unknown"}; competitorMap[c.domain].count++; });
      return Object.entries(competitorMap).sort((a,b)=>b[1].count-a[1].count).slice(0,5);
    })();`
);

// Fix 3: keywordGaps - useMemo -> regular const (line ~2172)
code = code.replace(
  /const \{ keywordGaps, totalMonthlyGapLoss \} = useMemo\(\(\) => \{/,
  `const { keywordGaps, totalMonthlyGapLoss } = (() => {`
);
// Close the useMemo -> IIFE: replace }, [analyzedDbProducts, avgScore]); with })();
code = code.replace(
  /\}, \[analyzedDbProducts, avgScore\]\);/,
  `})();`
);

// Verify
const hooksInIf = code.substring(code.indexOf("if (hasScanAccess) {")).match(/useMemo|useCallback/g);
if (hooksInIf) {
  console.log("WARNING: Still found hooks inside if block:", hooksInIf.length);
} else {
  console.log("SUCCESS: No more hooks inside if (hasScanAccess) block");
}

fs.writeFileSync(f, code, "utf-8");
console.log("File saved successfully!");
