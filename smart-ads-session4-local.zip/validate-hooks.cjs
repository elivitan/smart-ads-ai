const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");

if (!fs.existsSync(indexPath)) {
  console.log("app._index.jsx not found");
  process.exit(1);
}

const code = fs.readFileSync(indexPath, "utf-8");
const lines = code.split("\n");

// Count hooks
const hookPattern = /\b(useState|useEffect|useMemo|useRef|useCallback|useReducer)\b/;
let hookCount = 0;
let lastHookLine = 0;
let firstReturnLine = 0;
let hooksAfterReturn = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i].trim();
  
  // Skip comments
  if (line.startsWith("//") || line.startsWith("*")) continue;
  
  // Track hooks
  if (hookPattern.test(line) && !line.includes("import")) {
    hookCount++;
    lastHookLine = i + 1;
    if (firstReturnLine > 0) {
      hooksAfterReturn.push({ line: i + 1, code: line.substring(0, 80) });
    }
  }
  
  // Track early returns (but not inside functions)
  if ((line.startsWith("if (") || line.startsWith("if(")) && line.includes("return (") && firstReturnLine === 0) {
    firstReturnLine = i + 1;
  }
}

console.log("═══════════════════════════════════════");
console.log("  Hooks Validation Report");
console.log("═══════════════════════════════════════");
console.log("  Total hooks found: " + hookCount);
console.log("  Last hook at line: " + lastHookLine);
console.log("  First early return: " + firstReturnLine);

if (hooksAfterReturn.length > 0) {
  console.log("\n  ⛔ DANGER: " + hooksAfterReturn.length + " hook(s) AFTER early return!");
  console.log("  This WILL crash with 'Rendered more hooks'\n");
  hooksAfterReturn.forEach(h => {
    console.log("    Line " + h.line + ": " + h.code);
  });
  process.exit(1);
} else {
  console.log("\n  ✅ All hooks are before early returns - SAFE");
}

// Save hook count for future comparison
const countFile = path.join(ROOT, ".hooks-count");
const savedCount = fs.existsSync(countFile) ? parseInt(fs.readFileSync(countFile, "utf-8")) : 0;
if (savedCount > 0 && hookCount !== savedCount) {
  console.log("\n  ⚠️  Hook count changed: " + savedCount + " → " + hookCount);
  console.log("  Make sure new hooks are before line " + firstReturnLine);
}
fs.writeFileSync(countFile, String(hookCount), "utf-8");
console.log("  Hook count saved: " + hookCount);
