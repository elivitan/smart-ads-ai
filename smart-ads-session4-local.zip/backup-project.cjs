// backup-project.cjs
// Creates a full backup zip of the Smart Ads AI project
// Excludes: node_modules, .git, *.backup, dev.sqlite
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const timestamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
const zipName = `smart-ads-backup-${timestamp}.zip`;
const outputPath = path.join(process.env.USERPROFILE || ".", "Downloads", zipName);

console.log("=== Smart Ads AI — Full Project Backup ===\n");
console.log("Output:", outputPath);

// Use PowerShell Compress-Archive via child process
const excludeDirs = ["node_modules", ".git", ".cache", ".prisma"];
const excludeFiles = ["*.sqlite", "*.sqlite-journal", "*.sqlite-wal", "*.pre-pg-backup", "*.sqlite-backup"];

// Collect all files, excluding unwanted
const allFiles = [];
function walk(dir, rel) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.join(rel, entry.name);

    if (entry.isDirectory()) {
      if (excludeDirs.includes(entry.name)) continue;
      walk(fullPath, relPath);
    } else {
      let skip = false;
      for (const pattern of excludeFiles) {
        const ext = pattern.replace("*", "");
        if (entry.name.endsWith(ext)) { skip = true; break; }
      }
      if (!skip) allFiles.push(relPath);
    }
  }
}

walk(".", ".");
console.log(`Found ${allFiles.length} files to backup\n`);

// Write file list to temp file
const listFile = path.join(".", "_backup_files.txt");
fs.writeFileSync(listFile, allFiles.join("\n"), "utf8");

// Create zip using tar (available on Windows 10+)
try {
  // Try with PowerShell Compress-Archive
  const psFiles = allFiles.map(f => `"${f.replace(/\\/g, "/")}"`).join(",");

  // For large file lists, use a different approach
  const tempDir = "_backup_temp";
  if (fs.existsSync(tempDir)) fs.rmSync(tempDir, { recursive: true });

  // Use robocopy to create a clean copy
  console.log("Creating clean copy...");
  execSync(
    `robocopy . "${tempDir}" /E /XD node_modules .git .cache /XF *.sqlite *.sqlite-journal *.sqlite-wal *.pre-pg-backup *.sqlite-backup _backup_files.txt`,
    { stdio: "pipe" }
  ).toString();
} catch (e) {
  // robocopy returns non-zero exit codes even on success
}

const tempDir = "_backup_temp";
if (fs.existsSync(tempDir)) {
  console.log("Compressing...");
  try {
    execSync(
      `powershell -Command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${outputPath}' -Force"`,
      { stdio: "inherit" }
    );
    console.log(`\n✅ Backup created: ${outputPath}`);

    // Show size
    const stats = fs.statSync(outputPath);
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    console.log(`   Size: ${sizeMB} MB`);
    console.log(`   Files: ${allFiles.length}`);
  } catch (err) {
    console.error("Compress failed:", err.message);
  }

  // Cleanup
  fs.rmSync(tempDir, { recursive: true, force: true });
}

if (fs.existsSync(listFile)) fs.unlinkSync(listFile);

console.log("\nDone!");
