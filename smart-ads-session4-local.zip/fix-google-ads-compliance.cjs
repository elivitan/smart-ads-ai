const fs = require("fs");
const path = require("path");

let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app"))) {
  console.log("ERROR: Run from project root");
  process.exit(1);
}

let fixes = 0;

console.log("═══════════════════════════════════════════");
console.log("  Smart Ads AI — Google Ads Compliance Fix");
console.log("═══════════════════════════════════════════\n");

// ─── 1. Fix prompts.server.js ───
console.log("1. Updating prompts.server.js...");
const promptsPath = path.join(ROOT, "app/prompts.server.js");
if (fs.existsSync(promptsPath)) {
  const newPrompts = `/**
 * prompts.server.js
 * 
 * All AI prompts — aligned with Google Ads requirements.
 * RSA: up to 15 headlines (30 chars), 4 descriptions (90 chars)
 * PMax: + long headlines (90 chars), business name (25 chars)
 * 
 * Usage:
 *   import { PROMPTS } from "./prompts.server.js";
 */

export const PROMPTS = {

  /**
   * Analyze a batch of products for Google Ads.
   * Generates assets for BOTH RSA and PMax campaigns.
   */
  analyzeBatch: (products) =>
    \`You are a Google Ads expert. Analyze these \${products.length} products and generate campaign-ready assets.

PRODUCTS:
\${products.map((p, i) => \`\${i + 1}. "\${p.title}" - $\${p.price} - \${(p.description || "").slice(0, 150)}\`).join("\\n")}

Return ONLY valid JSON (no markdown, no backticks):
{
  "products": [
    {
      "title": "exact product title",
      "ad_score": 82,
      "ad_strength": "GOOD",
      "headlines": ["15 unique headlines, EACH max 30 characters"],
      "long_headlines": ["3 unique long headlines, EACH max 90 characters"],
      "descriptions": ["4 unique descriptions, EACH max 90 characters"],
      "keywords": [
        {"text": "keyword", "match_type": "BROAD"},
        {"text": "keyword phrase", "match_type": "PHRASE"},
        {"text": "exact keyword", "match_type": "EXACT"}
      ],
      "negative_keywords": ["free", "diy", "cheap", "used", "repair", "how to", "tutorial"],
      "path1": "Shop",
      "path2": "BestDeals",
      "recommended_bid": 1.50,
      "target_demographics": "Adults 25-45",
      "sitelinks": [
        {"title": "max 25 chars", "description": "max 35 chars", "url": "/page"}
      ]
    }
  ]
}

STRICT RULES:
- headlines: EXACTLY 15 unique headlines. Each MUST be ≤30 characters. Include product name, benefits, CTAs, urgency, price points.
- long_headlines: EXACTLY 3. Each MUST be ≤90 characters. More descriptive, include value proposition.
- descriptions: EXACTLY 4 unique descriptions. Each MUST be ≤90 characters. Include CTA, benefits, social proof.
- keywords: 15-20 high-intent keywords. Mix of BROAD, PHRASE, EXACT match types. Focus on buyer intent.
- negative_keywords: 7-10 keywords to exclude (informational, DIY, free, etc.)
- sitelinks: EXACTLY 4. Title max 25 chars, description max 35 chars.
- path1/path2: max 15 characters each, relevant to product category.
- ad_score: 60-95 range. 90+=excellent, 70-89=good, 50-69=average.
- ad_strength: EXCELLENT/GOOD/AVERAGE/POOR based on asset quality and variety.\`,

  /**
   * Select best products for advertising.
   */
  selectBest: (products, maxProducts) =>
    \`Google Ads expert. Select the \${maxProducts} products with highest ad potential from this list. Return JSON only.
Return: { "selected": [indices of best products, 0-based] }

Products:
\${products.map((p, i) => \`\${i}. "\${p.title}" - $\${p.price}\`).join("\\n")}

Criteria: high margin potential, clear search intent, competitive pricing, broad appeal.
Respond ONLY with valid JSON.\`,

  /**
   * Campaign strategy.
   */
  campaignStrategy: (storeInfo, productSummary) =>
    \`Google Ads strategist. Store: \${storeInfo.url || "shopify"} | \${productSummary}

Decide the optimal campaign setup. Return JSON only:
{"strategy":{"campaign_type":"pmax","campaign_type_reason":"reason","bidding":"max_conversions","bidding_reason":"reason","daily_budget_recommended":30,"daily_budget_min":15,"daily_budget_aggressive":60,"budget_reason":"reason","locations":["US"],"languages":["en"],"estimated_monthly_results":{"impressions":5000,"clicks":200,"ctr_pct":4.0,"conversions":8,"cost":600,"roas":3.5},"confidence_score":85,"warnings":["warning"],"quick_wins":["tip"]}}

Rules:
- campaign_type: "pmax" for most stores, "search" for niche/small budget
- bidding: "max_conversions" default, "max_clicks" for new stores
- Be realistic with estimates
Respond ONLY with valid JSON.\`,

  /**
   * Competitor analysis with full Google Ads asset generation.
   */
  competitorAnalysis: (product, competitors) =>
    \`Google Ads competitor analyst. Create winning ad assets for this product based on competitive landscape.

Product: "\${product.title}" - $\${product.price}
\${product.description ? \`Description: \${product.description.slice(0, 200)}\` : ""}

Competitor landscape:
\${competitors.map((c, i) => \`\${i + 1}. \${c.domain}: "\${c.title}" \${c.snippet ? \`- \${c.snippet.slice(0, 100)}\` : ""}\`).join("\\n")}

Return ONLY valid JSON:
{
  "headlines": ["15 unique headlines max 30 chars each, differentiated from competitors"],
  "long_headlines": ["3 long headlines max 90 chars each"],
  "descriptions": ["4 descriptions max 90 chars each with competitive advantages"],
  "keywords": [{"text":"keyword","match_type":"BROAD|PHRASE|EXACT"}],
  "negative_keywords": ["7-10 exclusion keywords"],
  "competitor_insights": "brief analysis",
  "recommended_bid": 1.50,
  "ad_score": 85,
  "keyword_gaps": ["keywords competitors use that this product should target"]
}

RULES:
- headlines: EXACTLY 15, each ≤30 chars. Include USPs vs competitors, price advantages, urgency.
- long_headlines: EXACTLY 3, each ≤90 chars. Compelling value propositions.
- descriptions: EXACTLY 4, each ≤90 chars. Highlight competitive advantages.
- keywords: 15-20 with mix of BROAD/PHRASE/EXACT. Include competitor alternative terms.
- negative_keywords: 7-10 to avoid wasted spend.
Respond ONLY with valid JSON.\`,

  /**
   * Keyword research.
   */
  keywordResearch: (topic, context) =>
    \`SEO and Google Ads keyword expert. Generate comprehensive keyword research for: "\${topic}"
\${context ? \`Context: \${context}\` : ""}

Return JSON only:
{"keywords": [{"keyword": "string", "search_volume": number, "competition": "low|medium|high", "cpc_estimate": number, "intent": "commercial|informational|navigational|transactional", "match_type": "broad|phrase|exact"}]}

Rules:
- Include 20-30 keywords
- Mix of head terms and long-tail
- Focus on commercial and transactional intent
- Include negative keyword suggestions
Respond ONLY with valid JSON.\`,

  keywordExpansion: (seedKeywords, productTitle) =>
    \`Google Ads keyword expert. Expand these seed keywords for "\${productTitle}":
\${seedKeywords.join(", ")}

Return JSON only:
{"expanded": [{"keyword": "string", "match_type": "broad|phrase|exact", "estimated_cpc": number, "relevance_score": number}]}

Rules:
- Generate 15-25 expanded keywords
- Include long-tail variations
- Include buyer-intent modifiers (buy, best, cheap, near me, review)
Respond ONLY with valid JSON.\`,
};
`;
  fs.writeFileSync(promptsPath, newPrompts, "utf-8");
  fixes++;
  console.log("  UPDATED: prompts.server.js — 15 headlines, long_headlines, 4 descriptions");
}

// ─── 2. Fix ai.server.js basic prompt + model ───
console.log("\n2. Updating ai.server.js...");
const aiPath = path.join(ROOT, "app/ai.server.js");
if (fs.existsSync(aiPath)) {
  let ai = fs.readFileSync(aiPath, "utf-8");
  
  // Fix model name
  ai = ai.replace(/claude-3-5-haiku-20241022/g, "claude-3-5-haiku-latest");
  
  // Fix the basic prompt to generate 15 headlines + long_headlines
  const oldBasicPrompt = `"headlines": ["h1","h2","h3","h4","h5","h6","h7","h8","h9","h10"]`;
  const newBasicPrompt = `"headlines": ["h1","h2","h3","h4","h5","h6","h7","h8","h9","h10","h11","h12","h13","h14","h15"],
      "long_headlines": ["long headline 1 max 90 chars","long headline 2","long headline 3"]`;
  if (ai.includes(oldBasicPrompt)) {
    ai = ai.replace(oldBasicPrompt, newBasicPrompt);
    console.log("  FIXED: Basic prompt now generates 15 headlines + 3 long_headlines");
  }

  // Update rules in basic prompt
  const oldRules = `Rules: headlines max 30 chars, descriptions max 90 chars.`;
  const newRules = `Rules: EXACTLY 15 headlines max 30 chars each. EXACTLY 3 long_headlines max 90 chars. EXACTLY 4 descriptions max 90 chars.`;
  if (ai.includes(oldRules)) {
    ai = ai.replace(oldRules, newRules);
  }

  // Ensure long_headlines are trimmed in post-processing
  if (!ai.includes("long_headlines")) {
    ai = ai.replace(
      "if (p.headlines) p.headlines = p.headlines.map(h => h.trim().slice(0, 30));\r?\n",
      "if (p.headlines) p.headlines = p.headlines.map(h => h.trim().slice(0, 30));\r?\n\n      if (p.long_headlines) p.long_headlines = p.long_headlines.map(h => h.trim().slice(0, 90));"
    );
  }
  
  fs.writeFileSync(aiPath, ai, "utf-8");
  fixes++;
  console.log("  UPDATED: ai.server.js — model + 15 headlines + long_headlines");
}

// ─── 3. Fix competitor-intel.server.js model + long_headlines ───
console.log("\n3. Updating competitor-intel.server.js...");
const compPath = path.join(ROOT, "app/competitor-intel.server.js");
if (fs.existsSync(compPath)) {
  let comp = fs.readFileSync(compPath, "utf-8");
  
  // Fix model
  comp = comp.replace(/claude-3-5-haiku-20241022/g, "claude-3-5-haiku-latest");
  
  // Add long_headlines to the JSON template if missing
  if (!comp.includes('"long_headlines"')) {
    comp = comp.replace(
      '"headlines":["h1 max 30 chars","h2","h3","h4","h5","h6","h7","h8","h9","h10","h11","h12","h13","h14","h15"]',
      '"headlines":["h1 max 30 chars","h2","h3","h4","h5","h6","h7","h8","h9","h10","h11","h12","h13","h14","h15"],"long_headlines":["long h1 max 90 chars","long h2","long h3"]'
    );
  }
  
  // Add long_headlines trimming
  if (!comp.includes("result.long_headlines")) {
    // Add long_headlines trimming after headlines trimming
    const compLines = comp.split("\n");
    for (let i = 0; i < compLines.length; i++) {
      if (compLines[i].includes("result.headlines") && compLines[i].includes("slice(0, 30)") && !compLines[i].includes("long_headlines")) {
        if (!comp.includes("result.long_headlines")) {
          compLines.splice(i + 1, 0, "  if (result.long_headlines) result.long_headlines = result.long_headlines.map(h => h.slice(0, 90));");
          break;
        }
      }
    }
    comp = compLines.join("\n");
  }
  
  // Add long_headlines to fallback
  if (!comp.includes("long_headlines: [")) {
    comp = comp.replace(
      'descriptions: [`Shop ${product.title} at great prices.`',
      'long_headlines: [`Discover ${product.title} - Premium Quality at Unbeatable Prices`,`Shop ${product.title} Online - Free Shipping & Easy Returns`,`${product.title} - Top Rated by Customers Worldwide`],\n        descriptions: [`Shop ${product.title} at great prices.`'
    );
  }
  
  fs.writeFileSync(compPath, comp, "utf-8");
  fixes++;
  console.log("  UPDATED: competitor-intel.server.js — model + long_headlines");
}

// ─── 4. Fix google-ads.server.js to use long_headlines for PMax ───
console.log("\n4. Updating google-ads.server.js for PMax long headlines...");
const gadsPath = path.join(ROOT, "app/google-ads.server.js");
if (fs.existsSync(gadsPath)) {
  let gads = fs.readFileSync(gadsPath, "utf-8");
  
  // Add long_headlines to createCampaign params if missing
  if (!gads.includes("longHeadlines")) {
    gads = gads.replace(
      "  imageUrls = [],\n  videoUrls = [],\n})",
      "  imageUrls = [],\n  videoUrls = [],\n  longHeadlines = [],\n})"
    );
    
    // Pass longHeadlines to PMax
    if (gads.includes("productTitle, headlines, descriptions, finalUrl, budgetResourceName, imageUrls, videoUrls,")) {
      gads = gads.replace(
        "productTitle, headlines, descriptions, finalUrl, budgetResourceName, imageUrls, videoUrls,",
        "productTitle, headlines, descriptions, finalUrl, budgetResourceName, imageUrls, videoUrls, longHeadlines,"
      );
    }
  }
  
  // Add longHeadlines to PMax function params
  if (gads.includes("async function createPMaxCampaign(customer, {") && !gads.includes("longHeadlines,\n})")) {
    gads = gads.replace(
      "productTitle, headlines, descriptions, finalUrl, budgetResourceName, imageUrls, videoUrls,\n})",
      "productTitle, headlines, descriptions, finalUrl, budgetResourceName, imageUrls, videoUrls, longHeadlines,\n})"
    );
  }
  
  fs.writeFileSync(gadsPath, gads, "utf-8");
  fixes++;
  console.log("  UPDATED: google-ads.server.js — longHeadlines param for PMax");
}

// ─── 5. Fix DB schema to store long_headlines ───
console.log("\n5. Checking Prisma schema for long_headlines...");
const schemaPath = path.join(ROOT, "prisma/schema.prisma");
if (fs.existsSync(schemaPath)) {
  let schema = fs.readFileSync(schemaPath, "utf-8");
  if (!schema.includes("longHeadlines")) {
    // Use regex to match any amount of whitespace
    schema = schema.replace(
      /^(  headlines\s+String\s+@default\("\[\]"\)\s+\/\/ JSON array)$/m,
      "$1\n  longHeadlines    String?   @default(\"[]\")  // JSON array - long headlines for PMax"
    );
    fs.writeFileSync(schemaPath, schema, "utf-8");
    fixes++;
    console.log("  ADDED: longHeadlines field to AiAnalysis model");
    console.log("  NOTE: Run 'npx prisma migrate dev --name add-long-headlines' after!");
  } else {
    console.log("  OK: already has longHeadlines");
  }
} else {
  console.log("  SKIP: schema.prisma not found");
}

// ─── 6. Fix scan route to save long_headlines ───
console.log("\n6. Updating scan route to save long_headlines...");
const scanPath = path.join(ROOT, "app/routes/app.api.scan.js");
if (fs.existsSync(scanPath)) {
  let scan = fs.readFileSync(scanPath, "utf-8");
  if (!scan.includes("longHeadlines")) {
    scan = scan.replace(
      'headlines: JSON.stringify(aiProduct.headlines || []),',
      'headlines: JSON.stringify(aiProduct.headlines || []),\n          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),'
    );
    // Also in update block
    scan = scan.replace(
      'headlines: JSON.stringify(aiProduct.headlines || []),',
      'headlines: JSON.stringify(aiProduct.headlines || []),\n          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),'
    );
    fs.writeFileSync(scanPath, scan, "utf-8");
    fixes++;
    console.log("  UPDATED: scan route saves long_headlines");
  } else {
    console.log("  OK: already saves longHeadlines");
  }
}

console.log("\n═══════════════════════════════════════════");
console.log("  Total fixes: " + fixes);
console.log("═══════════════════════════════════════════");
console.log("\n  Google Ads compliance summary:");
console.log("    RSA: 15 headlines (30ch) + 4 descriptions (90ch) ✅");
console.log("    PMax: + 3 long headlines (90ch) ✅");
console.log("    Keywords: 15-20 with match types ✅");
console.log("    Negative keywords: 7-10 ✅");
console.log("    Sitelinks: 4 with title+desc ✅");
console.log("    Path1/Path2: 15 chars each ✅");
console.log("\n  Next steps:");
console.log("    1. npx prisma migrate dev --name add-long-headlines");
console.log("    2. npm run dev");
console.log("    3. Run a new scan to generate updated assets");

// ─── EXTRA FIX: Ensure long_headlines trimming in ai.server.js ───
const aiPath2 = path.join(ROOT, "app/ai.server.js");
if (fs.existsSync(aiPath2)) {
  let aiCode = fs.readFileSync(aiPath2, "utf-8");
  if (!aiCode.includes("p.long_headlines")) {
    aiCode = aiCode.replace(
      /if \(p\.headlines\) p\.headlines = p\.headlines\.map\(h => h\.trim\(\)\.slice\(0, 30\)\);/,
      "if (p.headlines) p.headlines = p.headlines.map(h => h.trim().slice(0, 30));\n      if (p.long_headlines) p.long_headlines = p.long_headlines.map(h => h.trim().slice(0, 90));"
    );
    fs.writeFileSync(aiPath2, aiCode, "utf-8");
    console.log("  EXTRA FIX: Added long_headlines trimming to ai.server.js");
  }
}
