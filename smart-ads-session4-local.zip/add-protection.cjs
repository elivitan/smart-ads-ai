const fs = require("fs");
const path = require("path");

let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  console.log("ERROR: Run from project root");
  process.exit(1);
}

let fixes = 0;

console.log("═══════════════════════════════════════");
console.log("  Smart Ads AI — Extra Protection Layer");
console.log("═══════════════════════════════════════\n");

// ─── 1. Add ErrorBoundary to app._index.jsx ───
console.log("1. Adding ErrorBoundary to dashboard...");
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");
let indexCode = fs.readFileSync(indexPath, "utf-8");

// Count hooks BEFORE any changes
const hooksBefore = (indexCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;

if (!indexCode.includes("ErrorBoundary")) {
  // Add import at top (after last import)
  const lastImportIdx = indexCode.lastIndexOf("import {");
  const lastImportEnd = indexCode.indexOf("\n", indexCode.indexOf(";", lastImportIdx));
  
  // Add ErrorBoundary export at the very end of the file
  // This is a React Router feature - not a hook, completely safe
  const errorBoundaryCode = `

// ── ERROR BOUNDARY — catches React crashes and shows recovery UI ──
export function ErrorBoundary() {
  return (
    <div style={{
      minHeight:"100vh",background:"#0a0a1a",color:"#fff",
      display:"flex",alignItems:"center",justifyContent:"center",
      fontFamily:"Plus Jakarta Sans,system-ui,sans-serif"
    }}>
      <div style={{textAlign:"center",maxWidth:480,padding:"40px 20px"}}>
        <div style={{fontSize:64,marginBottom:20}}>⚠️</div>
        <h1 style={{fontSize:24,fontWeight:800,marginBottom:12}}>Something went wrong</h1>
        <p style={{fontSize:15,color:"rgba(255,255,255,.6)",marginBottom:24}}>
          The dashboard encountered an error. Your data is safe.
        </p>
        <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
          <button onClick={() => window.location.reload()} style={{
            background:"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff",
            border:"none",padding:"12px 24px",borderRadius:10,fontSize:14,
            fontWeight:700,cursor:"pointer"
          }}>🔄 Reload Dashboard</button>
          <button onClick={() => { try { sessionStorage.clear(); } catch(e) {} window.location.reload(); }} style={{
            background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.8)",
            border:"1px solid rgba(255,255,255,.15)",padding:"12px 24px",
            borderRadius:10,fontSize:14,fontWeight:600,cursor:"pointer"
          }}>🧹 Clear Cache & Reload</button>
        </div>
        <p style={{fontSize:12,color:"rgba(255,255,255,.3)",marginTop:20}}>
          If this keeps happening, try clearing your browser cache or contact support.
        </p>
      </div>
    </div>
  );
}
`;

  // Append at the end
  indexCode = indexCode.trimEnd() + "\n" + errorBoundaryCode;
  
  // Verify hooks count didn't change
  const hooksAfter = (indexCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  if (hooksAfter !== hooksBefore) {
    console.log("  ⛔ ABORTED: Hook count changed from " + hooksBefore + " to " + hooksAfter);
    process.exit(1);
  }
  
  fs.writeFileSync(indexPath, indexCode, "utf-8");
  fixes++;
  console.log("  ADDED: ErrorBoundary (catches crashes, shows recovery buttons)");
  console.log("  VERIFIED: Hook count unchanged (" + hooksBefore + " → " + hooksAfter + ")");
} else {
  console.log("  OK: ErrorBoundary already exists");
}

// ─── 2. Wrap all server API routes with try-catch safety ───
console.log("\n2. Adding try-catch safety to API routes...");
const apiFiles = [
  "app/routes/app.api.scan.js",
  "app/routes/app.api.campaign.js",
  "app/routes/app.api.ai-improve.js",
  "app/routes/app.api.subscription.js",
  "app/routes/app.api.sync.js",
  "app/routes/app.api.keywords.js",
];

for (const file of apiFiles) {
  const fullPath = path.join(ROOT, file);
  if (!fs.existsSync(fullPath)) { console.log("  SKIP: " + file); continue; }
  let code = fs.readFileSync(fullPath, "utf-8");
  
  // Check if action/loader already has outer try-catch
  if (code.includes("catch (authErr)") || code.includes("Unexpected error in")) {
    console.log("  OK: " + path.basename(file));
    continue;
  }
  
  // Wrap authenticate calls with try-catch if not already wrapped
  if (code.includes("await authenticate.admin(request);") && !code.includes("catch (authErr)")) {
    code = code.replace(
      /await authenticate\.admin\(request\);/,
      "try { await authenticate.admin(request); } catch (authErr) { console.error('[SmartAds] Auth failed:', authErr.message); return Response.json({ success: false, error: 'Authentication failed' }, { status: 401 }); }"
    );
    fs.writeFileSync(fullPath, code, "utf-8");
    fixes++;
    console.log("  FIXED: " + path.basename(file) + " — safe auth");
  } else {
    console.log("  OK: " + path.basename(file));
  }
}

// ─── 3. Add defensive checks to loader in app._index.jsx ───
console.log("\n3. Protecting loader from crashes...");
let loaderCode = fs.readFileSync(indexPath, "utf-8");
if (!loaderCode.includes("catch (loaderErr)")) {
  // Find the loader function and wrap the body in try-catch
  const loaderMatch = loaderCode.match(/export const loader = async \(\{ request \}\) => \{/);
  if (loaderMatch) {
    const loaderStart = loaderCode.indexOf(loaderMatch[0]);
    const loaderBodyStart = loaderStart + loaderMatch[0].length;
    
    // Find the return statement of the loader
    const returnMatch = loaderCode.indexOf("\n  return {", loaderBodyStart);
    if (returnMatch > 0) {
      // Find the closing of the return
      let braceCount = 0;
      let returnEnd = -1;
      for (let i = returnMatch; i < loaderCode.length; i++) {
        if (loaderCode[i] === '{') braceCount++;
        if (loaderCode[i] === '}') braceCount--;
        if (braceCount === 0 && loaderCode[i] === ';') {
          returnEnd = i + 1;
          break;
        }
      }
      
      if (returnEnd > 0) {
        // Find the closing brace of the loader
        const loaderClose = loaderCode.indexOf("\n};", returnEnd);
        if (loaderClose > 0) {
          const loaderBody = loaderCode.substring(loaderBodyStart, loaderClose);
          const wrappedBody = `
  try {${loaderBody}
  } catch (loaderErr) {
    console.error("[SmartAds] Loader error:", loaderErr.message);
    return {
      products: [],
      syncStatus: { totalProducts: 0 },
      shop: "",
      planFromCookie: "free",
      isPaidServer: false,
      needsInitialSync: true,
      subscription: { plan: "free", scanCredits: 0, aiCredits: 0, canPublish: false },
    };
  }`;
          loaderCode = loaderCode.substring(0, loaderBodyStart) + wrappedBody + "\n};" + loaderCode.substring(loaderClose + 3);
          
          // Verify hooks unchanged
          const hooksCheck = (loaderCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
          if (hooksCheck !== hooksBefore) {
            console.log("  ⛔ ABORTED: Hook count changed!");
            process.exit(1);
          }
          
          fs.writeFileSync(indexPath, loaderCode, "utf-8");
          fixes++;
          console.log("  ADDED: Loader try-catch (returns safe defaults on crash)");
        }
      }
    }
  }
} else {
  console.log("  OK: Loader already protected");
}

// ─── 4. Add .env validation ───
console.log("\n4. Creating env validation...");
const envCheckScript = `const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
const envPath = path.join(ROOT, ".env");

if (!fs.existsSync(envPath)) {
  console.log("⛔ .env file not found!");
  process.exit(1);
}

const env = fs.readFileSync(envPath, "utf-8");
const required = [
  "SHOPIFY_API_KEY",
  "SHOPIFY_API_SECRET", 
  "ANTHROPIC_API_KEY",
];
const optional = [
  "GOOGLE_ADS_CLIENT_ID",
  "GOOGLE_ADS_CLIENT_SECRET",
  "GOOGLE_ADS_DEVELOPER_TOKEN",
  "GOOGLE_ADS_CUSTOMER_ID",
  "GOOGLE_ADS_REFRESH_TOKEN",
  "SERPAPI_KEY",
];

console.log("Environment Check:\\n");
let missing = 0;
for (const key of required) {
  if (env.includes(key + "=") && !env.includes(key + "=\\n") && !env.includes(key + '=""')) {
    console.log("  ✅ " + key);
  } else {
    console.log("  ⛔ " + key + " — REQUIRED, missing or empty!");
    missing++;
  }
}
for (const key of optional) {
  if (env.includes(key + "=") && !env.includes(key + "=\\n") && !env.includes(key + '=""')) {
    console.log("  ✅ " + key);
  } else {
    console.log("  ⚠️  " + key + " — optional, some features disabled");
  }
}
if (missing > 0) {
  console.log("\\n⛔ " + missing + " required key(s) missing!");
  process.exit(1);
} else {
  console.log("\\n✅ All required keys present");
}
`;
fs.writeFileSync(path.join(ROOT, "check-env.cjs"), envCheckScript, "utf-8");

// Add to package.json scripts
const pkgPath = path.join(ROOT, "package.json");
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
pkg.scripts["check-env"] = "node check-env.cjs";
pkg.scripts["preflight"] = "node safety-check.cjs && node validate-hooks.cjs && node check-env.cjs";
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf-8");
fixes++;
console.log("  ADDED: check-env.cjs + npm run preflight");

console.log("\n═══════════════════════════════════════");
console.log("  Total additions: " + fixes);
console.log("═══════════════════════════════════════");
console.log("\n  What's new:");
console.log("    • ErrorBoundary — crashes show recovery buttons instead of white screen");
console.log("    • Loader protection — if DB fails, shows empty dashboard not crash");
console.log("    • API auth safety — all routes return JSON errors, never HTML");
console.log("    • npm run preflight — full system check before development");
console.log("\n  Run: npm run dev");
