/**
 * Deploy LivePulse patch — replaces app._index.jsx + DashboardWidgets.jsx
 */
const fs = require("fs");
const path = require("path");
const ROOT = __dirname;

console.log("═══════════════════════════════════════════");
console.log("  Deploy: LivePulse + Campaign Controls");
console.log("═══════════════════════════════════════════\n");

const files = [
  ["app._index.fixed.jsx", "app/routes/app._index.jsx"],
  ["DashboardWidgets.fixed.jsx", "app/routes/DashboardWidgets.jsx"],
];

for (const [src, dest] of files) {
  const srcPath = path.join(ROOT, src);
  const destPath = path.join(ROOT, dest);
  if (!fs.existsSync(srcPath)) { console.log("❌ " + src + " not found!"); process.exit(1); }
  let content = fs.readFileSync(srcPath, "utf8");
  content = content.replace(/\r\n/g, "\n").replace(/\n/g, "\r\n");
  fs.writeFileSync(destPath, content, "utf8");
  console.log("✅ " + dest + " replaced");
}

// Verify
console.log("\n🔍 Verifying...\n");
const idx = fs.readFileSync(path.join(ROOT, "app/routes/app._index.jsx"), "utf8");
const dw = fs.readFileSync(path.join(ROOT, "app/routes/DashboardWidgets.jsx"), "utf8");

const checks = [
  ["campaignList state", idx.includes("setCampaignList")],
  ["fetchCampaigns useEffect", idx.includes("fetchCampaigns")],
  ["campaignList to LivePulse", idx.includes("campaignList={campaignList}")],
  ["LivePulse Campaign Manager", dw.includes("Campaign Manager")],
  ["Per-campaign controls", dw.includes("⏸") && dw.includes("▶") && dw.includes("🗑")],
  ["handlePauseCampaign params", idx.includes("handlePauseCampaign(targetId")],
  ["handleRemoveCampaign params", idx.includes("handleRemoveCampaign(targetId")],
  ["onboardingPhase", idx.includes("onboardingPhase")],
  ["hasGoogleAds", idx.includes("hasGoogleAds")],
  ["ErrorBoundary", idx.includes("export function ErrorBoundary()")],
];

let ok = true;
for (const [l, v] of checks) { console.log("  " + l + ": " + (v?"✅":"❌")); if(!v) ok=false; }
console.log("\n" + (ok ? "✅ All checks passed!" : "⚠️ Some failed"));
