/**
 * fix-ranking-and-strategy.cjs
 * ═════════════════════════════
 * Run: node fix-ranking-and-strategy.cjs
 *
 * Fixes:
 * 1. Remove duplicate Google Ranking card from dashboard
 * 2. Remove ranking block from ProductModal (already in dashboard)
 * 3. Remove duplicate Recommended Bid/Target Demo in ProductModal
 * 4. Remove duplicate Long Headlines in ProductModal
 * 5. Make doScan auto-launch use strategy-based campaign params
 * 6. Make handleAutoCampaign use strategy-based campaign params
 */

const fs = require("fs");
const path = require("path");

const INDEX = path.join(__dirname, "app", "routes", "app._index.jsx");
const MODAL = path.join(__dirname, "app", "routes", "ProductModal.jsx");

// Read raw + normalize to LF for pattern matching
const indexRaw = fs.readFileSync(INDEX, "utf-8");
const modalRaw = fs.readFileSync(MODAL, "utf-8");
let indexSrc = indexRaw.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
let modalSrc = modalRaw.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

// Detect original line endings
const indexCRLF = indexRaw.includes("\r\n");
const modalCRLF = modalRaw.includes("\r\n");

let changes = 0;
let errors = 0;

function safeReplace(file, label, src, find, replace) {
  const count = src.split(find).length - 1;
  if (count === 0) {
    console.error(`  ✗ ${label}: pattern NOT FOUND in ${file}`);
    errors++;
    return src;
  }
  if (count > 1 && replace === "") {
    // Remove only the LAST occurrence for duplicates
    const lastIdx = src.lastIndexOf(find);
    src = src.slice(0, lastIdx) + src.slice(lastIdx + find.length);
    changes++;
    console.log(`  ✓ ${label} (removed last of ${count} duplicates)`);
    return src;
  }
  src = src.replace(find, replace);
  changes++;
  console.log(`  ✓ ${label}`);
  return src;
}

function removeDuplicate(file, label, src, block) {
  const count = src.split(block).length - 1;
  if (count >= 2) {
    const lastIdx = src.lastIndexOf(block);
    src = src.slice(0, lastIdx) + src.slice(lastIdx + block.length);
    changes++;
    console.log(`  ✓ ${label} (removed duplicate)`);
  } else if (count === 1) {
    console.log(`  ⚠ ${label}: only 1 occurrence — no duplicate to remove`);
  } else {
    console.error(`  ✗ ${label}: pattern NOT FOUND in ${file}`);
    errors++;
  }
  return src;
}

// ═══════════════════════════════════════════════════
// FIX 1: Remove duplicate Google Ranking card
// ═══════════════════════════════════════════════════
console.log("\n[1/6] Removing duplicate Google Ranking card...");

const googleRankCard = `            <div className="status-card"><div className="status-card-icon" style={{background:rankingData.bestPosition && rankingData.bestPosition<=10?"rgba(34,197,94,.1)":rankingData.bestPosition?"rgba(245,158,11,.1)":"rgba(255,255,255,.05)",color:rankingData.bestPosition && rankingData.bestPosition<=10?"#22c55e":rankingData.bestPosition?"#fbbf24":"rgba(255,255,255,.3)"}}>📍</div><div><div className="status-card-label">Google Ranking</div><div className="status-card-val">{rankingData.bestPosition ? \`#\${rankingData.bestPosition}\` : "\u2014"}</div></div><div className="status-card-trend">{rankingData.bestPosition ? \`Avg #\${rankingData.avgPosition} across \${rankingData.products} products\` : "Run scan to check"}</div></div>`;

indexSrc = removeDuplicate("app._index.jsx", "Google Ranking card", indexSrc, googleRankCard);

// ═══════════════════════════════════════════════════
// FIX 2: Strategy-based auto campaign in doScan
// ═══════════════════════════════════════════════════
console.log("\n[2/6] Adding strategy-based params to doScan auto launch...");

const oldDoScan = `    if (isAuto && allAiProducts.length > 0 && canPublish) {
      setAutoLaunching(true);
      let successCount = 0;
      for (let i = 0; i < fetchedProducts.length; i++) {
        const prod = fetchedProducts[i], ai = allAiProducts.find(ap => ap.title===prod.title)||allAiProducts[i]||{};
        try {
          const form = new FormData();
          form.append("productTitle", prod.title); form.append("headlines", JSON.stringify(ai.headlines||[]));
          form.append("descriptions", JSON.stringify(ai.descriptions||[])); form.append("keywords", JSON.stringify(ai.keywords||[]));
          form.append("finalUrl", getProductUrl(prod)); form.append("dailyBudget", "50");
          const res = await fetch("/app/api/campaign", { method:"POST", body:form });
          const data = await res.json(); if (data.success) successCount++;
        } catch(e) { console.error("Campaign launch failed:", e); }
      }
      setAutoLaunching(false); setAutoStatus(successCount > 0 ? "success" : "error");
    }`;

const newDoScan = `    if (isAuto && allAiProducts.length > 0 && canPublish) {
      setAutoLaunching(true);
      let successCount = 0;
      for (let i = 0; i < fetchedProducts.length; i++) {
        const prod = fetchedProducts[i], ai = allAiProducts.find(ap => ap.title===prod.title)||allAiProducts[i]||{};
        // Strategy-based campaign params from competitor intel
        const cStrategy = (ai.competitor_intel?.strategy || "aggressive").toLowerCase();
        const cPosition = ai.competitor_intel?.store_ranking?.position || null;
        let autoBudget = "50", autoCampaignType = "search", autoBidding = "max_conversions";
        if (cStrategy.includes("defensive") || (cPosition && cPosition <= 5)) {
          autoBudget = "30"; autoCampaignType = "search"; autoBidding = "max_conversions";
        } else if (cStrategy.includes("moderate") || (cPosition && cPosition <= 20)) {
          autoBudget = "50"; autoCampaignType = "search"; autoBidding = "max_conversions";
        } else {
          autoBudget = "70"; autoCampaignType = "pmax"; autoBidding = "max_clicks";
        }
        try {
          const form = new FormData();
          form.append("productTitle", prod.title); form.append("headlines", JSON.stringify(ai.headlines||[]));
          form.append("descriptions", JSON.stringify(ai.descriptions||[])); form.append("keywords", JSON.stringify(ai.keywords||[]));
          form.append("finalUrl", getProductUrl(prod)); form.append("dailyBudget", autoBudget);
          form.append("campaignType", autoCampaignType); form.append("bidding", autoBidding);
          const res = await fetch("/app/api/campaign", { method:"POST", body:form });
          const data = await res.json(); if (data.success) successCount++;
        } catch(e) { console.error("Campaign launch failed:", e); }
      }
      setAutoLaunching(false); setAutoStatus(successCount > 0 ? "success" : "error");
    }`;

indexSrc = safeReplace("app._index.jsx", "doScan auto — strategy params", indexSrc, oldDoScan, newDoScan);

// ═══════════════════════════════════════════════════
// FIX 3: Strategy-based handleAutoCampaign
// ═══════════════════════════════════════════════════
console.log("\n[3/6] Adding strategy-based params to handleAutoCampaign...");

const oldHandle = `  async function handleAutoCampaign() {
    if (!canPublish) { setShowOnboard(true); setOnboardTab("subscription"); setOnboardStep(1); return; }
    setAutoLaunching(true);
    let successCount = 0;
    const toProcess = analyzedDbProducts.length > 0 ? analyzedDbProducts : allDbProducts.slice(0, 5);
    for (const prod of toProcess) {
      const ai = prod.aiAnalysis||{};
      try {
        const form = new FormData();
        form.append("productTitle", prod.title); form.append("headlines", JSON.stringify(ai.headlines||[]));
        form.append("descriptions", JSON.stringify(ai.descriptions||[])); form.append("keywords", JSON.stringify(ai.keywords||[]));
        form.append("finalUrl", getProductUrl(prod)); form.append("dailyBudget", "50");
        const res = await fetch("/app/api/campaign", { method:"POST", body:form });
        const data = await res.json(); if (data.success) successCount++;
      } catch(e) { console.error("Auto campaign failed:", e); }
    }
    setAutoLaunching(false); setAutoStatus(successCount > 0 ? "success" : "error");
    if (successCount > 0) triggerConfetti();
  }`;

const newHandle = `  async function handleAutoCampaign() {
    if (!canPublish) { setShowOnboard(true); setOnboardTab("subscription"); setOnboardStep(1); return; }
    setAutoLaunching(true);
    let successCount = 0;
    const toProcess = analyzedDbProducts.length > 0 ? analyzedDbProducts : allDbProducts.slice(0, 5);
    for (const prod of toProcess) {
      const ai = prod.aiAnalysis||{};
      // Strategy-based campaign params from competitor intel
      const cStrategy = (ai.competitor_intel?.strategy || "aggressive").toLowerCase();
      const cPosition = ai.competitor_intel?.store_ranking?.position || null;
      let autoBudget = "50", autoCampaignType = "search", autoBidding = "max_conversions";
      if (cStrategy.includes("defensive") || (cPosition && cPosition <= 5)) {
        autoBudget = "30"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else if (cStrategy.includes("moderate") || (cPosition && cPosition <= 20)) {
        autoBudget = "50"; autoCampaignType = "search"; autoBidding = "max_conversions";
      } else {
        autoBudget = "70"; autoCampaignType = "pmax"; autoBidding = "max_clicks";
      }
      try {
        const form = new FormData();
        form.append("productTitle", prod.title); form.append("headlines", JSON.stringify(ai.headlines||[]));
        form.append("descriptions", JSON.stringify(ai.descriptions||[])); form.append("keywords", JSON.stringify(ai.keywords||[]));
        form.append("finalUrl", getProductUrl(prod)); form.append("dailyBudget", autoBudget);
        form.append("campaignType", autoCampaignType); form.append("bidding", autoBidding);
        const res = await fetch("/app/api/campaign", { method:"POST", body:form });
        const data = await res.json(); if (data.success) successCount++;
      } catch(e) { console.error("Auto campaign failed:", e); }
    }
    setAutoLaunching(false); setAutoStatus(successCount > 0 ? "success" : "error");
    if (successCount > 0) triggerConfetti();
  }`;

indexSrc = safeReplace("app._index.jsx", "handleAutoCampaign — strategy params", indexSrc, oldHandle, newHandle);

// ═══════════════════════════════════════════════════
// FIX 4: Remove ranking block from ProductModal
// ═══════════════════════════════════════════════════
console.log("\n[4/6] Removing ranking block from ProductModal...");

const rankBlock = `              {cIntel.store_ranking && (
                <div className="ci-ranking">
                  <div className="ci-ranking-icon">{cIntel.store_ranking.status==="page_1"?"🟢":cIntel.store_ranking.status==="page_2"?"🟡":"🔴"}</div>
                  <div className="ci-ranking-info"><strong>Your Google Position</strong><span>{cIntel.store_ranking.position?\`#\${cIntel.store_ranking.position} for "\${cIntel.store_ranking.query}"\` :\`Not found in top 10 for "\${cIntel.store_ranking.query}"\`}</span></div>
                  <div className={\`ci-strategy-badge ci-strat-\${(cIntel.strategy||"aggressive").split("_")[0]}\`}>{(cIntel.strategy||"aggressive").replace(/_/g," ").toUpperCase()}</div>
                </div>
              )}`;

modalSrc = safeReplace("ProductModal.jsx", "Remove ranking block", modalSrc, rankBlock, "");

// ═══════════════════════════════════════════════════
// FIX 5: Remove duplicate Recommended Bid / Target Demo
// ═══════════════════════════════════════════════════
console.log("\n[5/6] Removing duplicate Recommended Bid / Target Demo...");

const bidBlock = `        {(recBid || targetDemo) && <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:16}}>
          {recBid && <div style={{background:"rgba(99,102,241,.1)",border:"1px solid rgba(99,102,241,.2)",borderRadius:10,padding:"8px 14px",fontSize:12}}><span style={{color:"rgba(255,255,255,.5)"}}>Recommended Bid: </span><strong style={{color:"#a5b4fc"}}>\${recBid.toFixed(2)}</strong></div>}
          {targetDemo && <div style={{background:"rgba(34,197,94,.08)",border:"1px solid rgba(34,197,94,.15)",borderRadius:10,padding:"8px 14px",fontSize:12}}><span style={{color:"rgba(255,255,255,.5)"}}>Target: </span><strong style={{color:"#86efac"}}>{targetDemo}</strong></div>}
        </div>}`;

modalSrc = removeDuplicate("ProductModal.jsx", "Recommended Bid/Target Demo", modalSrc, bidBlock);

// ═══════════════════════════════════════════════════
// FIX 6: Remove duplicate Long Headlines
// ═══════════════════════════════════════════════════
console.log("\n[6/6] Removing duplicate Long Headlines...");

const longHBlock = `          {longHeadlines.length>0 && <div className="rsa-section">
            <div className="rsa-section-head"><h3>Long Headlines ({longHeadlines.length}/5)</h3><span className="rsa-hint">Max 90 chars · Performance Max</span></div>
            <div className="rsa-items">{longHeadlines.map((lh,li)=>(
              <div key={li} className="rsa-item rsa-item-desc">
                <span className="rsa-item-num">{li+1}</span>
                <div className="rsa-item-input" style={{background:"rgba(99,102,241,.05)",padding:"8px 10px",borderRadius:8,fontSize:13,color:"rgba(255,255,255,.8)",minHeight:36,display:"flex",alignItems:"center"}}>{lh}</div>
                <span className={"rsa-item-len "+(lh.length>90?"rsa-over":"")}>{lh.length}/90</span>
              </div>
            ))}</div>
          </div>}`;

modalSrc = removeDuplicate("ProductModal.jsx", "Long Headlines", modalSrc, longHBlock);

// ═══════════════════════════════════════════════════
// WRITE FILES — restore original line endings
// ═══════════════════════════════════════════════════
console.log("\n" + "═".repeat(44));
if (changes > 0) {
  const indexOut = indexCRLF ? indexSrc.replace(/\n/g, "\r\n") : indexSrc;
  const modalOut = modalCRLF ? modalSrc.replace(/\n/g, "\r\n") : modalSrc;
  fs.writeFileSync(INDEX, indexOut);
  fs.writeFileSync(MODAL, modalOut);
  console.log(`✅ ${changes} fixes applied successfully.`);
  if (errors > 0) console.log(`⚠  ${errors} patterns not found (may already be fixed).`);
  console.log("Files updated:");
  console.log("  - app/routes/app._index.jsx");
  console.log("  - app/routes/ProductModal.jsx");
} else {
  console.log("⚠ No changes made.");
}
console.log("═".repeat(44) + "\n");
console.log("Next steps:");
console.log("  npm run validate    (check hooks)");
console.log("  npm run dev         (test locally)");
console.log("  git add -A && git commit -m 'fix: ranking dashboard + strategy-based auto campaigns'\n");
