const fs = require("fs");
const path = "shopify.app.v.toml";

// The EXACT original content from git, plus read_orders added to scopes
const correctContent = `# Learn more about configuring your app at https://shopify.dev/docs/apps/tools/cli/configuration
client_id = "d8246e06f88d2ac902b3945d0f6e1e51"
name = "v"
application_url = "https://example.com"
embedded = true
[webhooks]
api_version = "2025-10"
  [[webhooks.subscriptions]]
  topics = [ "app/scopes_update" ]
  uri = "/webhooks/app/scopes_update"
  [[webhooks.subscriptions]]
  topics = [ "app/uninstalled" ]
  uri = "/webhooks/app/uninstalled"
  [[webhooks.subscriptions]]
  topics = [ "products/delete" ]
  uri = "/webhooks/products-delete"
  [[webhooks.subscriptions]]
  topics = [ "products/update", "products/create" ]
  uri = "/webhooks/products"
[access_scopes]
# Learn more at https://shopify.dev/docs/apps/tools/cli/configuration#access_scopes
scopes = "read_products,write_products,read_orders"
[auth]
redirect_urls = [ "https://example.com/api/auth" ]
[build]
automatically_update_urls_on_dev = true
`;

fs.writeFileSync(path, correctContent, "utf-8");
console.log("shopify.app.v.toml restored with read_orders scope (no BOM)");

// Verify
const verify = fs.readFileSync(path, "utf-8");
console.log("First char:", verify.charCodeAt(0) === 35 ? "# (OK, no BOM)" : "PROBLEM: " + verify.charCodeAt(0));
console.log("Has [auth]:", verify.includes("[auth]") ? "OK" : "MISSING");
console.log("Has [access_scopes]:", verify.includes("[access_scopes]") ? "OK" : "MISSING");
console.log("Has [build]:", verify.includes("[build]") ? "OK" : "MISSING");
console.log("Has read_orders:", verify.includes("read_orders") ? "OK" : "MISSING");
