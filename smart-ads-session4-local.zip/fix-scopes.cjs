const fs = require("fs");

// Step 1: Restore toml — remove [access_scopes] section entirely
let toml = fs.readFileSync("shopify.app.v.toml", "utf-8");
// Remove the [access_scopes] section and everything in it until next section or end
toml = toml.replace(/\[access_scopes\]\r?\n[^\[]*/, "");
// Clean up extra blank lines at end
toml = toml.trimEnd() + "\n\nautomatically_update_urls_on_dev = true\n";
// Make sure automatically_update_urls_on_dev isn't duplicated
const lines = toml.split(/\r?\n/);
const seen = new Set();
const cleaned = [];
for (const line of lines) {
  if (line.includes("automatically_update_urls_on_dev")) {
    if (seen.has("auto")) continue;
    seen.add("auto");
  }
  cleaned.push(line);
}
fs.writeFileSync("shopify.app.v.toml", cleaned.join("\n"));
console.log("1. Restored toml (removed [access_scopes])");

// Step 2: Add SCOPES to .env if not there
let env = fs.readFileSync(".env", "utf-8");
if (env.includes("SCOPES=")) {
  // Update existing
  env = env.replace(/SCOPES=.*/, "SCOPES=read_products,write_products,read_orders");
  console.log("2. Updated SCOPES in .env");
} else {
  env = env.trimEnd() + "\nSCOPES=read_products,write_products,read_orders\n";
  console.log("2. Added SCOPES to .env");
}
fs.writeFileSync(".env", env);

console.log("\nDone! Now run: npm run dev");
