// fix-shopify-dev.cjs
// Fixes the "setup" script in package.json to use "prisma db push" 
// instead of "prisma migrate deploy" which fails on baselined databases.
// Also removes prisma/migrations directory to prevent conflicts.
const fs = require("fs");
const path = require("path");

// 1. Fix package.json setup script
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const oldSetup = pkg.scripts.setup;
pkg.scripts.setup = "prisma generate && prisma db push --skip-generate";
console.log("Old setup:", oldSetup);
console.log("New setup:", pkg.scripts.setup);
fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2) + "\n", "utf8");
console.log("Updated: package.json");

// 2. Create empty prisma/migrations with lock file to prevent errors
const migrDir = path.join("prisma", "migrations");
if (fs.existsSync(migrDir)) {
  fs.rmSync(migrDir, { recursive: true, force: true });
}
fs.mkdirSync(migrDir, { recursive: true });
fs.writeFileSync(
  path.join(migrDir, "migration_lock.toml"),
  'provider = "postgresql"\n',
  "utf8"
);
console.log("Created: prisma/migrations/migration_lock.toml");

console.log("\nDone! Now run: npm run dev");
