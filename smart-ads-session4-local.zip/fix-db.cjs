/**
 * Check DB state and fix subscription + run scan
 */
const fs = require("fs");
const path = require("path");

// Load .env
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf8");
  for (const line of envContent.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx === -1) continue;
    const key = trimmed.substring(0, eqIdx).trim();
    let val = trimmed.substring(eqIdx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!process.env[key]) process.env[key] = val;
  }
}

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function main() {
  console.log("=== DB STATUS ===\n");

  const subs = await prisma.shopSubscription.findMany();
  console.log("Subscriptions:", subs.length);
  for (const s of subs) {
    console.log("  Shop:", s.shop);
    console.log("  Plan:", s.plan, "| Status:", s.status);
    console.log("  Scan credits:", s.scanCredits, "| AI credits:", s.aiCredits);
  }

  const prods = await prisma.product.count();
  console.log("\nProducts:", prods);

  const ai = await prisma.aiAnalysis.count();
  console.log("AI analyses:", ai);

  // Fix: ensure subscription has credits
  if (subs.length > 0) {
    for (const s of subs) {
      if (s.scanCredits < 50 || s.plan === "free") {
        await prisma.shopSubscription.update({
          where: { id: s.id },
          data: { plan: "starter", status: "trial", scanCredits: 50, aiCredits: 10, maxProducts: 25, maxCampaigns: 5 }
        });
        console.log("\n✅ Fixed subscription for", s.shop, "— starter plan with 50 scan credits");
      } else {
        console.log("\n✅ Subscription OK for", s.shop);
      }
    }
  } else {
    console.log("\n⚠️  No subscriptions found. The app will create one automatically when you load it.");
  }

  console.log("\n=== NEXT STEP ===");
  if (ai === 0) {
    console.log("AI analyses are empty. Refresh the app and click 'Scan Products' to restore data.");
  } else {
    console.log("Everything looks good!");
  }

  await prisma.$disconnect();
}

main().catch(e => { console.error("Error:", e.message); process.exit(1); });
