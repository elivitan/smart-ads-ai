const fs = require("fs");

// Fix CompetitorComponents.jsx null-safety issues
const ccPath = "app/routes/CompetitorComponents.jsx";
if (fs.existsSync(ccPath)) {
  let code = fs.readFileSync(ccPath, "utf-8");
  let fixes = 0;

  // Fix 1: compData.keywords.length -> (compData.keywords||[]).length
  if (code.includes("compData.keywords.length")) {
    code = code.replace(/compData\.keywords\.length/g, "(compData.keywords||[]).length");
    fixes++;
  }

  // Fix 2: compData.ads.length -> (compData.ads||[]).length  
  if (code.includes("compData.ads.length")) {
    code = code.replace(/compData\.ads\.length/g, "(compData.ads||[]).length");
    fixes++;
  }

  fs.writeFileSync(ccPath, code, "utf-8");
  console.log("CompetitorComponents.jsx: " + fixes + " null-safety fixes applied");
} else {
  console.log("CompetitorComponents.jsx not found at " + ccPath);
}

console.log("DONE!");
