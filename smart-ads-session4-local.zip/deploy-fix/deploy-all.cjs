const fs = require("fs");
const path = require("path");

// Auto-detect project root
let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  ROOT = "C:\\Users\\\u05D0\u05DC\u05D9\\smart-ads-ai-backup";
}
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  console.log("ERROR: Cannot find app/routes. Run from project root.");
  process.exit(1);
}

const scriptDir = __dirname;
const routesDir = path.join(ROOT, "app/routes");
const componentsDir = path.join(ROOT, "app/components");

console.log("Project root: " + ROOT);
console.log("Script dir: " + scriptDir);
console.log("");

// Files that go in routes/
const routeFiles = [
  "app._index.jsx",
  "AdPreviewPanel.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "SmallComponents.jsx",
  "styles.index.js",
  "app.keywords.jsx",
];

let copied = 0;
for (const file of routeFiles) {
  const src = path.join(scriptDir, file);
  if (!fs.existsSync(src)) {
    console.log("SKIP (not in package): " + file);
    continue;
  }
  const dst = path.join(routesDir, file);
  fs.copyFileSync(src, dst);
  copied++;
  console.log("DEPLOYED: " + file + " -> routes/");
}

// ESLint config goes to root
const eslintSrc = path.join(scriptDir, "eslint.config.mjs");
if (fs.existsSync(eslintSrc)) {
  fs.copyFileSync(eslintSrc, path.join(ROOT, "eslint.config.mjs"));
  console.log("DEPLOYED: eslint.config.mjs -> root");
  copied++;
}

// Clean up old backup files from routes/
const routeEntries = fs.readdirSync(routesDir);
let cleaned = 0;
for (const f of routeEntries) {
  if (f.includes(".broken") || f.includes(".bak") || f.includes(".pre-deploy")) {
    fs.unlinkSync(path.join(routesDir, f));
    cleaned++;
    console.log("CLEANED: " + f);
  }
}

// Remove duplicate component files from components/ (avoid confusion)
const dupFiles = ["AdPreviewPanel.jsx","CollectingDataScreen.jsx","CompetitorComponents.jsx",
  "DashboardWidgets.jsx","LandingComponents.jsx","SmallComponents.jsx","styles.index.js"];
for (const f of dupFiles) {
  const dup = path.join(componentsDir, f);
  if (fs.existsSync(dup)) {
    fs.unlinkSync(dup);
    console.log("REMOVED duplicate: components/" + f);
  }
}

// Verify
const indexCode = fs.readFileSync(path.join(routesDir, "app._index.jsx"), "utf-8");
const lineCount = indexCode.split("\n").length;
const hasCorrectImports = indexCode.includes('./styles.index.js') && indexCode.includes('./SmallComponents.jsx');

console.log("\n=== VERIFICATION ===");
console.log("app._index.jsx: " + lineCount + " lines " + (lineCount < 1300 ? "OK" : "WRONG"));
console.log("Imports: " + (hasCorrectImports ? "OK (./ paths)" : "WRONG"));
console.log("Files deployed: " + copied);
console.log("Old files cleaned: " + cleaned);

// Check if DB has data
try {
  const dbPath = path.join(ROOT, "prisma/dev.sqlite");
  const dbSize = fs.statSync(dbPath).size;
  if (dbSize < 200000) {
    console.log("\n⚠️  DATABASE IS SMALL (" + Math.round(dbSize/1024) + "KB)");
    console.log("   If dashboard shows zeros, you need to:");
    console.log("   1. Copy DB from working project: Copy-Item 'C:\\Users\\אלי\\v\\prisma\\dev.sqlite' 'prisma\\dev.sqlite' -Force");
    console.log("   2. OR run a new scan from the dashboard");
  } else {
    console.log("Database: " + Math.round(dbSize/1024) + "KB - looks good");
  }
} catch(e) {
  console.log("\n⚠️  No database found - will be created on first run");
}

console.log("\nDONE! Run: npm run dev");
