const fs = require("fs");
const path = require("path");

let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  console.log("ERROR: Run from project root directory");
  process.exit(1);
}

let totalFixes = 0;

function readFile(relPath) {
  const full = path.join(ROOT, relPath);
  if (!fs.existsSync(full)) return null;
  return fs.readFileSync(full, "utf-8");
}

function writeFile(relPath, content) {
  fs.writeFileSync(path.join(ROOT, relPath), content, "utf-8");
}

function fix(relPath, description, fixFn) {
  const content = readFile(relPath);
  if (!content) { console.log("  SKIP (not found): " + relPath); return; }
  const fixed = fixFn(content);
  if (fixed === content) { console.log("  OK (no change needed): " + description); return; }
  writeFile(relPath, fixed);
  totalFixes++;
  console.log("  FIXED: " + description);
}

console.log("═══════════════════════════════════════");
console.log("  Smart Ads AI — Stabilization Script");
console.log("═══════════════════════════════════════\n");

// ─── FIX 1: google-ads — add imageUrls/videoUrls ───
console.log("1. google-ads.server.js");
fix("app/google-ads.server.js", "Add imageUrls/videoUrls params", (src) => {
  if (src.includes("imageUrls = []")) return src;
  return src.replace(
    /bidding = "max_conversions",\s*\r?\n\}\)/,
    'bidding = "max_conversions",\n  imageUrls = [],\n  videoUrls = [],\n})'
  );
});

// ─── FIX 2: license — limits after trial check ───
console.log("2. license.server.js");
fix("app/license.server.js", "Move limits calculation after trial check", (src) => {
  const lines = src.split("\n");
  let limitsIdx = -1, trialStartIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('const limits = PLAN_LIMITS[sub.plan]') && limitsIdx === -1) limitsIdx = i;
    if (lines[i].includes('sub.status === "trial"') && lines[i].includes('trialEndsAt') && trialStartIdx === -1) trialStartIdx = i;
  }
  if (limitsIdx < 0 || trialStartIdx < 0 || limitsIdx > trialStartIdx) return src;
  const limitsLine = lines.splice(limitsIdx, 1)[0];
  // Find end of trial block (closing brace after sub.status = "expired")
  for (let i = limitsIdx; i < lines.length; i++) {
    if (lines[i].includes('sub.plan = "free"') || lines[i].includes('sub.status = "expired"')) {
      for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
        if (lines[j].trim() === '}') {
          lines.splice(j + 1, 0, "", limitsLine);
          return lines.join("\n");
        }
      }
    }
  }
  return src;
});

// ─── FIX 3: sync — remove include from upsert ───
console.log("3. sync.server.js");
fix("app/sync.server.js", "Remove include from upsert", (src) => {
  return src.replace(
    /,?\s*include:\s*\{\s*aiAnalysis:\s*\{\s*select:\s*\{\s*productHash:\s*true\s*\}\s*\}\s*\}/g,
    ''
  );
});

// ─── FIX 4: campaign-manage — safe auth ───
console.log("4. app.api.campaign-manage.js");
fix("app/routes/app.api.campaign-manage.js", "Safe auth wrapper", (src) => {
  if (src.includes("catch (authErr)")) return src;
  return src.replace(
    /export const action = async \(\{ request \}\) => \{[\s\r\n]*await authenticate\.admin\(request\);/,
    `export const action = async ({ request }) => {\n  try { await authenticate.admin(request); } catch (authErr) { return Response.json({ success: false, error: "Auth failed" }, { status: 401 }); }`
  );
});

// ─── FIX 5: campaign-status — safe auth ───
console.log("5. app.api.campaign-status.js");
fix("app/routes/app.api.campaign-status.js", "Safe auth wrapper", (src) => {
  if (src.includes("catch (authErr)")) return src;
  return src.replace(
    /export const action = async \(\{ request \}\) => \{[\s\r\n]*await authenticate\.admin\(request\);/,
    `export const action = async ({ request }) => {\n  try { await authenticate.admin(request); } catch (authErr) { return Response.json({ success: false, error: "Auth failed" }, { status: 401 }); }`
  );
});

// ─── FIX 6: slider CSS ───
console.log("6. styles.index.js");
fix("app/routes/styles.index.js", "Cross-browser slider fix", (src) => {
  if (src.includes("moz-range-thumb")) return src;
  let result = src;
  // Increase slider height and z-index
  result = result.replace(
    /\.budget-sim-slider\{[^}]*\}/,
    '.budget-sim-slider{width:100%;height:8px;-webkit-appearance:none;appearance:none;background:rgba(99,102,241,.2);border-radius:4px;outline:none;cursor:pointer;position:relative;z-index:50;pointer-events:all;margin:8px 0}'
  );
  // Replace webkit thumb and add Firefox thumb
  result = result.replace(
    /\.budget-sim-slider::-webkit-slider-thumb\{[^}]*\}/,
    '.budget-sim-slider::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);cursor:pointer;box-shadow:0 0 8px rgba(99,102,241,.5);margin-top:-7px}.budget-sim-slider::-moz-range-thumb{width:22px;height:22px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);cursor:pointer;box-shadow:0 0 8px rgba(99,102,241,.5);border:none}.budget-sim-slider::-moz-range-track{height:8px;background:rgba(99,102,241,.2);border-radius:4px}'
  );
  return result;
});

// ─── FIX 7: app._index.jsx — protect campaign polling ───
console.log("7. app._index.jsx");
fix("app/routes/app._index.jsx", "Protect campaign polling from 500 errors", (src) => {
  // Find all fetch("/app/api/campaign-manage" calls and add res.ok check after
  const lines = src.split("\n");
  let changed = false;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('fetch("/app/api/campaign-manage"') && 
        i + 1 < lines.length && 
        lines[i+1].includes('res.json()') && 
        !lines[i+1].includes('if (!res.ok)')) {
      // Insert res.ok check before the json() call
      const indent = lines[i+1].match(/^(\s*)/)[1];
      lines.splice(i + 1, 0, indent + 'if (!res.ok) return;');
      changed = true;
      i++; // skip inserted line
    }
  }
  return changed ? lines.join("\n") : src;
});

// ─── FIX 8: ai.server.js — model update ───
console.log("8. ai.server.js");
fix("app/ai.server.js", "Update deprecated Claude model", (src) => {
  if (!src.includes("claude-3-5-haiku-20241022")) return src;
  return src.replace(/claude-3-5-haiku-20241022/g, "claude-3-5-haiku-latest");
});

console.log("\n═══════════════════════════════════════");
console.log("  Total fixes: " + totalFixes);
console.log("═══════════════════════════════════════");
if (totalFixes > 0) {
  console.log("\n  Next: npm run dev");
}
