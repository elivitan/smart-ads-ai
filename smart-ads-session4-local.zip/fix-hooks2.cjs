const fs = require("fs");
const f = "app/routes/app._index.jsx";
const lines = fs.readFileSync(f, "utf-8").split("\n");

// Find and fix all useMemo inside the if(hasScanAccess) block
let fixes = 0;
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  const trimmed = line.trim();
  
  // Fix 1: sortedProducts useMemo -> regular
  if (trimmed.startsWith("const sortedProducts = useMemo(() =>")) {
    // This is a 3-line useMemo: declaration, body, closing
    // Line i:   const sortedProducts = useMemo(() =>
    // Line i+1:   [...allDbProducts].sort(...),
    // Line i+2: [allDbProducts]);
    const body = lines[i+1].trim();
    // Remove trailing comma from body
    const cleanBody = body.endsWith(",") ? body.slice(0, -1) : body;
    const indent = line.match(/^(\s*)/)[1];
    lines[i] = indent + "const sortedProducts = " + cleanBody + ";";
    lines[i+1] = "";  // blank out
    lines[i+2] = "";  // blank out [allDbProducts]);
    fixes++;
    console.log("Fixed sortedProducts at line " + (i+1));
  }
  
  // Fix 2: topCompetitors useMemo -> IIFE
  if (trimmed.startsWith("const topCompetitors = useMemo(() => {")) {
    const indent = line.match(/^(\s*)/)[1];
    lines[i] = indent + "const topCompetitors = (() => {";
    // Find closing }, [analyzedDbProducts]);
    for (let j = i+1; j < i+20; j++) {
      if (lines[j].trim().startsWith("}, [analyzedDbProducts]);")) {
        lines[j] = indent + "})();";
        fixes++;
        console.log("Fixed topCompetitors at line " + (i+1) + ", closed at " + (j+1));
        break;
      }
    }
  }
  
  // Fix 3: keywordGaps useMemo -> IIFE
  if (trimmed.startsWith("const { keywordGaps, totalMonthlyGapLoss } = useMemo(() => {")) {
    const indent = line.match(/^(\s*)/)[1];
    lines[i] = indent + "const { keywordGaps, totalMonthlyGapLoss } = (() => {";
    // Find closing }, [analyzedDbProducts, avgScore]);
    for (let j = i+1; j < i+30; j++) {
      if (lines[j].trim().startsWith("}, [analyzedDbProducts, avgScore]);")) {
        lines[j] = indent + "})();";
        fixes++;
        console.log("Fixed keywordGaps at line " + (i+1) + ", closed at " + (j+1));
        break;
      }
    }
  }
}

fs.writeFileSync(f, lines.join("\n"), "utf-8");
console.log("\nTotal fixes applied: " + fixes);
if (fixes === 3) {
  console.log("SUCCESS - all 3 hooks fixed!");
} else {
  console.log("WARNING - expected 3 fixes, got " + fixes);
}
