const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "app", "routes", "app._index.jsx");
let c = fs.readFileSync(file, "utf8");
let fixes = 0;

// Fix 1: Remove setOnboardingPhase("scanning") from selectPlan
// Replace lines 262-264 and 266-268
c = c.replace(
  /\/\/ AUTO-SCAN: After plan saved, trigger scanning phase\r?\n\s*setShowOnboard\(false\);\r?\n\s*setOnboardingPhase\("scanning"\);/,
  'setShowOnboard(false);'
);
c = c.replace(
  /\/\/ Even if save fails, trigger scanning\r?\n\s*setShowOnboard\(false\);\r?\n\s*setOnboardingPhase\("scanning"\);/,
  'setShowOnboard(false);'
);
if (!c.includes('AUTO-SCAN') && !c.includes('Even if save fails, trigger scanning')) {
  fixes++;
  console.log("✅ Fix 1: selectPlan no longer auto-triggers scanning");
} else {
  console.log("⚠️  Fix 1: partial or not applied");
}

// Fix 2: onComplete — clear phase and reload
c = c.replace(
  /onComplete=\{?\(\) => \{\r?\n\s*setOnboardingPhase\("complete"\);\r?\n\s*var url = new URL\(window\.location\.href\); url\.searchParams\.delete\("preview"\); window\.location\.href = url\.toString\(\);/,
  'onComplete={() => {\n              setOnboardingPhase(null);\n              window.location.reload();'
);
if (c.includes('setOnboardingPhase(null);\n              window.location.reload();')) {
  fixes++;
  console.log("✅ Fix 2: onComplete clears phase and reloads");
} else {
  console.log("⚠️  Fix 2: checking...");
  // Try simpler approach
  if (c.includes('setOnboardingPhase("complete")')) {
    c = c.replace('setOnboardingPhase("complete")', 'setOnboardingPhase(null)');
    console.log("  → Replaced setOnboardingPhase(complete) with (null)");
  }
  if (c.includes('url.searchParams.delete("preview")')) {
    c = c.replace(/var url = new URL\(window\.location\.href\); url\.searchParams\.delete\("preview"\); window\.location\.href = url\.toString\(\);/, 'window.location.reload();');
    console.log("  → Replaced URL manipulation with simple reload");
    fixes++;
  }
}

fs.writeFileSync(file, c, "utf8");
console.log("\nDone:", fixes, "fixes applied");

// Verify
const final = fs.readFileSync(file, "utf8");
console.log("\nVerify:");
console.log("  No AUTO-SCAN comment:", !final.includes("AUTO-SCAN") ? "✅" : "❌");
console.log("  No auto scanning in selectPlan:", !final.includes('setOnboardingPhase("scanning");\r\n    })') ? "✅" : "check");
console.log("  onComplete has reload:", final.includes("window.location.reload()") ? "✅" : "❌");
