const fs = require("fs");
const path = require("path");

const routesDir = "app/routes";
const componentsDir = "app/components";

// Files that should be in routes/ (alongside app._index.jsx)
const routeComponents = [
  "AdPreviewPanel.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx", 
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "SmallComponents.jsx",
  "styles.index.js",
];

// Step 1: Move component files from components/ to routes/ if they're not there
let moved = 0;
for (const file of routeComponents) {
  const inRoutes = path.join(routesDir, file);
  const inComponents = path.join(componentsDir, file);
  
  if (!fs.existsSync(inRoutes) && fs.existsSync(inComponents)) {
    fs.copyFileSync(inComponents, inRoutes);
    fs.unlinkSync(inComponents);
    moved++;
    console.log("MOVED to routes/: " + file);
  } else if (fs.existsSync(inRoutes)) {
    console.log("ALREADY in routes/: " + file);
    // Remove duplicate from components/ if exists
    if (fs.existsSync(inComponents)) {
      fs.unlinkSync(inComponents);
      console.log("  (removed duplicate from components/)");
    }
  } else {
    console.log("MISSING: " + file + " (not in routes/ or components/)");
  }
}

// Step 2: Fix imports in app._index.jsx - change "../components/" back to "./" for these files
const indexPath = path.join(routesDir, "app._index.jsx");
let code = fs.readFileSync(indexPath, "utf-8");

const importFixes = {
  '"../components/styles.index.js"': '"./styles.index.js"',
  '"../components/SmallComponents.jsx"': '"./SmallComponents.jsx"',
  '"../components/CollectingDataScreen.jsx"': '"./CollectingDataScreen.jsx"',
  '"../components/AdPreviewPanel.jsx"': '"./AdPreviewPanel.jsx"',
  '"../components/CompetitorComponents.jsx"': '"./CompetitorComponents.jsx"',
  '"../components/DashboardWidgets.jsx"': '"./DashboardWidgets.jsx"',
  '"../components/LandingComponents.jsx"': '"./LandingComponents.jsx"',
  '"../components/ProductModal.jsx"': '"./ProductModal.jsx"',
};

let importFixes_count = 0;
for (const [wrong, correct] of Object.entries(importFixes)) {
  if (code.includes(wrong)) {
    code = code.replace(wrong, correct);
    importFixes_count++;
    console.log("FIXED import: " + wrong + " -> " + correct);
  }
}

// Keep "../components/Modals.jsx" as is - that one stays in components/
fs.writeFileSync(indexPath, code, "utf-8");

console.log("\n=== SUMMARY ===");
console.log("Files moved to routes/: " + moved);
console.log("Imports fixed: " + importFixes_count);
console.log("DONE! Run 'npm run dev' to test.");
