/**
 * migrate-to-postgres.cjs
 * ═══════════════════════════════════════════════════════════════
 * Migrates Smart Ads AI from SQLite to PostgreSQL.
 * Fixes ALL bugs found during deep code review.
 *
 * MIGRATION:
 * 1. schema.prisma: sqlite → postgresql + @db.Text + new indexes
 * 2. db.server.js: connection pool + logging
 *
 * BUG FIXES:
 * 3. app.api.scan.js: duplicate longHeadlines in create + missing from update
 * 4. sync.server.js saveAiAnalysis: missing longHeadlines in create + update
 * 5. sync.server.js getShopProducts: missing longHeadlines in response mapping
 * 6. license.server.js: manual updatedAt conflicts with @updatedAt
 * 7. keyword-research.server.js: deprecated claude-3-5-sonnet model
 *
 * Run: node migrate-to-postgres.cjs
 * ═══════════════════════════════════════════════════════════════
 */

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
let errors = 0;

function readFile(rel) {
  const full = path.join(ROOT, rel);
  if (!fs.existsSync(full)) {
    console.error(`  ❌ File not found: ${rel}`);
    errors++;
    return null;
  }
  return fs.readFileSync(full, "utf8");
}

function writeFile(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, "utf8");
  console.log(`  ✅ Written: ${rel}`);
}

function backupFile(rel) {
  const src = path.join(ROOT, rel);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, src + ".pre-pg-backup");
    console.log(`  📦 Backup: ${rel}`);
  }
}

function patchFile(rel, patches) {
  let raw = readFile(rel);
  if (!raw) return;
  backupFile(rel);
  const hasCRLF = raw.includes("\r\n");
  let content = raw.replace(/\r\n/g, "\n");
  for (const { find, replace, label } of patches) {
    if (content.includes(find)) {
      content = content.replace(find, replace);
      console.log(`  ✅ Patched: ${label}`);
    } else {
      console.error(`  ❌ Patch failed: ${label}`);
      errors++;
    }
  }
  if (hasCRLF) content = content.replace(/\n/g, "\r\n");
  writeFile(rel, content);
}

function verify(label, ok) {
  if (ok) console.log(`  ✅ ${label}`);
  else { console.error(`  ❌ ${label}`); errors++; }
}

console.log("\n═══════════════════════════════════════════════════════════");
console.log("  Smart Ads AI — PostgreSQL Migration + All Bug Fixes");
console.log("═══════════════════════════════════════════════════════════\n");

// ═══════════════════════════════════════════════
// STEP 1: Backups
// ═══════════════════════════════════════════════
console.log("📦 Step 1: Backups...");
backupFile("schema.prisma");
backupFile("app/db.server.js");

// ═══════════════════════════════════════════════
// STEP 2: schema.prisma
// ═══════════════════════════════════════════════
console.log("\n📝 Step 2: New schema.prisma...");
writeFile("schema.prisma", [
  '// Smart Ads AI — Prisma Schema (PostgreSQL)',
  '',
  'generator client {',
  '  provider = "prisma-client-js"',
  '}',
  '',
  'datasource db {',
  '  provider = "postgresql"',
  '  url      = env("DATABASE_URL")',
  '}',
  '',
  'model Session {',
  '  id            String    @id',
  '  shop          String',
  '  state         String',
  '  isOnline      Boolean   @default(false)',
  '  scope         String?',
  '  expires       DateTime?',
  '  accessToken   String',
  '  userId        BigInt?',
  '  firstName     String?',
  '  lastName      String?',
  '  email         String?',
  '  accountOwner  Boolean   @default(false)',
  '  locale        String?',
  '  collaborator  Boolean?  @default(false)',
  '  emailVerified Boolean?  @default(false)',
  '  refreshToken        String?',
  '  refreshTokenExpires DateTime?',
  '',
  '  @@index([shop])',
  '}',
  '',
  'model Product {',
  '  id              String    @id',
  '  shop            String',
  '  title           String',
  '  description     String    @default("") @db.Text',
  '  handle          String    @default("")',
  '  image           String    @default("") @db.Text',
  '  price           String    @default("0")',
  '  status          String    @default("ACTIVE")',
  '  inventoryTotal  Int       @default(0)',
  '  inStock         Boolean   @default(true)',
  '  productType     String    @default("")',
  '  vendor          String    @default("")',
  '  tags            String    @default("") @db.Text',
  '  shopifyUpdatedAt DateTime?',
  '  syncedAt        DateTime  @default(now())',
  '  createdAt       DateTime  @default(now())',
  '',
  '  aiAnalysis      AiAnalysis?',
  '',
  '  @@index([shop])',
  '  @@index([shop, inStock])',
  '  @@index([shop, status])',
  '}',
  '',
  'model AiAnalysis {',
  '  id              String    @id @default(cuid())',
  '  productId       String    @unique',
  '  shop            String',
  '  adScore         Int       @default(0)',
  '  adStrength      String    @default("AVERAGE")',
  '  headlines       String    @default("[]") @db.Text',
  '  longHeadlines   String?   @default("[]") @db.Text',
  '  descriptions    String    @default("[]") @db.Text',
  '  keywords        String    @default("[]") @db.Text',
  '  negativeKeywords String   @default("[]") @db.Text',
  '  path1           String    @default("Shop")',
  '  path2           String    @default("")',
  '  recommendedBid  Float     @default(1.0)',
  '  targetDemographics String @default("") @db.Text',
  '  sitelinks       String    @default("[]") @db.Text',
  '  competitorIntel String    @default("{}") @db.Text',
  '  analyzedAt      DateTime  @default(now())',
  '  productHash     String    @default("")',
  '',
  '  product         Product   @relation(fields: [productId], references: [id], onDelete: Cascade)',
  '',
  '  @@index([shop])',
  '  @@index([productId])',
  '  @@index([shop, adScore])',
  '}',
  '',
  'model SyncLog {',
  '  id          String    @id @default(cuid())',
  '  shop        String',
  '  type        String',
  '  status      String',
  '  details     String    @default("") @db.Text',
  '  productsAffected Int  @default(0)',
  '  startedAt   DateTime  @default(now())',
  '  completedAt DateTime?',
  '  error       String?   @db.Text',
  '',
  '  @@index([shop])',
  '  @@index([shop, type])',
  '  @@index([startedAt])',
  '}',
  '',
  'model ShopSubscription {',
  '  id              String    @id @default(cuid())',
  '  shop            String    @unique',
  '  plan            String    @default("free")',
  '  status          String    @default("active")',
  '  scanCredits     Int       @default(0)',
  '  aiCredits       Int       @default(0)',
  '  maxProducts     Int       @default(3)',
  '  maxCampaigns    Int       @default(0)',
  '  scanCountToday  Int       @default(0)',
  '  lastScanAt      DateTime?',
  '  apiCallsToday   Int       @default(0)',
  '  rateLimitReset  DateTime  @default(now())',
  '  trialEndsAt     DateTime?',
  '  billingStartedAt DateTime?',
  '  cancelledAt     DateTime?',
  '  createdAt       DateTime  @default(now())',
  '  updatedAt       DateTime  @updatedAt',
  '',
  '  @@index([shop])',
  '  @@index([plan])',
  '}',
  '',
  'model CampaignJob {',
  '  id                String    @id',
  '  shop              String',
  '  state             String    @default("QUEUED")',
  '  payload           String    @default("{}") @db.Text',
  '  idempotencyKey    String    @default("")',
  '  attempts          Int       @default(0)',
  '  stepsJson         String    @default("[]") @db.Text',
  '  googleCampaignId  String?',
  '  lastError         String?   @db.Text',
  '  lastStepAt        DateTime  @default(now())',
  '  createdAt         DateTime  @default(now())',
  '  updatedAt         DateTime  @updatedAt',
  '',
  '  @@index([shop])',
  '  @@index([shop, state])',
  '  @@index([idempotencyKey])',
  '  @@index([state, createdAt])',
  '}',
  '',
].join("\n"));

// ═══════════════════════════════════════════════
// STEP 3: db.server.js
// ═══════════════════════════════════════════════
console.log("\n📝 Step 3: New db.server.js...");
writeFile("app/db.server.js", [
  '// app/db.server.js',
  '// PostgreSQL connection for multi-tenant production (30K+ shops)',
  'import { PrismaClient } from "@prisma/client";',
  '',
  'const LOG_LEVELS = process.env.NODE_ENV === "production"',
  '  ? ["error", "warn"]',
  '  : ["query", "error", "warn"];',
  '',
  'function createPrismaClient() {',
  '  return new PrismaClient({',
  '    log: LOG_LEVELS,',
  '    datasources: {',
  '      db: {',
  '        url: process.env.DATABASE_URL,',
  '      },',
  '    },',
  '  });',
  '}',
  '',
  '// Prevent multiple instances in development (hot reload)',
  'if (process.env.NODE_ENV !== "production") {',
  '  if (!globalThis.prismaGlobal) {',
  '    globalThis.prismaGlobal = createPrismaClient();',
  '  }',
  '}',
  '',
  'const prisma = globalThis.prismaGlobal ?? createPrismaClient();',
  '',
  'export default prisma;',
  '',
].join("\n"));

// ═══════════════════════════════════════════════
// STEP 4: Fix scan.js — duplicate + missing longHeadlines
// ═══════════════════════════════════════════════
console.log("\n🔧 Step 4: Fix app/routes/app.api.scan.js...");
patchFile("app/routes/app.api.scan.js", [
  {
    label: "Remove duplicate longHeadlines in create block",
    find: "          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),\n          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),",
    replace: "          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),",
  },
  {
    label: "Add longHeadlines to update block",
    find: "          headlines: JSON.stringify(aiProduct.headlines || []),\n          descriptions: JSON.stringify(aiProduct.descriptions || []),\n          keywords: JSON.stringify(aiProduct.keywords || []),\n          negativeKeywords: JSON.stringify(aiProduct.negative_keywords || []),\n          path1: aiProduct.path1 || \"Shop\",\n          path2: aiProduct.path2 || \"\",\n          recommendedBid: aiProduct.recommended_bid || 1.0,\n          targetDemographics: aiProduct.target_demographics || \"\",\n          sitelinks: JSON.stringify(aiProduct.sitelinks || []),\n          competitorIntel: JSON.stringify(aiProduct.competitor_intel || {}),\n          analyzedAt: new Date(),\n          productHash: hash,",
    replace: "          headlines: JSON.stringify(aiProduct.headlines || []),\n          longHeadlines: JSON.stringify(aiProduct.long_headlines || []),\n          descriptions: JSON.stringify(aiProduct.descriptions || []),\n          keywords: JSON.stringify(aiProduct.keywords || []),\n          negativeKeywords: JSON.stringify(aiProduct.negative_keywords || []),\n          path1: aiProduct.path1 || \"Shop\",\n          path2: aiProduct.path2 || \"\",\n          recommendedBid: aiProduct.recommended_bid || 1.0,\n          targetDemographics: aiProduct.target_demographics || \"\",\n          sitelinks: JSON.stringify(aiProduct.sitelinks || []),\n          competitorIntel: JSON.stringify(aiProduct.competitor_intel || {}),\n          analyzedAt: new Date(),\n          productHash: hash,",
  },
]);

// ═══════════════════════════════════════════════
// STEP 5: Fix sync.server.js — saveAiAnalysis missing longHeadlines
// ═══════════════════════════════════════════════
console.log("\n🔧 Step 5: Fix sync.server.js saveAiAnalysis...");
patchFile("app/sync.server.js", [
  {
    label: "Add longHeadlines to saveAiAnalysis create + update blocks",
    find: "      headlines: JSON.stringify(aiResult.headlines || []),\n      descriptions: JSON.stringify(aiResult.descriptions || []),\n      keywords: JSON.stringify(aiResult.keywords || []),\n      negativeKeywords: JSON.stringify(aiResult.negative_keywords || []),\n      path1: aiResult.path1 || \"Shop\",\n      path2: aiResult.path2 || \"\",\n      recommendedBid: aiResult.recommended_bid || 1.0,\n      targetDemographics: aiResult.target_demographics || \"\",\n      sitelinks: JSON.stringify(aiResult.sitelinks || []),\n      competitorIntel: JSON.stringify(aiResult.competitor_intel || {}),\n      productHash: hash,\n      analyzedAt: new Date(),\n    },\n    update: {\n      adScore: aiResult.ad_score || 0,\n      adStrength: aiResult.ad_strength || \"AVERAGE\",\n      headlines: JSON.stringify(aiResult.headlines || []),\n      descriptions: JSON.stringify(aiResult.descriptions || []),",
    replace: "      headlines: JSON.stringify(aiResult.headlines || []),\n      longHeadlines: JSON.stringify(aiResult.long_headlines || []),\n      descriptions: JSON.stringify(aiResult.descriptions || []),\n      keywords: JSON.stringify(aiResult.keywords || []),\n      negativeKeywords: JSON.stringify(aiResult.negative_keywords || []),\n      path1: aiResult.path1 || \"Shop\",\n      path2: aiResult.path2 || \"\",\n      recommendedBid: aiResult.recommended_bid || 1.0,\n      targetDemographics: aiResult.target_demographics || \"\",\n      sitelinks: JSON.stringify(aiResult.sitelinks || []),\n      competitorIntel: JSON.stringify(aiResult.competitor_intel || {}),\n      productHash: hash,\n      analyzedAt: new Date(),\n    },\n    update: {\n      adScore: aiResult.ad_score || 0,\n      adStrength: aiResult.ad_strength || \"AVERAGE\",\n      headlines: JSON.stringify(aiResult.headlines || []),\n      longHeadlines: JSON.stringify(aiResult.long_headlines || []),\n      descriptions: JSON.stringify(aiResult.descriptions || []),",
  },
]);

// ═══════════════════════════════════════════════
// STEP 6: Fix sync.server.js — getShopProducts missing longHeadlines
// ═══════════════════════════════════════════════
console.log("\n🔧 Step 6: Fix sync.server.js getShopProducts...");
patchFile("app/sync.server.js", [
  {
    label: "Add longHeadlines to getShopProducts response mapping",
    find: "            headlines: JSON.parse(p.aiAnalysis.headlines),\n            descriptions: JSON.parse(p.aiAnalysis.descriptions),",
    replace: "            headlines: JSON.parse(p.aiAnalysis.headlines),\n            long_headlines: JSON.parse(p.aiAnalysis.longHeadlines || \"[]\"),\n            descriptions: JSON.parse(p.aiAnalysis.descriptions),",
  },
]);

// ═══════════════════════════════════════════════
// STEP 7: Fix license.server.js — manual updatedAt
// ═══════════════════════════════════════════════
console.log("\n🔧 Step 7: Fix license.server.js...");
patchFile("app/license.server.js", [
  {
    label: "Remove manual updatedAt (Prisma @updatedAt handles it)",
    find: "    aiCredits: limits.aiCreditsMonthly,\n    updatedAt: new Date(),\n  };",
    replace: "    aiCredits: limits.aiCreditsMonthly,\n  };",
  },
]);

// ═══════════════════════════════════════════════
// STEP 8: Fix keyword-research.server.js — deprecated model
// ═══════════════════════════════════════════════
console.log("\n🔧 Step 8: Fix keyword-research.server.js...");
patchFile("app/keyword-research.server.js", [
  {
    label: "Update deprecated claude-3-5-sonnet to claude-haiku-4-5 (first occurrence)",
    find: '        model: "claude-3-5-sonnet-20241022",\n        max_tokens: 4000,',
    replace: '        model: "claude-haiku-4-5-20251001",\n        max_tokens: 4000,',
  },
  {
    label: "Update deprecated claude-3-5-sonnet to claude-haiku-4-5 (second occurrence)",
    find: '        model: "claude-3-5-sonnet-20241022",\n        max_tokens: 4000,',
    replace: '        model: "claude-haiku-4-5-20251001",\n        max_tokens: 4000,',
  },
]);

// ═══════════════════════════════════════════════
// STEP 9: .env.postgres
// ═══════════════════════════════════════════════
console.log("\n📝 Step 9: Creating .env.postgres...");
writeFile(".env.postgres", [
  '# Smart Ads AI — PostgreSQL Configuration',
  '# Copy DATABASE_URL to your .env file',
  '#',
  '# Supabase (recommended):',
  '# DATABASE_URL="postgresql://postgres.[ref]:[pass]@aws-0-[region].pooler.supabase.com:6543/postgres?pgbouncer=true"',
  '#',
  '# Neon:',
  '# DATABASE_URL="postgresql://[user]:[pass]@[host].neon.tech/smart_ads_ai?sslmode=require"',
  '#',
  '# Local:',
  '# DATABASE_URL="postgresql://postgres:your_password@localhost:5432/smart_ads_ai?schema=public"',
  '',
].join("\n"));

// ═══════════════════════════════════════════════
// STEP 10: Delete old SQLite files
// ═══════════════════════════════════════════════
console.log("\n🗑️  Step 10: Removing SQLite artifacts...");
const migrationsDir = path.join(ROOT, "migrations");
if (fs.existsSync(migrationsDir)) {
  fs.rmSync(migrationsDir, { recursive: true, force: true });
  console.log("  ✅ Deleted: migrations/");
} else {
  console.log("  ℹ️  No migrations/ directory");
}
for (const f of ["dev.sqlite", "dev.sqlite-journal", "dev.sqlite-wal"]) {
  const fp = path.join(ROOT, f);
  if (fs.existsSync(fp)) { fs.unlinkSync(fp); console.log(`  ✅ Deleted: ${f}`); }
}

// ═══════════════════════════════════════════════
// STEP 11: Verify everything
// ═══════════════════════════════════════════════
console.log("\n🔍 Step 11: Verification...\n");

// Schema
const schema = readFile("schema.prisma");
if (schema) {
  verify("schema: PostgreSQL provider", schema.includes('provider = "postgresql"'));
  verify("schema: @db.Text present", schema.includes("@db.Text"));
  verify("schema: No SQLite references", !schema.includes("sqlite"));
  verify("schema: Session @@index([shop])", schema.includes("@@index([shop])"));
}

// scan.js
const scanJs = readFile("app/routes/app.api.scan.js");
if (scanJs) {
  const norm = scanJs.replace(/\r\n/g, "\n");
  const lhCount = (norm.match(/longHeadlines:/g) || []).length;
  verify(`scan.js: longHeadlines ${lhCount}x (want 2)`, lhCount === 2);
  verify("scan.js: No duplicate longHeadlines", !(norm.match(/longHeadlines:.*\nlongHeadlines:/g)));
}

// sync.server.js — saveAiAnalysis
const syncJs = readFile("app/sync.server.js");
if (syncJs) {
  const norm = syncJs.replace(/\r\n/g, "\n");
  const fnStart = norm.indexOf("export async function saveAiAnalysis");
  if (fnStart > -1) {
    const fnBody = norm.slice(fnStart, fnStart + 2000);
    const count = (fnBody.match(/longHeadlines:/g) || []).length;
    verify(`sync saveAiAnalysis: longHeadlines ${count}x (want 2)`, count === 2);
  }
  // getShopProducts
  const gpStart = norm.indexOf("export async function getShopProducts");
  if (gpStart > -1) {
    const gpBody = norm.slice(gpStart, gpStart + 2000);
    verify("sync getShopProducts: long_headlines in response", gpBody.includes("long_headlines:"));
  }
}

// license.server.js
const licenseJs = readFile("app/license.server.js");
if (licenseJs) {
  verify("license.server.js: No manual updatedAt", !licenseJs.includes("updatedAt: new Date()"));
}

// keyword-research.server.js
const kwJs = readFile("app/keyword-research.server.js");
if (kwJs) {
  verify("keyword-research: No deprecated model", !kwJs.includes("claude-3-5-sonnet"));
  verify("keyword-research: Uses haiku-4-5", kwJs.includes("claude-haiku-4-5-20251001"));
}

// ═══════════════════════════════════════════════
// REPORT
// ═══════════════════════════════════════════════
console.log("\n═══════════════════════════════════════════════════════════");
if (errors === 0) {
  console.log("  ✅ ALL CHECKS PASSED!");
} else {
  console.log(`  ⚠️  ${errors} issue(s). Review above.`);
}
console.log("═══════════════════════════════════════════════════════════");
console.log("");
console.log("  Modified files:");
console.log("    schema.prisma                — PostgreSQL + @db.Text + indexes");
console.log("    app/db.server.js             — Connection pool + logging");
console.log("    app/routes/app.api.scan.js   — Fixed longHeadlines (duplicate + missing)");
console.log("    app/sync.server.js           — Fixed longHeadlines in save + read");
console.log("    app/license.server.js        — Removed manual updatedAt");
console.log("    app/keyword-research.server.js — Updated deprecated Claude model");
console.log("");
console.log("  Backups: *.pre-pg-backup for each modified file");
console.log("");
console.log("  Next steps:");
console.log("  1. Add DATABASE_URL to .env (see .env.postgres)");
console.log("  2. npx prisma generate");
console.log("  3. npx prisma db push");
console.log("  4. npm run dev");
console.log("");
