const fs = require("fs");
const path = require("path");

const routesDir = "app/routes";

// All files from split_files.zip that go into routes/
const splitFiles = [
  "app._index.jsx",
  "AdPreviewPanel.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "SmallComponents.jsx",
  "styles.index.js",
];

// Step 1: Backup current app._index.jsx
const currentIndex = path.join(routesDir, "app._index.jsx");
if (fs.existsSync(currentIndex)) {
  const backup = currentIndex + ".pre-deploy-backup";
  fs.copyFileSync(currentIndex, backup);
  console.log("BACKUP: current app._index.jsx saved as .pre-deploy-backup");
}

// Step 2: Copy split files to routes/
// The script expects the split files to be in the same directory as this script
const scriptDir = __dirname;
let copied = 0;
for (const file of splitFiles) {
  const src = path.join(scriptDir, file);
  const dst = path.join(routesDir, file);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, dst);
    copied++;
    console.log("COPIED: " + file + " -> routes/");
  } else {
    console.log("ERROR: " + file + " not found in script directory!");
  }
}

// Step 3: Remove component files from components/ if they exist (avoid duplicates)
const componentsDir = "app/components";
const componentDuplicates = [
  "AdPreviewPanel.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "SmallComponents.jsx",
  "styles.index.js",
];
for (const file of componentDuplicates) {
  const dup = path.join(componentsDir, file);
  if (fs.existsSync(dup)) {
    fs.unlinkSync(dup);
    console.log("REMOVED duplicate: components/" + file);
  }
}

// Step 4: Remove any .broken or .backup files from routes/
const routeFiles = fs.readdirSync(routesDir);
for (const f of routeFiles) {
  if (f.includes(".broken") || f.includes(".pre-deploy-backup")) {
    fs.unlinkSync(path.join(routesDir, f));
    console.log("CLEANED: " + f);
  }
}

// Step 5: Verify imports
const code = fs.readFileSync(currentIndex, "utf-8");
const checks = [
  ['./styles.index.js', true],
  ['./SmallComponents.jsx', true],
  ['./CollectingDataScreen.jsx', true],
  ['../components/Modals.jsx', true],
];
console.log("\n=== VERIFICATION ===");
for (const [imp, expected] of checks) {
  const found = code.includes(imp);
  console.log((found === expected ? "OK" : "FAIL") + ": " + imp + " " + (found ? "found" : "missing"));
}

console.log("\n=== SUMMARY ===");
console.log("Files deployed: " + copied + "/9");
console.log("DONE! Run 'npm run dev' to test.");
