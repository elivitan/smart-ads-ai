const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app"))) { console.log("ERROR: Run from project root"); process.exit(1); }

let fixes = 0;
console.log("=== Google Ranking Enhancement ===\n");

// ─── 1. SerpAPI: expand to 50 results ───
console.log("1. Expanding SerpAPI search depth...");
const compPath = path.join(ROOT, "app/competitor-intel.server.js");
if (fs.existsSync(compPath)) {
  let comp = fs.readFileSync(compPath, "utf-8");
  if (comp.includes("num=10")) {
    comp = comp.replace("num=10", "num=50");
    fixes++;
    console.log("   FIXED: Now searches top 50 results (was 10)");
  }
  // Better status classification
  const oldStatus = 'r.position <= 3 ? "page_1" : r.position <= 10 ? "page_1_low" : "page_2"';
  const newStatus = 'r.position <= 3 ? "top_3" : r.position <= 10 ? "page_1" : r.position <= 20 ? "page_2" : r.position <= 30 ? "page_3" : "deep"';
  if (comp.includes(oldStatus)) {
    comp = comp.replace(oldStatus, newStatus);
    fixes++;
    console.log("   FIXED: Detailed position classification");
  }
  fs.writeFileSync(compPath, comp, "utf-8");
}

// ─── 2. app._index.jsx: Add real ranking computation + replace fake data ───
console.log("\n2. Adding real ranking to dashboard...");
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");
if (fs.existsSync(indexPath)) {
  let idx = fs.readFileSync(indexPath, "utf-8");
  const hooksBefore = (idx.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  
  const lines = idx.split("\n");
  
  for (let i = 0; i < lines.length; i++) {
    // Replace the fake googleRankStatus with real ranking computation
    if (lines[i].includes('const googleRankStatus = avgScore>=70?"page_1"')) {
      lines[i] = `    // Google Ranking — aggregated from real SerpAPI data
    const rankingData = (() => {
      const rankings = analyzedDbProducts
        .map(p => p.aiAnalysis?.competitor_intel?.store_ranking)
        .filter(r => r && r.found && r.position);
      if (rankings.length === 0) return { avgPosition: null, bestPosition: null, products: 0, status: "unknown" };
      const positions = rankings.map(r => r.position);
      const best = Math.min(...positions);
      const avg = Math.round(positions.reduce((a,b) => a+b, 0) / positions.length);
      const status = best <= 3 ? "top_3" : best <= 10 ? "page_1" : best <= 20 ? "page_2" : best <= 30 ? "page_3" : "deep";
      return { avgPosition: avg, bestPosition: best, products: rankings.length, status, page: Math.ceil(best / 10) };
    })();
    const googleRankStatus = rankingData.status;`;
      fixes++;
      console.log("   FIXED: Real ranking from SerpAPI data");
    }
    
    // Replace the Competitor Threat status card to show real ranking
    if (lines[i].includes('Competitor Threat') && lines[i].includes('status-card')) {
      // Find the whole card (it's one long line)
      const oldCard = lines[i];
      // Build the new card with real ranking info
      lines[i] = `            <div className="status-card"><div className="status-card-icon" style={{background:\`rgba(\${threatColor==="#22c55e"?"34,197,94":threatColor==="#f59e0b"?"245,158,11":"239,68,68"},.1)\`,color:threatColor}}>🕵️</div><div><div className="status-card-label">Competitor Threat</div><div className="status-card-val" style={{color:threatColor}}>{competitorThreat}</div></div><div className="status-card-trend" style={{color:threatColor}}>{rankingData.bestPosition ? \`Best: #\${rankingData.bestPosition}\` : "Scan to check"}</div></div>`;
      
      // Add a new Google Ranking card right after
      lines.splice(i + 1, 0, `            <div className="status-card"><div className="status-card-icon" style={{background:rankingData.bestPosition && rankingData.bestPosition<=10?"rgba(34,197,94,.1)":rankingData.bestPosition?"rgba(245,158,11,.1)":"rgba(255,255,255,.05)",color:rankingData.bestPosition && rankingData.bestPosition<=10?"#22c55e":rankingData.bestPosition?"#fbbf24":"rgba(255,255,255,.3)"}}>📍</div><div><div className="status-card-label">Google Ranking</div><div className="status-card-val">{rankingData.bestPosition ? \`#\${rankingData.bestPosition}\` : "—"}</div></div><div className="status-card-trend">{rankingData.bestPosition ? \`Avg #\${rankingData.avgPosition} across \${rankingData.products} products\` : "Run scan to check"}</div></div>`);
      fixes++;
      console.log("   FIXED: Added Google Ranking card to dashboard");
      i++; // skip the inserted line
    }
  }
  
  idx = lines.join("\n");
  
  // Verify hooks unchanged
  const hooksAfter = (idx.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  if (hooksAfter !== hooksBefore) {
    console.log("   ABORTED: Hook count changed " + hooksBefore + " -> " + hooksAfter);
    process.exit(1);
  }
  console.log("   VERIFIED: Hook count unchanged (" + hooksBefore + ")");
  
  fs.writeFileSync(indexPath, idx, "utf-8");
}

// ─── 3. Update prompts to include ranking in strategy ───
console.log("\n3. Including ranking in campaign strategy...");
const promptsPath = path.join(ROOT, "app/prompts.server.js");
if (fs.existsSync(promptsPath)) {
  let prompts = fs.readFileSync(promptsPath, "utf-8");
  
  // Add ranking context to competitor analysis prompt
  if (!prompts.includes("store_position")) {
    prompts = prompts.replace(
      'Competitor landscape:',
      'Store Google position: Use this to adjust strategy — top 10 = defensive bidding, 11-30 = moderate, 30+ = aggressive with long-tail keywords.\n\nCompetitor landscape:'
    );
    fixes++;
    console.log("   FIXED: Strategy prompt includes ranking context");
  }
  fs.writeFileSync(promptsPath, prompts, "utf-8");
}

// ─── 4. Update competitor-intel prompt to factor ranking into strategy ───
console.log("\n4. Ranking influences campaign strategy...");
if (fs.existsSync(compPath)) {
  let comp = fs.readFileSync(compPath, "utf-8");
  
  // The prompt already sends ranking data to Claude. Let me enhance the strategy instruction
  if (comp.includes('"strategy":"aggressive or defensive or dominant"') && !comp.includes("based on position")) {
    comp = comp.replace(
      '"strategy":"aggressive or defensive or dominant"',
      '"strategy":"aggressive(position>20) or defensive(position<=5) or moderate(position 6-20) — based on position"'
    );
    fixes++;
    console.log("   FIXED: Strategy now based on actual ranking position");
  }
  fs.writeFileSync(compPath, comp, "utf-8");
}

console.log("\n=== Total fixes: " + fixes + " ===");
console.log("\nWhat changed:");
console.log("  - SerpAPI searches top 50 (was 10) — real position up to #50");
console.log("  - Dashboard shows exact Google position (#1, #23, #47...)");
console.log("  - New Google Ranking card in status row");
console.log("  - Campaign strategy adapts to ranking position");
console.log("  - Hooks unchanged — safe to deploy");
