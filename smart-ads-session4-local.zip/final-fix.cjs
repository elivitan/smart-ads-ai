const fs = require("fs");
const f = "app/routes/app._index.jsx";
let c = fs.readFileSync(f, "utf8");

// Fix the =>const bug (if not already fixed)
c = c.replace(
  ') =>const { authenticate } = await import("../shopify.server"); {',
  ') => { const { authenticate } = await import("../shopify.server");'
);

// Split at safe export boundaries so React Router can find them
c = c.replace('; // Cookie helper', ';\n// Cookie helper');
c = c.replace('; }  export const loader', ';\n}\n\nexport const loader');
c = c.replace('}; };  const FREE_SCAN_LIMIT', '};\n};\n\nconst FREE_SCAN_LIMIT');
c = c.replace(
  'return { ...data, ctr, isRealData, lastUpdated }; }   // ',
  'return { ...data, ctr, isRealData, lastUpdated };\n}\n\n// '
);
c = c.replace(
  '  export default function Index()',
  '\n\nexport default function Index()'
);

let opens = (c.match(/{/g)||[]).length;
let closes = (c.match(/}/g)||[]).length;
console.log("Braces:", opens, "open,", closes, "close, diff:", opens - closes);
console.log("Has loader:", c.includes("export const loader"));
console.log("Has default:", c.includes("export default function"));
console.log("Lines:", c.split("\n").length);
fs.writeFileSync(f, c);
console.log("DONE!");
