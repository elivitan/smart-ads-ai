const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const ROOT = process.cwd();

console.log("═══════════════════════════════════════");
console.log("  Pre-Change Safety Check");
console.log("═══════════════════════════════════════\n");

let issues = 0;

// 1. Check git status
try {
  const status = execSync("git status --porcelain", { cwd: ROOT, encoding: "utf-8" });
  if (status.trim()) {
    console.log("  ⚠️  Uncommitted changes detected!");
    console.log("  Run: git add -A && git commit -m \"save before change\"");
    issues++;
  } else {
    console.log("  ✅ Git: clean state");
  }
} catch {
  console.log("  ⚠️  Git not initialized");
  issues++;
}

// 2. Check hooks
try {
  execSync("node validate-hooks.cjs", { cwd: ROOT, stdio: "pipe" });
  console.log("  ✅ Hooks: valid");
} catch {
  console.log("  ⛔ Hooks: INVALID - fix before making changes!");
  issues++;
}

// 3. Check for .bak files in routes
const routesDir = path.join(ROOT, "app/routes");
const bakFiles = fs.readdirSync(routesDir).filter(f => f.includes(".bak") || f.includes(".broken"));
if (bakFiles.length > 0) {
  console.log("  ⚠️  Cleanup needed: " + bakFiles.length + " backup files in routes/");
  bakFiles.forEach(f => console.log("    - " + f));
  issues++;
} else {
  console.log("  ✅ Routes: clean");
}

// 4. Check key files exist
const required = [
  "app/routes/app._index.jsx",
  "app/routes/styles.index.js",
  "app/routes/SmallComponents.jsx",
  "app/routes/DashboardWidgets.jsx",
  "app/routes/CollectingDataScreen.jsx",
  "app/routes/CompetitorComponents.jsx",
  "app/routes/AdPreviewPanel.jsx",
  "app/routes/LandingComponents.jsx",
  "app/routes/ProductModal.jsx",
];
const missing = required.filter(f => !fs.existsSync(path.join(ROOT, f)));
if (missing.length > 0) {
  console.log("  ⛔ Missing files: " + missing.join(", "));
  issues++;
} else {
  console.log("  ✅ Files: all present");
}

console.log("\n" + (issues === 0 ? "  ✅ ALL CLEAR - safe to make changes" : "  ⚠️  " + issues + " issue(s) found - fix before changing code"));
