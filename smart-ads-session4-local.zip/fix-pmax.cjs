﻿const fs = require('fs');
const file = 'app/google-ads.server.js';
let code = fs.readFileSync(file, 'utf8');

const old = export async function createCampaign({
  productTitle,
  headlines,
  descriptions,
  keywords = [],
  finalUrl,
  dailyBudget = 50,
  campaignType = "search",
  bidding = "max_conversions",
});

const fixed = export async function createCampaign({
  productTitle,
  headlines,
  descriptions,
  keywords = [],
  finalUrl,
  dailyBudget = 50,
  campaignType = "search",
  bidding = "max_conversions",
  imageUrls = [],
  videoUrls = [],
});

if (!code.includes(old)) {
  console.log('ERROR: Could not find the exact code to replace. File not changed.');
  process.exit(1);
}

code = code.replace(old, fixed);
fs.writeFileSync(file, code);
console.log('OK: Added imageUrls and videoUrls params to createCampaign');
