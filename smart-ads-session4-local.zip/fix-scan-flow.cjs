const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "app", "routes", "app._index.jsx");
let c = fs.readFileSync(file, "utf8");
let fixes = 0;

// Fix 1: selectPlan should NOT auto-trigger scanning
// Remove setOnboardingPhase("scanning") from both .then() and .catch()
const old1 = `}).then(() => {
      // AUTO-SCAN: After plan saved, trigger scanning phase
      setShowOnboard(false);
      setOnboardingPhase("scanning");
    }).catch(() => {
      // Even if save fails, trigger scanning
      setShowOnboard(false);
      setOnboardingPhase("scanning");
    });`;

const new1 = `}).then(() => {
      setShowOnboard(false);
    }).catch(() => {
      setShowOnboard(false);
    });`;

if (c.includes(old1)) {
  c = c.replace(old1, new1);
  fixes++;
  console.log("✅ Fix 1: selectPlan no longer auto-triggers scanning");
} else {
  console.log("⚠️  Fix 1: pattern not found");
}

// Fix 2: onComplete should just clear onboardingPhase (no page navigation)
const old2 = `onComplete={() => {
              setOnboardingPhase("complete");
              var url = new URL(window.location.href); url.searchParams.delete("preview"); window.location.href = url.toString();
            }}`;

const new2 = `onComplete={() => {
              setOnboardingPhase(null);
              window.location.reload();
            }}`;

if (c.includes(old2)) {
  c = c.replace(old2, new2);
  fixes++;
  console.log("✅ Fix 2: onComplete clears phase and reloads");
} else {
  console.log("⚠️  Fix 2: pattern not found");
}

fs.writeFileSync(file, c, "utf8");
console.log("\nDone:", fixes, "fixes applied");
