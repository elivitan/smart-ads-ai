const fs = require("fs");
const f = "app/routes/app._index.jsx";
let c = fs.readFileSync(f, "utf8");
if (c.includes(") =>const { authenticate }")) {
  c = c.replace(
    ') =>const { authenticate } = await import("../shopify.server"); {',
    ') => { const { authenticate } = await import("../shopify.server");'
  );
  fs.writeFileSync(f, c);
  console.log("FIXED!");
} else {
  console.log("Already fixed or pattern not found");
  let i = c.indexOf("export const loader");
  console.log(c.substring(i, i + 200));
}
