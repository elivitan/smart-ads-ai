const fs = require("fs");
const f = "app/routes/_index/route.jsx";
let c = fs.readFileSync(f, "utf8");
c = c.replace(
  'await import("../shopify.server")',
  'await import("../../shopify.server")'
);
fs.writeFileSync(f, c);
console.log("FIXED!");
