const fs = require("fs");
const path = require("path");

let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  console.log("ERROR: Run from project root");
  process.exit(1);
}

let fixes = 0;

console.log("═══════════════════════════════════════");
console.log("  Smart Ads AI — Extra Protection Layer");
console.log("═══════════════════════════════════════\n");

// ─── 1. Add ErrorBoundary to app._index.jsx ───
console.log("1. Adding ErrorBoundary to dashboard...");
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");
let indexCode = fs.readFileSync(indexPath, "utf-8");
const hooksBefore = (indexCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;

if (!indexCode.includes("export function ErrorBoundary")) {
  const errorBoundaryCode = `

// ── ERROR BOUNDARY — catches React crashes and shows recovery UI ──
export function ErrorBoundary() {
  return (
    <div style={{
      minHeight:"100vh",background:"#0a0a1a",color:"#fff",
      display:"flex",alignItems:"center",justifyContent:"center",
      fontFamily:"Plus Jakarta Sans,system-ui,sans-serif"
    }}>
      <div style={{textAlign:"center",maxWidth:480,padding:"40px 20px"}}>
        <div style={{fontSize:64,marginBottom:20}}>⚠️</div>
        <h1 style={{fontSize:24,fontWeight:800,marginBottom:12}}>Something went wrong</h1>
        <p style={{fontSize:15,color:"rgba(255,255,255,.6)",marginBottom:24}}>
          The dashboard encountered an error. Your data is safe.
        </p>
        <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
          <button onClick={() => window.location.reload()} style={{
            background:"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff",
            border:"none",padding:"12px 24px",borderRadius:10,fontSize:14,
            fontWeight:700,cursor:"pointer"
          }}>Reload Dashboard</button>
          <button onClick={() => { try { sessionStorage.clear(); } catch(e) {} window.location.reload(); }} style={{
            background:"rgba(255,255,255,.08)",color:"rgba(255,255,255,.8)",
            border:"1px solid rgba(255,255,255,.15)",padding:"12px 24px",
            borderRadius:10,fontSize:14,fontWeight:600,cursor:"pointer"
          }}>Clear Cache and Reload</button>
        </div>
      </div>
    </div>
  );
}
`;
  indexCode = indexCode.trimEnd() + "\n" + errorBoundaryCode;
  const hooksAfter = (indexCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  if (hooksAfter !== hooksBefore) {
    console.log("  ABORTED: Hook count changed from " + hooksBefore + " to " + hooksAfter);
    process.exit(1);
  }
  fs.writeFileSync(indexPath, indexCode, "utf-8");
  fixes++;
  console.log("  ADDED: ErrorBoundary (hooks: " + hooksBefore + " unchanged)");
} else {
  console.log("  OK: already exists");
}

// ─── 2. Safe auth for API routes ───
console.log("\n2. Adding safe auth to API routes...");

function addSafeAuth(filePath) {
  const name = path.basename(filePath);
  if (!fs.existsSync(filePath)) { console.log("  SKIP: " + name); return; }
  let code = fs.readFileSync(filePath, "utf-8");
  if (code.includes("catch (authErr)")) { console.log("  OK: " + name); return; }

  // Pattern C: const { admin, session } = await authenticate.admin(request);
  if (code.includes("const { admin, session } = await authenticate.admin(request)")) {
    code = code.replace(
      /const \{ admin, session \} = await authenticate\.admin\(request\);/,
      `let admin, session;
  try {
    ({ admin, session } = await authenticate.admin(request));
  } catch (authErr) {
    console.error("[SmartAds] Auth failed:", authErr.message);
    return Response.json({ success: false, error: "Authentication failed" }, { status: 401 });
  }`
    );
    fs.writeFileSync(filePath, code, "utf-8");
    fixes++;
    console.log("  FIXED: " + name + " (admin+session pattern)");
    return;
  }

  // Pattern B: const { session } = await authenticate.admin(request);
  if (code.includes("const { session } = await authenticate.admin(request)")) {
    code = code.replace(
      /const \{ session \} = await authenticate\.admin\(request\);/,
      `let session;
  try {
    ({ session } = await authenticate.admin(request));
  } catch (authErr) {
    console.error("[SmartAds] Auth failed:", authErr.message);
    return Response.json({ success: false, error: "Authentication failed" }, { status: 401 });
  }`
    );
    fs.writeFileSync(filePath, code, "utf-8");
    fixes++;
    console.log("  FIXED: " + name + " (session pattern)");
    return;
  }

  // Pattern A: await authenticate.admin(request);
  if (code.includes("await authenticate.admin(request);")) {
    code = code.replace(
      /(\s*)await authenticate\.admin\(request\);/,
      `$1try { await authenticate.admin(request); } catch (authErr) { console.error("[SmartAds] Auth failed:", authErr.message); return Response.json({ success: false, error: "Authentication failed" }, { status: 401 }); }`
    );
    fs.writeFileSync(filePath, code, "utf-8");
    fixes++;
    console.log("  FIXED: " + name + " (simple pattern)");
    return;
  }

  console.log("  OK: " + name);
}

const apiFiles = [
  "app/routes/app.api.scan.js",
  "app/routes/app.api.campaign.js",
  "app/routes/app.api.ai-improve.js",
  "app/routes/app.api.subscription.js",
  "app/routes/app.api.sync.js",
  "app/routes/app.api.keywords.js",
  "app/routes/app.api.campaign-manage.js",
  "app/routes/app.api.campaign-status.js",
];
for (const f of apiFiles) addSafeAuth(path.join(ROOT, f));

// ─── 3. Protect loader ───
console.log("\n3. Protecting loader from crashes...");
let loaderCode = fs.readFileSync(indexPath, "utf-8");
if (!loaderCode.includes("catch (loaderErr)")) {
  const lines = loaderCode.split("\n");
  // Find "export const loader" line
  let loaderStartIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes("export const loader = async")) { loaderStartIdx = i; break; }
  }
  if (loaderStartIdx >= 0) {
    // Find the closing "};' of the loader
    let loaderEndIdx = -1;
    let braceDepth = 0;
    for (let i = loaderStartIdx; i < lines.length; i++) {
      for (const ch of lines[i]) {
        if (ch === "{") braceDepth++;
        if (ch === "}") braceDepth--;
      }
      if (braceDepth === 0 && i > loaderStartIdx) { loaderEndIdx = i; break; }
    }
    if (loaderEndIdx > 0) {
      // Insert try after opening brace
      lines.splice(loaderStartIdx + 1, 0, "  try {");
      loaderEndIdx++; // shift because we inserted a line
      // Insert catch before closing
      const catchBlock = `  } catch (loaderErr) {
    console.error("[SmartAds] Loader error:", loaderErr.message);
    return {
      products: [],
      syncStatus: { totalProducts: 0 },
      shop: "",
      planFromCookie: "free",
      isPaidServer: false,
      needsInitialSync: true,
      subscription: { plan: "free", scanCredits: 0, aiCredits: 0, canPublish: false },
    };
  }`;
      lines.splice(loaderEndIdx, 0, catchBlock);
      loaderCode = lines.join("\n");
      
      const hooksCheck = (loaderCode.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
      if (hooksCheck !== hooksBefore) {
        console.log("  ABORTED: Hook count changed!");
        process.exit(1);
      }
      fs.writeFileSync(indexPath, loaderCode, "utf-8");
      fixes++;
      console.log("  ADDED: Loader try-catch");
    }
  }
} else {
  console.log("  OK: already protected");
}

// ─── 4. Env check + preflight ───
console.log("\n4. Creating env validation...");
const envCheck = `const fs=require("fs"),path=require("path"),ROOT=process.cwd();
const env=fs.readFileSync(path.join(ROOT,".env"),"utf-8");
const req=["SHOPIFY_API_KEY","SHOPIFY_API_SECRET","ANTHROPIC_API_KEY"];
const opt=["GOOGLE_ADS_CLIENT_ID","GOOGLE_ADS_CLIENT_SECRET","GOOGLE_ADS_DEVELOPER_TOKEN","GOOGLE_ADS_CUSTOMER_ID","GOOGLE_ADS_REFRESH_TOKEN","SERPAPI_KEY"];
let m=0;
console.log("Env Check:");
req.forEach(k=>{if(env.includes(k+"=")&&!env.match(new RegExp(k+'=\\\\s*$','m'))){console.log("  OK: "+k)}else{console.log("  MISSING: "+k);m++}});
opt.forEach(k=>{if(env.includes(k+"=")){console.log("  OK: "+k)}else{console.log("  optional: "+k)}});
console.log(m>0?"\\nMISSING "+m+" required keys!":"\\nAll required keys present");
`;
fs.writeFileSync(path.join(ROOT, "check-env.cjs"), envCheck, "utf-8");
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf-8"));
pkg.scripts["check-env"] = "node check-env.cjs";
pkg.scripts["preflight"] = "node safety-check.cjs && node validate-hooks.cjs && node check-env.cjs";
fs.writeFileSync(path.join(ROOT, "package.json"), JSON.stringify(pkg, null, 2) + "\n", "utf-8");
fixes++;
console.log("  ADDED: check-env.cjs + npm run preflight");

console.log("\n═══════════════════════════════════════");
console.log("  Total: " + fixes + " protections added");
console.log("═══════════════════════════════════════");
console.log("\n  Run: npm run dev");
