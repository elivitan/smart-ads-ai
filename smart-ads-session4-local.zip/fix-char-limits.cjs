const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) { console.log("ERROR: Run from project root"); process.exit(1); }

let fixes = 0;

console.log("═══ Character Limit Enforcement ═══\n");

// 1. ProductModal — enforce slice in onChange
const pmPath = path.join(ROOT, "app/routes/ProductModal.jsx");
if (fs.existsSync(pmPath)) {
  let pm = fs.readFileSync(pmPath, "utf-8");
  
  // Headlines onChange: add .slice(0,30)
  if (pm.includes("n[i]=e.target.value;setEditHeadlines") && !pm.includes("e.target.value.slice(0,30)")) {
    pm = pm.replace(
      "n[i]=e.target.value;setEditHeadlines(n);",
      "n[i]=e.target.value.slice(0,30);setEditHeadlines(n);"
    );
    fixes++;
    console.log("  FIXED: ProductModal headlines onChange — enforces 30 char limit");
  }
  
  // Descriptions onChange: add .slice(0,90)
  if (pm.includes("n[i]=e.target.value;setEditDescriptions") && !pm.includes("e.target.value.slice(0,90)")) {
    pm = pm.replace(
      "n[i]=e.target.value;setEditDescriptions(n);",
      "n[i]=e.target.value.slice(0,90);setEditDescriptions(n);"
    );
    fixes++;
    console.log("  FIXED: ProductModal descriptions onChange — enforces 90 char limit");
  }
  
  fs.writeFileSync(pmPath, pm, "utf-8");
}

// 2. app._index.jsx — enforce slice when loading from DB and AI improve
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");
if (fs.existsSync(indexPath)) {
  let idx = fs.readFileSync(indexPath, "utf-8");
  const hooksBefore = (idx.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  
  // Loading headlines from DB/AI — add .slice(0,30)
  if (idx.includes('.map(h => typeof h==="string"?h:h.text||h)') && !idx.includes('.map(h => (typeof h==="string"?h:h.text||h).slice(0,30))')) {
    idx = idx.replace(
      '.map(h => typeof h==="string"?h:h.text||h)',
      '.map(h => (typeof h==="string"?h:h.text||h).slice(0,30))'
    );
    fixes++;
    console.log("  FIXED: Headlines load — enforces 30 char limit from DB");
  }
  
  // Loading descriptions from DB/AI — add .slice(0,90)
  if (idx.includes('.map(d => typeof d==="string"?d:d.text||d)') && !idx.includes('.map(d => (typeof d==="string"?d:d.text||d).slice(0,90))')) {
    idx = idx.replace(
      '.map(d => typeof d==="string"?d:d.text||d)',
      '.map(d => (typeof d==="string"?d:d.text||d).slice(0,90))'
    );
    fixes++;
    console.log("  FIXED: Descriptions load — enforces 90 char limit from DB");
  }
  
  // AI improve result — slice headlines
  if (idx.includes('n[index]=data.improved; setEditHeadlines') && !idx.includes('n[index]=data.improved.slice(0,30)')) {
    idx = idx.replace(
      'n[index]=data.improved; setEditHeadlines(n);',
      'n[index]=data.improved.slice(0,30); setEditHeadlines(n);'
    );
    fixes++;
    console.log("  FIXED: AI improve headlines — enforces 30 char limit");
  }
  
  // AI improve result — slice descriptions  
  if (idx.includes('n[index]=data.improved; setEditDescriptions') && !idx.includes('n[index]=data.improved.slice(0,90)')) {
    idx = idx.replace(
      'n[index]=data.improved; setEditDescriptions(n);',
      'n[index]=data.improved.slice(0,90); setEditDescriptions(n);'
    );
    fixes++;
    console.log("  FIXED: AI improve descriptions — enforces 90 char limit");
  }
  
  // Verify hooks unchanged
  const hooksAfter = (idx.match(/\b(useState|useEffect|useMemo|useRef|useCallback)\b/g) || []).length;
  if (hooksAfter !== hooksBefore) {
    console.log("  ⛔ ABORTED: Hook count changed from " + hooksBefore + " to " + hooksAfter);
    process.exit(1);
  }
  console.log("  VERIFIED: Hook count unchanged (" + hooksBefore + ")");
  
  fs.writeFileSync(indexPath, idx, "utf-8");
}

console.log("\n═══ Total fixes: " + fixes + " ═══");
