const fs = require("fs");
const { execSync } = require("child_process");
const f = "app/routes/app._index.jsx";
try {
  const orig = execSync("git show HEAD:" + f, { encoding: "utf8" });
  let c = orig.replace(
    ') =>const { authenticate } = await import("../shopify.server"); {',
    ') => { const { authenticate } = await import("../shopify.server");'
  );
  fs.writeFileSync(f, c);
  console.log("Restored from git and fixed! Length:", c.length);
} catch(e) {
  console.log("Git failed:", e.message);
}
