/**
 * install-store-analytics.cjs
 * ════════════════════════════
 * Patches app._index.jsx to add StoreAnalytics widget
 *
 * Run: node install-store-analytics.cjs
 */

const fs = require("fs");
const path = require("path");

const INDEX = path.join(__dirname, "app", "routes", "app._index.jsx");

const raw = fs.readFileSync(INDEX, "utf-8");
let src = raw.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
const hadCRLF = raw.includes("\r\n");

let changes = 0;

function safeReplace(label, find, replace) {
  if (src.includes(replace.trim().slice(0, 50))) {
    console.log(`  ⚠ ${label}: already applied — skipping`);
    return;
  }
  if (!src.includes(find)) {
    console.error(`  ✗ ${label}: pattern NOT FOUND`);
    return;
  }
  src = src.replace(find, replace);
  changes++;
  console.log(`  ✓ ${label}`);
}

// PATCH 1: Add import
console.log("\n[1/2] Adding StoreAnalytics import...");
safeReplace(
  "Add import",
  `import { MarketAlert } from "./MarketAlert.jsx";`,
  `import { MarketAlert } from "./MarketAlert.jsx";
import { StoreAnalyticsWidget } from "./StoreAnalytics.jsx";`
);

// PATCH 2: Add widget in dashboard — after Market Intelligence, before Competitor Panel
console.log("\n[2/2] Adding StoreAnalytics widget to dashboard...");
safeReplace(
  "Add widget",
  `          {/* MARKET INTELLIGENCE */}
          <MarketAlert shopDomain={shopDomain}/>

          {/* COMPETITOR PANEL */}`,
  `          {/* MARKET INTELLIGENCE */}
          <MarketAlert shopDomain={shopDomain}/>

          {/* STORE PERFORMANCE ANALYTICS */}
          <StoreAnalyticsWidget/>

          {/* COMPETITOR PANEL */}`
);

// WRITE
console.log("\n" + "═".repeat(44));
if (changes > 0) {
  fs.writeFileSync(INDEX, hadCRLF ? src.replace(/\n/g, "\r\n") : src);
  console.log(`✅ ${changes} patches applied.`);
  console.log("Files updated: app/routes/app._index.jsx");
  console.log("\nNew files:");
  console.log("  - app/store-analytics.server.js");
  console.log("  - app/routes/app.api.store-analytics.js");
  console.log("  - app/routes/StoreAnalytics.jsx");
} else {
  console.log("⚠ No changes made.");
}
console.log("═".repeat(44));

// Check scopes
console.log("\n⚠ IMPORTANT: Your app needs 'read_orders' scope!");
console.log("  Add to shopify.app.v.toml under [access_scopes]:");
console.log("    scopes = \"read_products,write_products,read_orders\"");
console.log("  Then restart: shopify app dev\n");
