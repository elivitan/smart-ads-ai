const fs = require("fs");
let s = fs.readFileSync("shopify.app.v.toml", "utf-8");
s = s.replace(
  "scopes = read_products,write_products,read_orders",
  'scopes = "read_products,write_products,read_orders"'
);
s = s.replace(
  /\[access_scopes\]\r?\nscopes = "read_products,write_products,read_orders"\r?\nautomatically_update_urls_on_dev = true/,
  '[access_scopes]\nscopes = "read_products,write_products,read_orders"\n\nautomatically_update_urls_on_dev = true'
);
fs.writeFileSync("shopify.app.v.toml", s);
console.log("Fixed");
