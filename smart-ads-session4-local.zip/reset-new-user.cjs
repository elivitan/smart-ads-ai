/**
 * Reset as New User
 * Deletes subscription + AI analysis data from DB.
 * After running, refresh the app to see the Landing Page.
 */
const fs = require("fs");
const path = require("path");

// Load .env manually
const envPath = path.join(__dirname, ".env");
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf8");
  for (const line of envContent.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx === -1) continue;
    const key = trimmed.substring(0, eqIdx).trim();
    let val = trimmed.substring(eqIdx + 1).trim();
    // Remove surrounding quotes
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!process.env[key]) process.env[key] = val;
  }
  console.log("✅ Loaded .env");
} else {
  console.log("⚠️  No .env found, using existing env vars");
}

const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function reset() {
  console.log("\n🔄 Resetting as new user...\n");

  try {
    // Delete AI analyses
    const ai = await prisma.aiAnalysis.deleteMany({});
    console.log(`  Deleted ${ai.count} AI analyses`);

    // Delete subscriptions
    const subs = await prisma.shopSubscription.deleteMany({});
    console.log(`  Deleted ${subs.count} subscriptions`);

    // Delete campaign jobs
    const jobs = await prisma.campaignJob.deleteMany({});
    console.log(`  Deleted ${jobs.count} campaign jobs`);

    // Delete sync logs
    const logs = await prisma.syncLog.deleteMany({});
    console.log(`  Deleted ${logs.count} sync logs`);

    // Keep products (they'll be re-synced) but show count
    const products = await prisma.product.count();
    console.log(`  Products kept: ${products} (will re-sync from Shopify)`);

    console.log("\n✅ Done! You are now a fresh new user.");
    console.log("   Refresh the app in your browser to see the Landing Page.");
  } catch (e) {
    console.log("\n❌ Error:", e.message);
    if (e.message.includes("Can't reach database")) {
      console.log("   Check your DATABASE_URL in .env");
    }
  } finally {
    await prisma.$disconnect();
  }
}

reset();
