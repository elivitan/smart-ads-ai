const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "app/routes"))) { console.log("ERROR: Run from project root"); process.exit(1); }

const pmPath = path.join(ROOT, "app/routes/ProductModal.jsx");
let code = fs.readFileSync(pmPath, "utf-8");
let fixes = 0;

console.log("=== ProductModal Compliance Fix ===\n");

// 1. Add longHeadlines, recBid, targetDemo extraction
if (!code.includes("longHeadlines")) {
  code = code.replace(
    /const path1 = ai\.path1\|\|"Shop", path2 = ai\.path2\|\|"", negKw = ai\.negative_keywords\|\|\[\];/,
    'const path1 = ai.path1||"Shop", path2 = ai.path2||"", negKw = ai.negative_keywords||[];\n  const longHeadlines = (ai.long_headlines||ai.longHeadlines||[]).map(h => typeof h==="string"?h:(h?.text||"")).filter(Boolean);\n  const recBid = ai.recommended_bid||null;\n  const targetDemo = ai.target_demographics||null;'
  );
  fixes++;
  console.log("  ADDED: longHeadlines, recBid, targetDemo");
}

// 2-6: Use line-by-line approach for all remaining fixes
const lines = code.split("\n");
let strengthFixed = false, badgeFixed = false, longHFixed = false, sliceHFixed = false, sliceDFixed = false;

for (let i = 0; i < lines.length; i++) {
  // 2. Strength bar - add long headlines count
  if (!strengthFixed && lines[i].includes("rsa-strength-info") && lines[i].includes("/4 descriptions") && !lines[i].includes("long headlines")) {
    lines[i] = lines[i].replace('/4 descriptions</span>', '/4 descriptions{longHeadlines.length>0?` \u00b7 ${longHeadlines.length}/5 long headlines`:""}</span>');
    strengthFixed = true; fixes++;
    console.log("  ADDED: long headlines in strength bar");
  }
  
  // 3. Add badges before rsa-preview
  if (!badgeFixed && lines[i].includes('className="rsa-preview"') && lines[i].trim().startsWith('<div')) {
    const indent = lines[i].match(/^(\s*)/)[1];
    lines.splice(i, 0,
      indent + '{(recBid || targetDemo) && <div style={{display:"flex",gap:12,flexWrap:"wrap",marginBottom:16}}>',
      indent + '  {recBid && <div style={{background:"rgba(99,102,241,.1)",border:"1px solid rgba(99,102,241,.2)",borderRadius:10,padding:"8px 14px",fontSize:12}}><span style={{color:"rgba(255,255,255,.5)"}}>Recommended Bid: </span><strong style={{color:"#a5b4fc"}}>${recBid.toFixed(2)}</strong></div>}',
      indent + '  {targetDemo && <div style={{background:"rgba(34,197,94,.08)",border:"1px solid rgba(34,197,94,.15)",borderRadius:10,padding:"8px 14px",fontSize:12}}><span style={{color:"rgba(255,255,255,.5)"}}>Target: </span><strong style={{color:"#86efac"}}>{targetDemo}</strong></div>}',
      indent + '</div>}'
    );
    badgeFixed = true; fixes++; i += 4;
    console.log("  ADDED: Recommended Bid + Target Demographics");
  }
  
  // 4. Add Long Headlines section before Descriptions
  if (!longHFixed && lines[i].includes("Descriptions (") && lines[i].includes("rsa-section-head")) {
    // Find the parent <div className="rsa-section"> 
    let insertAt = i;
    for (let j = i - 1; j >= Math.max(i - 3, 0); j--) {
      if (lines[j].includes("rsa-section")) { insertAt = j; break; }
    }
    const indent = lines[insertAt].match(/^(\s*)/)[1];
    const longLines = [
      indent + '{longHeadlines.length>0 && <div className="rsa-section">',
      indent + '  <div className="rsa-section-head"><h3>Long Headlines ({longHeadlines.length}/5)</h3><span className="rsa-hint">Max 90 chars \u00b7 Performance Max</span></div>',
      indent + '  <div className="rsa-items">{longHeadlines.map((lh,li)=>(',
      indent + '    <div key={li} className="rsa-item rsa-item-desc">',
      indent + '      <span className="rsa-item-num">{li+1}</span>',
      indent + '      <div className="rsa-item-input" style={{background:"rgba(99,102,241,.05)",padding:"8px 10px",borderRadius:8,fontSize:13,color:"rgba(255,255,255,.8)",minHeight:36,display:"flex",alignItems:"center"}}>{lh}</div>',
      indent + '      <span className={"rsa-item-len "+(lh.length>90?"rsa-over":"")}>{lh.length}/90</span>',
      indent + '    </div>',
      indent + '  ))}</div>',
      indent + '</div>}',
    ];
    lines.splice(insertAt, 0, ...longLines);
    longHFixed = true; fixes++; i += longLines.length;
    console.log("  ADDED: Long Headlines section");
  }

  // 5. slice(0,30) for headlines
  if (!sliceHFixed && lines[i].includes("n[i]=e.target.value;setEditHeadlines") && !lines[i].includes("slice(0,30)")) {
    lines[i] = lines[i].replace("n[i]=e.target.value;setEditHeadlines(n);", "n[i]=e.target.value.slice(0,30);setEditHeadlines(n);");
    sliceHFixed = true; fixes++;
    console.log("  ADDED: .slice(0,30) on headlines");
  }

  // 6. slice(0,90) for descriptions
  if (!sliceDFixed && lines[i].includes("n[i]=e.target.value;setEditDescriptions") && !lines[i].includes("slice(0,90)")) {
    lines[i] = lines[i].replace("n[i]=e.target.value;setEditDescriptions(n);", "n[i]=e.target.value.slice(0,90);setEditDescriptions(n);");
    sliceDFixed = true; fixes++;
    console.log("  ADDED: .slice(0,90) on descriptions");
  }
}

code = lines.join("\n");
fs.writeFileSync(pmPath, code, "utf-8");
console.log("\nTotal fixes: " + fixes);
