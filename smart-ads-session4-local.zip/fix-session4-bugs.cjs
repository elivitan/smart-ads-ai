/**
 * Session 4 — Bug Fix Patch
 * 
 * Fixes found during deep code review:
 * 
 * BUG 1 (CRITICAL): package.json — react-router override 7.13.1 conflicts with dep ^7.12.0
 *                    → npm install fails completely
 *                    FIX: Change dep to match override (7.13.1)
 * 
 * BUG 2 (CRITICAL): package.json — setup script still uses "prisma migrate deploy"
 *                    → Shopify CLI deploy will fail
 *                    FIX: Change to "prisma generate && prisma db push"
 * 
 * BUG 3 (CRITICAL): prisma/schema.prisma — still SQLite, should be PostgreSQL
 *                    → All Prisma CLI commands use wrong DB
 *                    FIX: Copy root schema.prisma to prisma/schema.prisma
 * 
 * BUG 4 (CRITICAL): app._index.jsx:115 — POST /app/api/sync without "step" param
 *                    → Returns 400 "Unknown step", initial sync never works
 *                    FIX: Send FormData with step="full_sync"
 * 
 * BUG 5 (COSMETIC): SmallComponents.jsx — double semicolons ;; on lines 66, 89
 *                    FIX: Remove extra semicolons
 * 
 * BUG 6 (COSMETIC): app._index.jsx — ModalScrollLock imported but never used
 *                    FIX: Remove from import
 */

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
let fixCount = 0;
let errorCount = 0;

function fixFile(filePath, description, replacements) {
  const fullPath = path.join(ROOT, filePath);
  try {
    let content = fs.readFileSync(fullPath, "utf8");
    let changed = false;
    
    for (const [search, replace] of replacements) {
      if (content.includes(search)) {
        content = content.replace(search, replace);
        changed = true;
      } else {
        console.log(`  ⚠️  Pattern not found in ${filePath}: "${search.substring(0, 60)}..."`);
      }
    }
    
    if (changed) {
      fs.writeFileSync(fullPath, content, "utf8");
      fixCount++;
      console.log(`✅ FIX ${fixCount}: ${description}`);
      console.log(`   File: ${filePath}`);
    } else {
      console.log(`⏭️  SKIP: ${description} — already fixed or pattern not found`);
    }
  } catch (err) {
    errorCount++;
    console.log(`❌ ERROR: ${description} — ${err.message}`);
  }
}

console.log("═══════════════════════════════════════════");
console.log("  Smart Ads AI — Session 4 Bug Fix Patch");
console.log("═══════════════════════════════════════════\n");

// ── BUG 1: package.json — react-router version conflict ──
fixFile("package.json", "react-router version conflict (dep ^7.12.0 vs override 7.13.1)", [
  ['"react-router": "^7.12.0"', '"react-router": "7.13.1"'],
]);

// ── BUG 2: package.json — setup script uses migrate deploy instead of db push ──
fixFile("package.json", "setup script: migrate deploy → db push", [
  ['"setup": "prisma generate && prisma migrate deploy"', '"setup": "prisma generate && prisma db push"'],
]);

// ── BUG 3: prisma/schema.prisma — copy from root (PostgreSQL version) ──
try {
  const rootSchema = fs.readFileSync(path.join(ROOT, "schema.prisma"), "utf8");
  const prismaSchema = fs.readFileSync(path.join(ROOT, "prisma", "schema.prisma"), "utf8");
  
  if (rootSchema.includes("postgresql") && prismaSchema.includes("sqlite")) {
    fs.writeFileSync(path.join(ROOT, "prisma", "schema.prisma"), rootSchema, "utf8");
    fixCount++;
    console.log(`✅ FIX ${fixCount}: prisma/schema.prisma — replaced SQLite with PostgreSQL (copied from root)`);
    console.log(`   File: prisma/schema.prisma`);
  } else if (prismaSchema.includes("postgresql")) {
    console.log(`⏭️  SKIP: prisma/schema.prisma — already PostgreSQL`);
  } else {
    console.log(`⚠️  UNEXPECTED: prisma/schema.prisma doesn't match expected patterns`);
  }
} catch (err) {
  errorCount++;
  console.log(`❌ ERROR: prisma/schema.prisma copy — ${err.message}`);
}

// ── BUG 4: app._index.jsx — initial sync POST without step param ──
fixFile("app/routes/app._index.jsx", "initial sync: add step=full_sync to POST body", [
  [
    `  useEffect(() => {
    if (needsInitialSync) {
      fetch("/app/api/sync", { method: "POST" })
        .catch(() => {}); // silent — UI will update via webhook
    }
  }, [needsInitialSync]);`,
    `  useEffect(() => {
    if (needsInitialSync) {
      const form = new FormData();
      form.append("step", "full_sync");
      fetch("/app/api/sync", { method: "POST", body: form })
        .catch(() => {}); // silent — UI will update via webhook
    }
  }, [needsInitialSync]);`
  ],
]);

// ── BUG 5: SmallComponents.jsx — double semicolons ──
fixFile("app/routes/SmallComponents.jsx", "remove double semicolons (;;)", [
  [
    `30%"];;`,
    `30%"];`
  ],
  [
    `ago", emoji:"📈" },\n];;`,
    `ago", emoji:"📈" },\n];`
  ],
]);

// ── BUG 6: app._index.jsx — unused ModalScrollLock import ──
fixFile("app/routes/app._index.jsx", "remove unused ModalScrollLock import", [
  [
    `import { Counter, ScoreRing, Speedometer, TipRotator, Confetti, SuccessTicker, ModalScrollLock } from "./SmallComponents.jsx";`,
    `import { Counter, ScoreRing, Speedometer, TipRotator, Confetti, SuccessTicker } from "./SmallComponents.jsx";`
  ],
]);

// ── SUMMARY ──
console.log("\n═══════════════════════════════════════════");
console.log(`  Done: ${fixCount} fixes applied, ${errorCount} errors`);
console.log("═══════════════════════════════════════════");

if (errorCount > 0) {
  console.log("\n⚠️  Some fixes failed — check output above.");
  process.exit(1);
}

// ── VERIFICATION ──
console.log("\n🔍 Verifying fixes...\n");

// Verify 1: package.json
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const depVer = pkg.dependencies["react-router"];
const overrideVer = pkg.overrides["react-router"];
const setupScript = pkg.scripts.setup;
console.log(`  react-router dep: ${depVer} | override: ${overrideVer} | ${depVer === overrideVer ? "✅ match" : "❌ MISMATCH"}`);
console.log(`  setup script: ${setupScript} | ${setupScript.includes("db push") ? "✅ db push" : "❌ still migrate deploy"}`);

// Verify 2: prisma/schema.prisma
const prismaContent = fs.readFileSync(path.join(ROOT, "prisma", "schema.prisma"), "utf8");
console.log(`  prisma/schema.prisma: ${prismaContent.includes("postgresql") ? "✅ PostgreSQL" : "❌ NOT PostgreSQL"}`);
console.log(`  prisma/schema.prisma directUrl: ${prismaContent.includes("directUrl") ? "✅ present" : "❌ missing"}`);

// Verify 3: initial sync
const indexContent = fs.readFileSync(path.join(ROOT, "app", "routes", "app._index.jsx"), "utf8");
console.log(`  initial sync step: ${indexContent.includes('form.append("step", "full_sync")') ? "✅ has step=full_sync" : "❌ missing step"}`);

// Verify 4: double semicolons
const smallComp = fs.readFileSync(path.join(ROOT, "app", "routes", "SmallComponents.jsx"), "utf8");
const dblSemicolons = (smallComp.match(/;;/g) || []).length;
console.log(`  SmallComponents.jsx double semicolons: ${dblSemicolons === 0 ? "✅ none" : "❌ " + dblSemicolons + " found"}`);

// Verify 5: unused import
console.log(`  ModalScrollLock import: ${indexContent.includes("ModalScrollLock") ? "❌ still imported" : "✅ removed"}`);

console.log("\n✨ All verifications complete.");
