const fs = require("fs");
const { execSync } = require("child_process");
const f = "app/routes/app._index.jsx";
let c = execSync("git show HEAD:" + f, { encoding: "utf8" });
c = c.replace(
  ') =>const { authenticate } = await import("../shopify.server"); {',
  ') => { const { authenticate } = await import("../shopify.server");'
);
c = c.replace(
  'ProductModal.jsx"; // Cookie helper',
  'ProductModal.jsx";\n// Cookie helper'
);
c = c.replace(
  'catch { return null; } }   // ',
  'catch { return null; } }\n// '
);
c = c.replace(
  'CSS}}/> ; }  export const loader',
  'CSS}}/> ; }\n\nexport const loader'
);
c = c.replace(
  '}; };  const FREE_SCAN_LIMIT',
  '};\n};\n\nconst FREE_SCAN_LIMIT'
);
c = c.replace(
  '  export default function Index()',
  '\n\nexport default function Index()'
);
let opens = (c.match(/{/g)||[]).length;
let closes = (c.match(/}/g)||[]).length;
let lines = c.split("\n");
console.log("Braces:", opens, closes, "diff:", opens-closes);
console.log("Lines:", lines.length);
for (let i = 0; i < lines.length; i++) {
  let s = lines[i].substring(0,60);
  if (s.includes("getPlanFromCookie") || s.includes("StyleTag") || s.includes("export const loader") || s.includes("export default")) {
    console.log("L" + (i+1) + " (" + lines[i].length + "):", s);
  }
}
fs.writeFileSync(f, c);
console.log("DONE!");
