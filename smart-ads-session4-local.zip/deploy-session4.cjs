/**
 * Session 4 — Full Deploy Script
 * 
 * The original patch script only fixed package.json, prisma/schema.prisma,
 * and SmallComponents.jsx — those were already applied.
 * 
 * But app._index.jsx still has the OLD version from the zip (with mock data,
 * no onboarding flow, no hasGoogleAds guards, broken initial sync).
 * 
 * This script replaces app._index.jsx with the fully fixed version that includes:
 * 1. useGoogleAdsData() returns nulls instead of mock data
 * 2. hasGoogleAds guards on all dashboard metrics
 * 3. onboardingPhase state + auto-scan after selectPlan()
 * 4. Initial sync with step=full_sync
 * 5. Product cards show real AI data (score/keywords/strategy) not fake impressions
 * 6. realCampaigns instead of mockCampaigns
 * 7. ModalScrollLock removed from import
 * 
 * Also fixes SmallComponents.jsx double semicolons (if not already fixed).
 */

const fs = require("fs");
const path = require("path");
const https = require("https");

const ROOT = __dirname;

console.log("═══════════════════════════════════════════");
console.log("  Smart Ads AI — Session 4 Full Deploy");
console.log("═══════════════════════════════════════════\n");

// Verify we're in the right directory
if (!fs.existsSync(path.join(ROOT, "app", "routes", "app._index.jsx"))) {
  console.log("❌ ERROR: app/routes/app._index.jsx not found!");
  console.log("   Make sure you're running from: C:\\Users\\אלי\\smart-ads-ai-backup");
  process.exit(1);
}

// ── Step 1: Read the bundled fixed file ──
const FIXED_FILE_PATH = path.join(ROOT, "app._index.fixed.jsx");
const TARGET_PATH = path.join(ROOT, "app", "routes", "app._index.jsx");
const BACKUP_PATH = path.join(ROOT, "app", "routes", "app._index.jsx.bak");

// The fixed file content is embedded in this script as a separate file
// We'll read it from app._index.fixed.jsx (placed alongside this script)

if (!fs.existsSync(FIXED_FILE_PATH)) {
  console.log("❌ ERROR: app._index.fixed.jsx not found next to this script!");
  console.log("   Make sure both files are in: C:\\Users\\אלי\\smart-ads-ai-backup");
  console.log("   - deploy-session4.cjs");
  console.log("   - app._index.fixed.jsx");
  process.exit(1);
}

// ── Step 2: Backup current file ──
try {
  fs.copyFileSync(TARGET_PATH, BACKUP_PATH);
  console.log("✅ Backup created: app/routes/app._index.jsx.bak");
} catch (e) {
  console.log("⚠️  Could not create backup:", e.message);
}

// ── Step 3: Read fixed file and convert to Windows line endings ──
let fixedContent = fs.readFileSync(FIXED_FILE_PATH, "utf8");

// Normalize to \n first, then convert to \r\n for Windows
fixedContent = fixedContent.replace(/\r\n/g, "\n").replace(/\n/g, "\r\n");

fs.writeFileSync(TARGET_PATH, fixedContent, "utf8");
console.log("✅ app/routes/app._index.jsx replaced with fixed version");

// ── Step 4: Fix SmallComponents.jsx double semicolons ──
const scPath = path.join(ROOT, "app", "routes", "SmallComponents.jsx");
try {
  let sc = fs.readFileSync(scPath, "utf8");
  const before = (sc.match(/;;/g) || []).length;
  if (before > 0) {
    sc = sc.replace(/;;\s*$/gm, ";");
    // Also handle ;; not at end of line
    sc = sc.replace(/];;/g, "];");
    fs.writeFileSync(scPath, sc, "utf8");
    console.log(`✅ SmallComponents.jsx: removed ${before} double semicolons`);
  } else {
    console.log("⏭️  SmallComponents.jsx: no double semicolons found");
  }
} catch (e) {
  console.log("⚠️  SmallComponents.jsx fix failed:", e.message);
}

// ── Step 5: Verify everything ──
console.log("\n🔍 Verifying...\n");

const final = fs.readFileSync(TARGET_PATH, "utf8");
const checks = [
  ["Lines", final.split("\n").length + " (should be ~1303)"],
  ["buildMockData removed", !final.includes("buildMockData") ? "✅" : "❌ still present"],
  ["onboardingPhase added", final.includes("onboardingPhase") ? "✅" : "❌ missing"],
  ["hasGoogleAds guards", final.includes("hasGoogleAds") ? "✅" : "❌ missing"],
  ["full_sync step", final.includes("full_sync") ? "✅" : "❌ missing"],
  ["ModalScrollLock removed", !final.includes("ModalScrollLock") ? "✅" : "❌ still present"],
  ["realCampaigns", final.includes("realCampaigns") ? "✅" : "❌ missing"],
  ["useGoogleAdsData() no params", final.includes("useGoogleAdsData()") ? "✅" : "❌"],
  ["selectPlan triggers scanning", final.includes("setOnboardingPhase") ? "✅" : "❌ missing"],
  ["Product cards: kwCount", final.includes("kwCount") ? "✅" : "❌ missing"],
  ["Product cards: strategy", final.includes("ai.competitor_intel?.strategy") ? "✅" : "❌ missing"],
  ["export default function", final.includes("export default function Index()") ? "✅" : "❌"],
  ["ErrorBoundary", final.includes("export function ErrorBoundary()") ? "✅" : "❌"],
];

let allGood = true;
for (const [label, result] of checks) {
  console.log(`  ${label}: ${result}`);
  if (String(result).includes("❌")) allGood = false;
}

// Also check package.json and prisma
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
console.log(`  package.json react-router: ${pkg.dependencies["react-router"]} = ${pkg.overrides["react-router"]} ${pkg.dependencies["react-router"] === pkg.overrides["react-router"] ? "✅" : "❌"}`);
console.log(`  package.json setup: ${pkg.scripts.setup.includes("db push") ? "✅ db push" : "❌ wrong"}`);

const prismaSchema = fs.readFileSync(path.join(ROOT, "prisma", "schema.prisma"), "utf8");
console.log(`  prisma/schema.prisma: ${prismaSchema.includes("postgresql") ? "✅ PostgreSQL" : "❌ wrong"}`);

console.log("\n═══════════════════════════════════════════");
if (allGood) {
  console.log("  ✅ All checks passed! Deploy complete.");
} else {
  console.log("  ⚠️  Some checks failed — review output above.");
}
console.log("═══════════════════════════════════════════");
