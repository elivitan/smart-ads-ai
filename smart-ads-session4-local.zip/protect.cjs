const fs = require("fs");
const path = require("path");

let ROOT = process.cwd();
if (!fs.existsSync(path.join(ROOT, "package.json"))) {
  console.log("ERROR: package.json not found. Run from project root.");
  process.exit(1);
}
if (!fs.existsSync(path.join(ROOT, "app/routes"))) {
  console.log("ERROR: Run from project root");
  process.exit(1);
}

console.log("═══════════════════════════════════════");
console.log("  Smart Ads AI — Protection Setup");
console.log("═══════════════════════════════════════\n");

// ─── 1. Lock npm versions to prevent auto-updates ───
console.log("1. Locking package versions...");
const pkgPath = path.join(ROOT, "package.json");
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));

// Add engine lock and exact versions
if (!pkg.engines) pkg.engines = {};
pkg.engines.node = ">=18.0.0";

// Add overrides to prevent react-router from auto-updating
if (!pkg.overrides) pkg.overrides = {};
// Read current react-router version from lock file or node_modules
const rrPkgPath = path.join(ROOT, "node_modules/react-router/package.json");
if (fs.existsSync(rrPkgPath)) {
  const rrVersion = JSON.parse(fs.readFileSync(rrPkgPath, "utf-8")).version;
  pkg.overrides["react-router"] = rrVersion;
  console.log("  Locked react-router to " + rrVersion);
}

// Save-exact so future npm install --save uses exact versions
if (!pkg.config) pkg.config = {};

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf-8");
console.log("  DONE: package.json updated");

// ─── 2. Create .npmrc to enforce exact versions ───
console.log("\n2. Creating .npmrc for exact versions...");
const npmrcPath = path.join(ROOT, ".npmrc");
let npmrc = fs.existsSync(npmrcPath) ? fs.readFileSync(npmrcPath, "utf-8") : "";
if (!npmrc.includes("save-exact")) {
  npmrc += "\nsave-exact=true\n";
  fs.writeFileSync(npmrcPath, npmrc, "utf-8");
  console.log("  DONE: .npmrc created with save-exact=true");
} else {
  console.log("  OK: already set");
}

// ─── 3. Create hooks validation script ───
console.log("\n3. Creating hooks validation script...");
const validateScript = `const fs = require("fs");
const path = require("path");
const ROOT = process.cwd();
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");

if (!fs.existsSync(indexPath)) {
  console.log("app._index.jsx not found");
  process.exit(1);
}

const code = fs.readFileSync(indexPath, "utf-8");
const lines = code.split("\\n");

// Count hooks
const hookPattern = /\\b(useState|useEffect|useMemo|useRef|useCallback|useReducer)\\b/;
let hookCount = 0;
let lastHookLine = 0;
let firstReturnLine = 0;
let hooksAfterReturn = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i].trim();
  
  // Skip comments
  if (line.startsWith("//") || line.startsWith("*")) continue;
  
  // Track hooks
  if (hookPattern.test(line) && !line.includes("import")) {
    hookCount++;
    lastHookLine = i + 1;
    if (firstReturnLine > 0) {
      hooksAfterReturn.push({ line: i + 1, code: line.substring(0, 80) });
    }
  }
  
  // Track early returns (but not inside functions)
  if ((line.startsWith("if (") || line.startsWith("if(")) && line.includes("return (") && firstReturnLine === 0) {
    firstReturnLine = i + 1;
  }
}

console.log("═══════════════════════════════════════");
console.log("  Hooks Validation Report");
console.log("═══════════════════════════════════════");
console.log("  Total hooks found: " + hookCount);
console.log("  Last hook at line: " + lastHookLine);
console.log("  First early return: " + firstReturnLine);

if (hooksAfterReturn.length > 0) {
  console.log("\\n  ⛔ DANGER: " + hooksAfterReturn.length + " hook(s) AFTER early return!");
  console.log("  This WILL crash with 'Rendered more hooks'\\n");
  hooksAfterReturn.forEach(h => {
    console.log("    Line " + h.line + ": " + h.code);
  });
  process.exit(1);
} else {
  console.log("\\n  ✅ All hooks are before early returns - SAFE");
}

// Save hook count for future comparison
const countFile = path.join(ROOT, ".hooks-count");
const savedCount = fs.existsSync(countFile) ? parseInt(fs.readFileSync(countFile, "utf-8")) : 0;
if (savedCount > 0 && hookCount !== savedCount) {
  console.log("\\n  ⚠️  Hook count changed: " + savedCount + " → " + hookCount);
  console.log("  Make sure new hooks are before line " + firstReturnLine);
}
fs.writeFileSync(countFile, String(hookCount), "utf-8");
console.log("  Hook count saved: " + hookCount);
`;
fs.writeFileSync(path.join(ROOT, "validate-hooks.cjs"), validateScript, "utf-8");
console.log("  DONE: validate-hooks.cjs created");

// ─── 4. Create pre-change checklist script ───
console.log("\n4. Creating safety check script...");
const safetyScript = `const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const ROOT = process.cwd();

console.log("═══════════════════════════════════════");
console.log("  Pre-Change Safety Check");
console.log("═══════════════════════════════════════\\n");

let issues = 0;

// 1. Check git status
try {
  const status = execSync("git status --porcelain", { cwd: ROOT, encoding: "utf-8" });
  if (status.trim()) {
    console.log("  ⚠️  Uncommitted changes detected!");
    console.log("  Run: git add -A && git commit -m \\"save before change\\"");
    issues++;
  } else {
    console.log("  ✅ Git: clean state");
  }
} catch {
  console.log("  ⚠️  Git not initialized");
  issues++;
}

// 2. Check hooks
try {
  execSync("node validate-hooks.cjs", { cwd: ROOT, stdio: "pipe" });
  console.log("  ✅ Hooks: valid");
} catch {
  console.log("  ⛔ Hooks: INVALID - fix before making changes!");
  issues++;
}

// 3. Check for .bak files in routes
const routesDir = path.join(ROOT, "app/routes");
const bakFiles = fs.readdirSync(routesDir).filter(f => f.includes(".bak") || f.includes(".broken"));
if (bakFiles.length > 0) {
  console.log("  ⚠️  Cleanup needed: " + bakFiles.length + " backup files in routes/");
  bakFiles.forEach(f => console.log("    - " + f));
  issues++;
} else {
  console.log("  ✅ Routes: clean");
}

// 4. Check key files exist
const required = [
  "app/routes/app._index.jsx",
  "app/routes/styles.index.js",
  "app/routes/SmallComponents.jsx",
  "app/routes/DashboardWidgets.jsx",
  "app/routes/CollectingDataScreen.jsx",
  "app/routes/CompetitorComponents.jsx",
  "app/routes/AdPreviewPanel.jsx",
  "app/routes/LandingComponents.jsx",
  "app/routes/ProductModal.jsx",
];
const missing = required.filter(f => !fs.existsSync(path.join(ROOT, f)));
if (missing.length > 0) {
  console.log("  ⛔ Missing files: " + missing.join(", "));
  issues++;
} else {
  console.log("  ✅ Files: all present");
}

console.log("\\n" + (issues === 0 ? "  ✅ ALL CLEAR - safe to make changes" : "  ⚠️  " + issues + " issue(s) found - fix before changing code"));
`;
fs.writeFileSync(path.join(ROOT, "safety-check.cjs"), safetyScript, "utf-8");
console.log("  DONE: safety-check.cjs created");

// ─── 5. Update .gitignore ───
console.log("\n5. Updating .gitignore...");
const giPath = path.join(ROOT, ".gitignore");
let gi = fs.existsSync(giPath) ? fs.readFileSync(giPath, "utf-8") : "";
const additions = ["*.bak_*", "*.broken*", "*.pre-deploy*", "fix*.cjs", "deploy-fix/", "api-restore/", "routes-restore/", "routes/", ".hooks-count"];
let added = 0;
for (const entry of additions) {
  if (!gi.includes(entry)) { gi += "\n" + entry; added++; }
}
if (added > 0) {
  fs.writeFileSync(giPath, gi, "utf-8");
  console.log("  DONE: " + added + " entries added");
} else {
  console.log("  OK: already up to date");
}

// ─── 6. Add npm scripts ───
console.log("\n6. Adding npm scripts...");
const pkg2 = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
pkg2.scripts = pkg2.scripts || {};
pkg2.scripts["validate"] = "node validate-hooks.cjs";
pkg2.scripts["safety"] = "node safety-check.cjs";
pkg2.scripts["save"] = "git add -A && git commit -m";
fs.writeFileSync(pkgPath, JSON.stringify(pkg2, null, 2) + "\n", "utf-8");
console.log("  DONE: Added 'validate', 'safety', 'save' scripts");

// ─── 7. Run initial hook count ───
console.log("\n7. Running initial hooks validation...");
const indexPath = path.join(ROOT, "app/routes/app._index.jsx");
if (fs.existsSync(indexPath)) {
  const code = fs.readFileSync(indexPath, "utf-8");
  const hookPattern = /\b(useState|useEffect|useMemo|useRef|useCallback|useReducer)\b/;
  let hookCount = 0;
  code.split("\n").forEach(line => {
    if (!line.trim().startsWith("//") && !line.trim().startsWith("import") && hookPattern.test(line)) hookCount++;
  });
  fs.writeFileSync(path.join(ROOT, ".hooks-count"), String(hookCount), "utf-8");
  console.log("  Baseline hook count: " + hookCount);
}

console.log("\n═══════════════════════════════════════");
console.log("  Protection Setup Complete!");
console.log("═══════════════════════════════════════");
console.log("\n  New commands available:");
console.log("    npm run safety    — Run before making changes");
console.log("    npm run validate  — Check hooks are safe");
console.log("    npm run save \"description\"  — Quick git save");
console.log("\n  Workflow:");
console.log("    1. npm run safety");
console.log("    2. Make your change");
console.log("    3. npm run dev (test)");
console.log("    4. npm run save \"what I changed\"");
