const fs = require("fs");
const path = require("path");

const routesDir = path.join(process.cwd(), "app", "routes");

function walk(dir) {
  const files = fs.readdirSync(dir);

  for (const file of files) {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);

    if (stat.isDirectory()) {
      walk(full);
      continue;
    }

    if (!file.includes("webhooks")) continue;

    let code = fs.readFileSync(full, "utf8");

    if (code.split("\n").length < 5) {
      code = code.replace(/;/g, ";\n");
    }

    if (code.includes("json(") && !code.includes("@remix-run/node")) {
      code = `import { json } from "@remix-run/node";\n` + code;
    }

    fs.writeFileSync(full, code);

    console.log("fixed:", file);
  }
}

walk(routesDir);

console.log("✓ all webhook files repaired");