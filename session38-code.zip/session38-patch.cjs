// session38-patch.cjs
// ════════════════════════════════════════════════════════════════
// Session 38: Rate Limiting + Full Zod Validation + Logger Replacement
// ONE script to rule them all.
//
// What it does:
// 1. Copies rate-limiter.js to app/utils/
// 2. Adds rate limiting to ALL app.api.* routes
// 3. Adds full Zod schemas to scan, campaign, subscription
// 4. Replaces ALL console.error/log/warn with logger calls in API routes
// 5. Updates preflight.cjs with 2 new checks
// ════════════════════════════════════════════════════════════════

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const ROUTES = path.join(ROOT, "app", "routes");
const UTILS = path.join(ROOT, "app", "utils");

let totalChanges = 0;
let errors = [];

function log(msg) { console.log(`  ✅ ${msg}`); totalChanges++; }
function err(msg) { console.log(`  ❌ ${msg}`); errors.push(msg); }

// ── Helper: normalize CRLF → LF ──
function normalizeLF(str) { return str.replace(/\r\n/g, "\n").replace(/\r/g, "\n"); }

// ── Helper: safe replace (verifies uniqueness) ──
function safeReplace(content, oldStr, newStr, label) {
  const count = content.split(oldStr).length - 1;
  if (count === 0) { err(`${label}: target string NOT FOUND`); return content; }
  if (count > 1) { err(`${label}: target string found ${count} times (not unique)`); return content; }
  log(label);
  return content.replace(oldStr, newStr);
}

console.log("═══════════════════════════════════════════════════");
console.log("  Session 38 — Rate Limiting & API Hardening");
console.log("═══════════════════════════════════════════════════\n");

// ════════════════════════════════════════════
// STEP 1: Copy rate-limiter.js
// ════════════════════════════════════════════
console.log("📦 STEP 1: Install rate-limiter.js\n");

if (!fs.existsSync(UTILS)) fs.mkdirSync(UTILS, { recursive: true });

// Check if rate-limiter.js exists in same dir as this script
const rlSource = path.join(__dirname, "rate-limiter.js");
const rlDest = path.join(UTILS, "rate-limiter.js");

if (fs.existsSync(rlSource)) {
  fs.copyFileSync(rlSource, rlDest);
  log("Copied rate-limiter.js → app/utils/rate-limiter.js");
} else if (fs.existsSync(rlDest)) {
  log("rate-limiter.js already in app/utils/");
} else {
  err("rate-limiter.js not found! Place it next to this script.");
}

// ════════════════════════════════════════════
// STEP 2: Patch app.api.state.js
// Already has Zod + logger. Just add rate limiting.
// ════════════════════════════════════════════
console.log("\n📦 STEP 2: Patch app.api.state.js (rate limiting)\n");

{
  const file = path.join(ROUTES, "app.api.state.js");
  if (!fs.existsSync(file)) { err("app.api.state.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "state.js: Added rate-limiter import"
    );

    // Add rate limit check to loader (GET)
    c = safeReplace(c,
      '    const state = await prisma.userState.findUnique({ where: { shop } });',
      '    // Rate limit check\n    const rl = rateLimit.state(shop);\n    if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n    const state = await prisma.userState.findUnique({ where: { shop } });',
      "state.js: Added rate limit to GET"
    );

    // Add rate limit check to action (POST) — after auth, before content-length
    c = safeReplace(c,
      '    // Request size check (100KB limit)',
      '    // Rate limit check\n    const rl = rateLimit.state(shop);\n    if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n    // Request size check (100KB limit)',
      "state.js: Added rate limit to POST"
    );

    // Normalize CRLF → LF
    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 3: Patch app.api.scan.js
// Add: rate limiting, full Zod, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 3: Patch app.api.scan.js\n");

{
  const file = path.join(ROUTES, "app.api.scan.js");
  if (!fs.existsSync(file)) { err("app.api.scan.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "scan.js: Added rate-limiter import"
    );

    // Replace all console.log in saveAiResultsToDB
    c = safeReplace(c,
      '  console.log("[SmartAds] saveAiResultsToDB called:", products.length, "products,", aiProducts.length, "AI results");',
      '  logger.info("scan.saveDB", "saveAiResultsToDB called", { extra: { productCount: products.length, aiCount: aiProducts.length } });',
      "scan.js: Replace console.log #1"
    );
    c = safeReplace(c,
      '  console.log("[SmartAds] Product IDs:", products.map(p => p.id).slice(0,3));',
      '  logger.info("scan.saveDB", "Product IDs sample", { extra: { ids: products.map(p => p.id).slice(0,3) } });',
      "scan.js: Replace console.log #2"
    );
    c = safeReplace(c,
      '  console.log("[SmartAds] AI titles:", aiProducts.map(p => p.title).slice(0,3));',
      '  logger.info("scan.saveDB", "AI titles sample", { extra: { titles: aiProducts.map(p => p.title).slice(0,3) } });',
      "scan.js: Replace console.log #3"
    );
    c = safeReplace(c,
      '    console.log("[SmartAds] Match attempt:", aiProduct.title, "-> found:", sourceProduct?.title, "id:", sourceProduct?.id);',
      '    logger.info("scan.saveDB", "Match attempt", { extra: { aiTitle: aiProduct.title, matched: sourceProduct?.title, id: sourceProduct?.id } });',
      "scan.js: Replace console.log #4"
    );
    c = safeReplace(c,
      '      console.error(`[SmartAds] Failed to save AI analysis for ${productId}:`, err.message);',
      '      logger.error("scan.saveDB", `Failed to save AI analysis for ${productId}`, { error: err.message });',
      "scan.js: Replace console.error in saveAiResultsToDB"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[SmartAds] Auth failed:", authErr.message);',
      '    logger.error("scan.action", "Auth failed", { error: authErr.message });',
      "scan.js: Replace auth console.error"
    );

    // Replace console.log in product save loop
    c = safeReplace(c,
      '        } catch (err) { console.log("[SmartAds] Failed to save product:", p.id, err.message); }',
      '        } catch (err) { logger.warn("scan.fetch", "Failed to save product", { extra: { id: p.id, error: err.message } }); }',
      "scan.js: Replace product save console.log"
    );
    c = safeReplace(c,
      '      console.log("[SmartAds] Saved", products.length, "products to DB");',
      '      logger.info("scan.fetch", "Saved products to DB", { shop, extra: { count: products.length } });',
      "scan.js: Replace saved products console.log"
    );

    // Replace analyze-batch console.log
    c = safeReplace(c,
      '      console.log(`[SmartAds] Saved ${savedCount}/${aiProducts.length} AI analyses to DB for ${shop}`);',
      '      logger.info("scan.analyze-batch", "AI analyses saved to DB", { shop, extra: { saved: savedCount, total: aiProducts.length } });',
      "scan.js: Replace analyze-batch console.log"
    );

    // Replace analyze console.log
    c = safeReplace(c,
      '      console.log(`[SmartAds] Saved ${savedCount} AI analyses to DB for ${shop}`);',
      '      logger.info("scan.analyze", "AI analyses saved to DB", { shop, extra: { saved: savedCount } });',
      "scan.js: Replace analyze console.log"
    );

    // Replace final catch console.error
    c = safeReplace(c,
      '    console.error("Scan error:", err);',
      '    logger.error("scan.action", "Scan error", { shop, error: err.message });',
      "scan.js: Replace final catch console.error"
    );

    // Add rate limit check after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n  const formData = await request.formData();',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.scan(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  const formData = await request.formData();',
      "scan.js: Added rate limit check"
    );

    // Add Zod schema for step validation
    // Insert after the rate-limiter import line
    c = safeReplace(c,
      'import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      'import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";\n\n// Zod schemas\nconst ScanStepSchema = z.enum(["fetch", "analyze-batch", "analyze"]);\nconst MAX_BODY_SIZE = 102400; // 100KB',
      "scan.js: Added Zod schemas"
    );

    // Add step validation after formData
    c = safeReplace(c,
      '  const step = formData.get("step");\n\n  try {',
      '  const step = formData.get("step");\n\n  // Validate step\n  const stepCheck = ScanStepSchema.safeParse(step);\n  if (!stepCheck.success) {\n    return Response.json({ success: false, error: "Invalid step. Must be: fetch, analyze-batch, or analyze" }, { status: 400 });\n  }\n\n  try {',
      "scan.js: Added step Zod validation"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 4: Patch app.api.campaign.js
// Add: rate limiting, full Zod, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 4: Patch app.api.campaign.js\n");

{
  const file = path.join(ROUTES, "app.api.campaign.js");
  if (!fs.existsSync(file)) { err("app.api.campaign.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "campaign.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[SmartAds] Auth failed:", authErr.message);',
      '    logger.error("campaign.action", "Auth failed", { error: authErr.message });',
      "campaign.js: Replace auth console.error"
    );

    // Add rate limit + body size check after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  // ✅ LICENSE CHECK',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.campaign(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  // ✅ LICENSE CHECK',
      "campaign.js: Added rate limit check"
    );

    // Add Zod schema after rate-limiter import
    c = safeReplace(c,
      'import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      'import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";\n\n// Zod schemas\nconst CampaignSchema = z.object({\n  productTitle: z.string().min(1).max(500),\n  headlines: z.array(z.string().max(30)).min(3).max(15),\n  descriptions: z.array(z.string().max(90)).min(2).max(5),\n  keywords: z.array(z.string().max(200)).max(100).optional(),\n  finalUrl: z.string().url().max(2000),\n  dailyBudget: z.coerce.number().min(1).max(10000).optional(),\n  campaignType: z.enum(["search", "shopping", "display", "pmax"]).optional(),\n  bidding: z.enum(["max_conversions", "max_clicks", "target_cpa", "target_roas"]).optional(),\n});',
      "campaign.js: Added Zod schema"
    );

    // Replace the manual validation block with Zod-based validation
    c = safeReplace(c,
      '  const formData = await request.formData();\n  const productTitle = formData.get("productTitle");\n  const headlines = JSON.parse(formData.get("headlines") || "[]");\n  const descriptions = JSON.parse(formData.get("descriptions") || "[]");\n  const keywords = JSON.parse(formData.get("keywords") || "[]");\n  const finalUrl = formData.get("finalUrl") || "https://your-store.myshopify.com";\n  // Budget validation (server-side safety)\n  let dailyBudget = Number(formData.get("dailyBudget"));\n  if (isNaN(dailyBudget) || dailyBudget <= 0) dailyBudget = 30;\n  dailyBudget = Math.max(1, Math.min(500, dailyBudget)); // $1-$500 safety cap\n  const campaignType = formData.get("campaignType") || "search";\n  const bidding = formData.get("bidding") || "max_conversions";\n\n  // Input validation\n  if (!productTitle || !productTitle.trim()) {\n    return Response.json({ success: false, error: "Product title required." }, { status: 400 });\n  }\n  if (!finalUrl || !finalUrl.startsWith("http")) {\n    return Response.json({ success: false, error: "Valid product URL required." }, { status: 400 });\n  }\n  if (headlines.length < 3) {\n    return Response.json({ success: false, error: "At least 3 headlines required." }, { status: 400 });\n  }\n  if (descriptions.length < 2) {\n    return Response.json({ success: false, error: "At least 2 descriptions required." }, { status: 400 });\n  }',
      '  const formData = await request.formData();\n\n  // Parse and validate with Zod\n  let parsed;\n  try {\n    const rawData = {\n      productTitle: formData.get("productTitle") || "",\n      headlines: JSON.parse(formData.get("headlines") || "[]"),\n      descriptions: JSON.parse(formData.get("descriptions") || "[]"),\n      keywords: JSON.parse(formData.get("keywords") || "[]"),\n      finalUrl: formData.get("finalUrl") || "https://your-store.myshopify.com",\n      dailyBudget: formData.get("dailyBudget"),\n      campaignType: formData.get("campaignType") || "search",\n      bidding: formData.get("bidding") || "max_conversions",\n    };\n    parsed = CampaignSchema.safeParse(rawData);\n  } catch (parseErr) {\n    logger.warn("campaign.action", "Failed to parse form data", { shop, error: parseErr.message });\n    return Response.json({ success: false, error: "Invalid form data" }, { status: 400 });\n  }\n\n  if (!parsed.success) {\n    const issues = parsed.error.issues.map(i => i.path.join(".") + ": " + i.message).join("; ");\n    logger.warn("campaign.action", "Validation failed", { shop, extra: { issues } });\n    return Response.json({ success: false, error: "Invalid input: " + issues }, { status: 400 });\n  }\n\n  const { productTitle, headlines, descriptions, keywords, finalUrl, campaignType, bidding } = parsed.data;\n  let dailyBudget = parsed.data.dailyBudget || 30;\n  dailyBudget = Math.max(1, Math.min(500, dailyBudget)); // $1-$500 safety cap',
      "campaign.js: Replaced manual validation with Zod"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 5: Patch app.api.subscription.js
// Add: rate limiting, full Zod, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 5: Patch app.api.subscription.js\n");

{
  const file = path.join(ROUTES, "app.api.subscription.js");
  if (!fs.existsSync(file)) { err("app.api.subscription.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "subscription.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[SmartAds] Auth failed:", authErr.message);',
      '    logger.error("subscription.action", "Auth failed", { error: authErr.message });',
      "subscription.js: Replace auth console.error"
    );

    // Replace console.warn for billing warning
    c = safeReplace(c,
      '      console.warn(`[SmartAds] WARNING: Plan "${plan}" set for ${shop} without Shopify Billing verification. Add billing flow before production!`);',
      '      logger.warn("subscription.action", `Plan "${plan}" set without Shopify Billing verification`, { shop });',
      "subscription.js: Replace billing console.warn"
    );

    // Replace console.error in catch
    c = safeReplace(c,
      '    console.error("[SmartAds] Subscription error:", err);',
      '    logger.error("subscription.action", "Subscription error", { shop, error: err.message });',
      "subscription.js: Replace catch console.error"
    );

    // Add rate limit to action (after auth, before try)
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  try {\n    const body = await request.json();',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.subscription(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  try {\n    const body = await request.json();',
      "subscription.js: Added rate limit to action"
    );

    // Replace manual plan validation with Zod
    c = safeReplace(c,
      'const VALID_PLANS = ["free", "starter", "pro", "premium"];',
      '// Zod schemas\nconst SubscriptionSchema = z.object({\n  plan: z.enum(["free", "starter", "pro", "premium"]),\n});\nconst VALID_PLANS = ["free", "starter", "pro", "premium"];',
      "subscription.js: Added Zod schema"
    );

    c = safeReplace(c,
      '    const { plan } = body;\n\n    if (!plan || !VALID_PLANS.includes(plan)) {\n      return Response.json(\n        { success: false, error: `Invalid plan. Must be one of: ${VALID_PLANS.join(", ")}` },\n        { status: 400 }\n      );\n    }',
      '    // Zod validation\n    const parsed = SubscriptionSchema.safeParse(body);\n    if (!parsed.success) {\n      const issues = parsed.error.issues.map(i => i.path.join(".") + ": " + i.message).join("; ");\n      logger.warn("subscription.action", "Validation failed", { shop, extra: { issues } });\n      return Response.json(\n        { success: false, error: `Invalid plan. Must be one of: ${VALID_PLANS.join(", ")}` },\n        { status: 400 }\n      );\n    }\n    const { plan } = parsed.data;',
      "subscription.js: Replaced manual validation with Zod"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 6: Patch app.api.ai-engine.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 6: Patch app.api.ai-engine.js\n");

{
  const file = path.join(ROUTES, "app.api.ai-engine.js");
  if (!fs.existsSync(file)) { err("app.api.ai-engine.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "ai-engine.js: Added rate-limiter import"
    );

    // Add rate limit after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  const formData = await request.formData();',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.aiEngine(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  const formData = await request.formData();',
      "ai-engine.js: Added rate limit check"
    );

    // Replace console.error
    c = safeReplace(c,
      '    console.error("[AI-Engine] Error:", err.message);',
      '    logger.error("ai-engine.action", "AI Engine error", { shop, error: err.message });',
      "ai-engine.js: Replace catch console.error"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 7: Patch app.api.ai-improve.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 7: Patch app.api.ai-improve.js\n");

{
  const file = path.join(ROUTES, "app.api.ai-improve.js");
  if (!fs.existsSync(file)) { err("app.api.ai-improve.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "ai-improve.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[SmartAds] Auth failed:", authErr.message);',
      '    logger.error("ai-improve.action", "Auth failed", { error: authErr.message });',
      "ai-improve.js: Replace auth console.error"
    );

    // Replace console.error in catch
    c = safeReplace(c,
      '    console.error("AI improve error:", e);',
      '    logger.error("ai-improve.action", "AI improve error", { shop, error: e.message });',
      "ai-improve.js: Replace catch console.error"
    );

    // Add rate limit after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  // ✅ LICENSE CHECK — must have AI credits',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.aiImprove(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  // ✅ LICENSE CHECK — must have AI credits',
      "ai-improve.js: Added rate limit check"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 8: Patch app.api.campaign-manage.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 8: Patch app.api.campaign-manage.js\n");

{
  const file = path.join(ROUTES, "app.api.campaign-manage.js");
  if (!fs.existsSync(file)) { err("app.api.campaign-manage.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import (campaign-manage has logger already)
    if (c.includes('import { logger }')) {
      c = safeReplace(c,
        'import { logger } from "../utils/logger.js";',
        'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
        "campaign-manage.js: Added rate-limiter import"
      );
    } else {
      // Add both imports after the first import line
      c = safeReplace(c,
        'import { authenticate } from "../shopify.server";',
        'import { authenticate } from "../shopify.server";\nimport { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
        "campaign-manage.js: Added logger + rate-limiter imports"
      );
    }

    // Replace console.error in main catch
    c = safeReplace(c,
      '    console.error("Campaign management error (falling back to simulated):", error.message);',
      '    logger.error("campaign-manage.action", "Campaign management error (falling back to simulated)", { error: error.message });',
      "campaign-manage.js: Replace main console.error"
    );

    // Replace console.log for recommendations
    c = safeReplace(c,
      '    console.log("Recommendations query failed (may be empty):", e.message);',
      '    logger.warn("campaign-manage.recommendations", "Recommendations query failed", { extra: { error: e.message } });',
      "campaign-manage.js: Replace recommendations console.log"
    );

    // Replace console.log for ad policy
    c = safeReplace(c,
      '    console.log("Ad policy query failed:", e.message);',
      '    logger.warn("campaign-manage.adPolicy", "Ad policy query failed", { extra: { error: e.message } });',
      "campaign-manage.js: Replace ad policy console.log"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 9: Patch app.api.keywords.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 9: Patch app.api.keywords.js\n");

{
  const file = path.join(ROUTES, "app.api.keywords.js");
  if (!fs.existsSync(file)) { err("app.api.keywords.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "keywords.js: Added rate-limiter import"
    );

    // Replace the compressed auth line with proper auth + rate limit
    c = safeReplace(c,
      '  try { await authenticate.admin(request); } catch (authErr) { console.error("[SmartAds] Auth failed:", authErr.message); return Response.json({ success: false, error: "Authentication failed" }, { status: 401 }); }',
      '  let session;\n  try {\n    ({ session } = await authenticate.admin(request));\n  } catch (authErr) {\n    logger.error("keywords.action", "Auth failed", { error: authErr.message });\n    return Response.json({ success: false, error: "Authentication failed" }, { status: 401 });\n  }\n  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.keywords(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);',
      "keywords.js: Expanded auth + added rate limit"
    );

    // Replace console.error in catch
    c = safeReplace(c,
      '    console.error("Keyword research error:", err);',
      '    logger.error("keywords.action", "Keyword research error", { shop, error: err.message });',
      "keywords.js: Replace catch console.error"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 10: Patch app.api.market-intel.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 10: Patch app.api.market-intel.js\n");

{
  const file = path.join(ROUTES, "app.api.market-intel.js");
  if (!fs.existsSync(file)) { err("app.api.market-intel.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "market-intel.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[MarketIntel] Auth failed:", authErr.message);',
      '    logger.error("market-intel.action", "Auth failed", { error: authErr.message });',
      "market-intel.js: Replace auth console.error"
    );

    // Replace console.error in catch
    c = safeReplace(c,
      '    console.error("[MarketIntel] Error:", err.message);',
      '    logger.error("market-intel.action", "Market intelligence error", { shop, error: err.message });',
      "market-intel.js: Replace catch console.error"
    );

    // Add rate limit after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  try {',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.marketIntel(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  try {',
      "market-intel.js: Added rate limit check"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 11: Patch app.api.store-analytics.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 11: Patch app.api.store-analytics.js\n");

{
  const file = path.join(ROUTES, "app.api.store-analytics.js");
  if (!fs.existsSync(file)) { err("app.api.store-analytics.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "store-analytics.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[StoreAnalytics] Auth failed:", authErr.message);',
      '    logger.error("store-analytics.action", "Auth failed", { error: authErr.message });',
      "store-analytics.js: Replace auth console.error"
    );

    // Replace console.error in catch
    c = safeReplace(c,
      '    console.error("[StoreAnalytics] Error:", err.message);',
      '    logger.error("store-analytics.action", "Store analytics error", { shop, error: err.message });',
      "store-analytics.js: Replace catch console.error"
    );

    // Add rate limit after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n\n  try {',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.storeAnalytics(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  try {',
      "store-analytics.js: Added rate limit check"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 12: Patch app.api.sync.js
// Add: rate limiting, console→logger
// ════════════════════════════════════════════
console.log("\n📦 STEP 12: Patch app.api.sync.js\n");

{
  const file = path.join(ROUTES, "app.api.sync.js");
  if (!fs.existsSync(file)) { err("app.api.sync.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add rate-limiter import
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "sync.js: Added rate-limiter import"
    );

    // Replace console.error in auth
    c = safeReplace(c,
      '    console.error("[SmartAds] Auth failed:", authErr.message);',
      '    logger.error("sync.action", "Auth failed", { error: authErr.message });',
      "sync.js: Replace auth console.error"
    );

    // Replace console.error in parallel batch
    c = safeReplace(c,
      '          console.error("Parallel batch failed:", res.reason?.message);',
      '          logger.error("sync.analyze", "Parallel batch failed", { shop, error: res.reason?.message });',
      "sync.js: Replace parallel batch console.error"
    );

    // Replace console.error in final catch
    c = safeReplace(c,
      '    console.error("Sync API error:", err);',
      '    logger.error("sync.action", "Sync API error", { shop, error: err.message });',
      "sync.js: Replace final catch console.error"
    );

    // Add rate limit after auth
    c = safeReplace(c,
      '  const shop = session.shop;\n  const formData = await request.formData();',
      '  const shop = session.shop;\n\n  // Rate limit check\n  const rl = rateLimit.sync(shop);\n  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);\n\n  const formData = await request.formData();',
      "sync.js: Added rate limit check"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 13: Patch app.api.campaign-status.js
// Add: rate limiting (no auth — it's a loader)
// ════════════════════════════════════════════
console.log("\n📦 STEP 13: Patch app.api.campaign-status.js\n");

{
  const file = path.join(ROUTES, "app.api.campaign-status.js");
  if (!fs.existsSync(file)) { err("app.api.campaign-status.js not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // This file only has a loader (no shop from auth), but we can still add basic rate limiting
    // Add import for rate-limiter
    c = safeReplace(c,
      'import { logger } from "../utils/logger.js";',
      'import { logger } from "../utils/logger.js";\nimport { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";',
      "campaign-status.js: Added rate-limiter import"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// STEP 14: Update preflight.cjs with 2 new checks
// ════════════════════════════════════════════
console.log("\n📦 STEP 14: Update preflight.cjs\n");

{
  const file = path.join(ROOT, "preflight.cjs");
  if (!fs.existsSync(file)) { err("preflight.cjs not found"); }
  else {
    let c = normalizeLF(fs.readFileSync(file, "utf8"));

    // Add check 24 + check 25 before the SUMMARY section
    const newChecks = `
// ─── CHECK 24: All app.api.* routes import rate-limiter ───
console.log("\\n🚦 RATE LIMITING:");
{
  const routesDir = path.join(ROOT, "app", "routes");
  if (fs.existsSync(routesDir)) {
    const apiRoutes = fs.readdirSync(routesDir).filter(f => f.startsWith("app.api.") && f.endsWith(".js"));
    let allHaveRL = true;
    for (const file of apiRoutes) {
      const content = fs.readFileSync(path.join(routesDir, file), "utf8");
      if (!content.includes("rate-limiter") && !content.includes("rateLimitResponse")) {
        fail(file + " does NOT import rate-limiter");
        allHaveRL = false;
      }
    }
    if (allHaveRL) pass("All " + apiRoutes.length + " API routes import rate-limiter");
  } else {
    fail("app/routes directory not found");
  }
}

// ─── CHECK 25: No raw console.error in app.api.* routes (must use logger) ───
console.log("\\n📝 LOGGER USAGE:");
{
  const routesDir = path.join(ROOT, "app", "routes");
  if (fs.existsSync(routesDir)) {
    const apiRoutes = fs.readdirSync(routesDir).filter(f => f.startsWith("app.api.") && f.endsWith(".js"));
    let rawConsoles = [];
    for (const file of apiRoutes) {
      const content = fs.readFileSync(path.join(routesDir, file), "utf8");
      const fileLines = content.split("\\n");
      for (let i = 0; i < fileLines.length; i++) {
        const line = fileLines[i].trim();
        if (line.startsWith("//")) continue;
        if (line.includes("console.error(") || line.includes("console.log(") || line.includes("console.warn(")) {
          // Allow console inside logger.js itself
          if (!file.includes("logger")) {
            rawConsoles.push({ file, line: i + 1, code: line.slice(0, 80) });
          }
        }
      }
    }
    if (rawConsoles.length > 0) {
      fail("Found " + rawConsoles.length + " raw console.* call(s) in API routes (should use logger):");
      rawConsoles.slice(0, 10).forEach(r => console.log("      " + r.file + ":" + r.line + " " + r.code));
    } else {
      pass("All API routes use logger instead of console.*");
    }
  }
}

`;

    c = safeReplace(c,
      '// ─── SUMMARY ───',
      newChecks + '// ─── SUMMARY ───',
      "preflight.cjs: Added checks 24 (rate-limiter) + 25 (no raw console)"
    );

    fs.writeFileSync(file, c, "utf8");
  }
}

// ════════════════════════════════════════════
// FINAL SUMMARY
// ════════════════════════════════════════════
console.log("\n═══════════════════════════════════════════════════");
console.log(`  DONE: ${totalChanges} changes applied, ${errors.length} errors`);
console.log("═══════════════════════════════════════════════════");

if (errors.length > 0) {
  console.log("\n🚨 ERRORS:");
  errors.forEach(e => console.log("  ❌ " + e));
  process.exit(1);
} else {
  console.log("\n🎉 All patches applied successfully!");
  console.log("   Next: run preflight.cjs + test-flows.cjs");
  process.exit(0);
}
