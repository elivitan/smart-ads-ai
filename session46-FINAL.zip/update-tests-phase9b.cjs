// update-tests-phase9b.cjs — Update preflight + test-flows for Phase 9b TypeScript files
// Run AFTER convert-phase9b.cjs
// Run: node update-tests-phase9b.cjs

const fs = require("fs");

console.log("╔══════════════════════════════════════════════╗");
console.log("║   Update Tests for Phase 9b                 ║");
console.log("╚══════════════════════════════════════════════╝\n");

// ═══════════════════════════════════════
// 1. Update preflight.cjs — add Phase 9b TS file count check
// ═══════════════════════════════════════
try {
  let preflight = fs.readFileSync("preflight.cjs", "utf8");

  // Find existing TS file count check and update the expected count
  // Phase 1 had 7 TS files, now we have 13 (7 + 6 new) + 1 .d.ts = 14 total
  if (preflight.includes("tsFileCount")) {
    // Update existing check
    preflight = preflight.replace(
      /const expectedTsMin\s*=\s*\d+/,
      "const expectedTsMin = 13"
    );
    console.log("✅ preflight.cjs: Updated TS file count minimum to 13");
  } else {
    console.log("⚠️  preflight.cjs: No tsFileCount check found — may need manual update");
  }

  // Add check that old .js versions don't exist
  const phase9bCheck = `
  // Phase 9b: Verify server files are TypeScript (not JS)
  const phase9bFiles = ["redis", "queue", "retry", "rate-limiter", "request-logger", "db-health"];
  let phase9bOk = true;
  for (const name of phase9bFiles) {
    const tsPath = findFile(name + ".ts");
    const jsPath = findFile(name + ".js");
    if (!tsPath) { log("FAIL", name + ".ts not found"); phase9bOk = false; }
    if (jsPath) { log("FAIL", name + ".js still exists — should be .ts"); phase9bOk = false; }
  }
  if (phase9bOk) log("PASS", "Phase 9b: All 6 server/infra files are TypeScript");
`;

  if (!preflight.includes("phase9bFiles")) {
    // Insert before the final summary
    const summaryIndex = preflight.lastIndexOf("// ═══ SUMMARY");
    if (summaryIndex > 0) {
      preflight = preflight.slice(0, summaryIndex) + phase9bCheck + "\n" + preflight.slice(summaryIndex);
      console.log("✅ preflight.cjs: Added Phase 9b server files check");
    } else {
      console.log("⚠️  preflight.cjs: Could not find summary section — add Phase 9b check manually");
    }
  } else {
    console.log("ℹ️  preflight.cjs: Phase 9b check already exists");
  }

  fs.writeFileSync("preflight.cjs", preflight, "utf8");
} catch (e) {
  console.error("❌ preflight.cjs update failed:", e.message);
}

// ═══════════════════════════════════════
// 2. Update test-flows.cjs — add Phase 9b validation test
// ═══════════════════════════════════════
try {
  let testFlows = fs.readFileSync("test-flows.cjs", "utf8");

  const phase9bTest = `
  // ═══ Phase 9b: Server/Infra TypeScript Validation ═══
  test("Phase 9b — server/infra files are TypeScript", () => {
    const serverTsFiles = ["redis.ts", "queue.ts", "retry.ts", "rate-limiter.ts", "request-logger.ts", "db-health.ts"];
    const utilsDir = findUtilsDir();
    
    for (const tsFile of serverTsFiles) {
      const fullPath = path.join(utilsDir, tsFile);
      assert(fs.existsSync(fullPath), tsFile + " should exist in utils/");
      
      const content = fs.readFileSync(fullPath, "utf8");
      // Verify it has TypeScript type annotations
      assert(
        content.includes(": ") || content.includes("interface ") || content.includes("type "),
        tsFile + " should contain TypeScript annotations"
      );
      
      // Verify old .js version is gone
      const jsFile = tsFile.replace(".ts", ".js");
      const jsPath = path.join(utilsDir, jsFile);
      assert(!fs.existsSync(jsPath), jsFile + " should NOT exist (replaced by .ts)");
    }
  });

  test("Phase 9b — server TS files import with .js extensions", () => {
    const serverTsFiles = ["redis.ts", "queue.ts", "retry.ts", "request-logger.ts", "db-health.ts"];
    const utilsDir = findUtilsDir();
    
    for (const tsFile of serverTsFiles) {
      const fullPath = path.join(utilsDir, tsFile);
      if (!fs.existsSync(fullPath)) continue;
      const content = fs.readFileSync(fullPath, "utf8");
      
      // All imports should use .js extension (Vite/Remix resolves .js → .ts)
      const importLines = content.match(/from\\s+["'][^"']+["']/g) || [];
      for (const imp of importLines) {
        if (imp.includes("./") && !imp.includes(".js")) {
          throw new Error(tsFile + " has import without .js extension: " + imp);
        }
      }
    }
  });
`;

  if (!testFlows.includes("Phase 9b")) {
    // Insert before the final summary/report
    const reportIndex = testFlows.lastIndexOf("// ═══ REPORT");
    if (reportIndex > 0) {
      testFlows = testFlows.slice(0, reportIndex) + phase9bTest + "\n" + testFlows.slice(reportIndex);
      console.log("✅ test-flows.cjs: Added Phase 9b validation tests (2 tests)");
    } else {
      // Try alternate insertion point
      const lastTest = testFlows.lastIndexOf("test(");
      if (lastTest > 0) {
        const endOfLastTest = testFlows.indexOf("});", lastTest);
        if (endOfLastTest > 0) {
          testFlows = testFlows.slice(0, endOfLastTest + 3) + "\n" + phase9bTest + testFlows.slice(endOfLastTest + 3);
          console.log("✅ test-flows.cjs: Added Phase 9b validation tests (after last test)");
        }
      }
    }
  } else {
    console.log("ℹ️  test-flows.cjs: Phase 9b tests already exist");
  }

  fs.writeFileSync("test-flows.cjs", testFlows, "utf8");
} catch (e) {
  console.error("❌ test-flows.cjs update failed:", e.message);
}

console.log("\n🎉 Test updates complete! Run: node preflight.cjs && node test-flows.cjs");
