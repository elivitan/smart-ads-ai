// deploy-session46.cjs — Phase 9b: Server/Infra → TypeScript
// Run: node deploy-session46.cjs
//
// This script:
// 1. Copies 6 new .ts files to app/utils/
// 2. Removes old .js versions
// 3. Runs update-tests-phase9b.cjs to update preflight + test-flows
// 4. Verifies everything

const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const UTILS_DIR = path.join("app", "utils");

const FILES_TO_DEPLOY = [
  "redis.ts",
  "queue.ts",
  "retry.ts",
  "rate-limiter.ts",
  "request-logger.ts",
  "db-health.ts",
];

const FILES_TO_REMOVE = [
  "redis.js",
  "queue.js",
  "retry.js",
  "rate-limiter.js",
  "request-logger.js",
  "db-health.js",
];

console.log("╔══════════════════════════════════════════════╗");
console.log("║   Deploy Session 46 — Phase 9b TypeScript   ║");
console.log("╚══════════════════════════════════════════════╝\n");

// 1. Deploy new .ts files
let deployed = 0;
for (const file of FILES_TO_DEPLOY) {
  const src = path.join(__dirname, file);
  const dest = path.join(UTILS_DIR, file);
  if (!fs.existsSync(src)) {
    console.error(`❌ Source not found: ${src}`);
    continue;
  }
  fs.copyFileSync(src, dest);
  console.log(`✅ Deployed: ${dest}`);
  deployed++;
}

// 2. Remove old .js files
let removed = 0;
for (const file of FILES_TO_REMOVE) {
  const target = path.join(UTILS_DIR, file);
  if (fs.existsSync(target)) {
    fs.unlinkSync(target);
    console.log(`🗑️  Removed: ${target}`);
    removed++;
  } else {
    console.log(`ℹ️  Already gone: ${target}`);
  }
}

// 3. Run test update script
const updateScript = path.join(__dirname, "update-tests-phase9b.cjs");
if (fs.existsSync(updateScript)) {
  console.log("\n📋 Updating preflight + test-flows...");
  try {
    execSync(`node "${updateScript}"`, { stdio: "inherit" });
  } catch (e) {
    console.warn("⚠️  Test update script had issues — check manually");
  }
}

// 4. Verify
console.log("\n═══ Verification ═══");
let ok = true;
for (const file of FILES_TO_DEPLOY) {
  const p = path.join(UTILS_DIR, file);
  if (fs.existsSync(p)) {
    console.log(`✅ ${file} exists`);
  } else {
    console.error(`❌ ${file} MISSING`);
    ok = false;
  }
}
for (const file of FILES_TO_REMOVE) {
  const p = path.join(UTILS_DIR, file);
  if (fs.existsSync(p)) {
    console.error(`❌ ${file} still exists!`);
    ok = false;
  }
}

// Count all TS files
const tsFiles = fs.readdirSync(UTILS_DIR).filter(f => f.endsWith(".ts") || f.endsWith(".tsx"));
const dtsFiles = fs.readdirSync(path.join("app", "types")).filter(f => f.endsWith(".d.ts"));
console.log(`\n📊 TypeScript files in utils: ${tsFiles.length}`);
console.log(`📊 Type declarations: ${dtsFiles.length}`);
console.log(`📊 Total: ${tsFiles.length + dtsFiles.length}`);

if (ok) {
  console.log("\n🎉 Deploy successful! Now run:");
  console.log("   node preflight.cjs");
  console.log("   node test-flows.cjs");
  console.log("   npx playwright test");
  console.log("   git add -A");
  console.log('   git commit -m "Phase 9b: Convert 6 server/infra files to TypeScript"');
  console.log("   git push");
} else {
  console.error("\n❌ Deploy had issues — check output above");
}
