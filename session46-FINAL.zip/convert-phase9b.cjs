// convert-phase9b.cjs — Phase 9b: Convert 6 server/infra files to TypeScript
// ONE comprehensive script — converts redis, queue, retry, rate-limiter, request-logger, db-health
// Run: node convert-phase9b.cjs

const fs = require("fs");
const path = require("path");

const FILES = {
  "redis.js": "redis.ts",
  "queue.js": "queue.ts",
  "retry.js": "retry.ts",
  "rate-limiter.js": "rate-limiter.ts",
  "request-logger.js": "request-logger.ts",
  "db-health.js": "db-health.ts",
};

// ═══════════════════════════════════════
// 1. redis.ts
// ═══════════════════════════════════════
const REDIS_TS = `// redis.ts — Redis connection for caching & rate limiting at scale
// Phase 4: Replace in-memory rate limiter with Redis-based
// Install: npm install ioredis
//
// USAGE:
//   import { getRedis, cache } from "../utils/redis.js";
//   const cached = await cache.get("scan:shop123:product456");
//   if (!cached) { const data = await doExpensiveScan(); await cache.set("scan:...", data, 3600); }

import { logger } from "./logger.js";

// Type for Redis client (ioredis)
interface RedisClient {
  get(key: string): Promise<string | null>;
  setex(key: string, seconds: number, value: string): Promise<string>;
  del(key: string | string[]): Promise<number>;
  on(event: string, listener: (...args: unknown[]) => void): this;
}

interface CacheHelper {
  get<T = unknown>(key: string): Promise<T | null>;
  set(key: string, value: unknown, ttlSeconds?: number): Promise<boolean>;
  del(key: string): Promise<boolean>;
}

// Lazy Redis connection — only connects when first used
let redisClient: RedisClient | null = null;

export function getRedis(): RedisClient | null {
  if (redisClient) return redisClient;
  try {
    const Redis = require("ioredis");
    redisClient = new Redis(process.env.REDIS_URL || "redis://localhost:6379", {
      maxRetriesPerRequest: 3,
      retryStrategy: (times: number): number => Math.min(times * 200, 5000),
      lazyConnect: true,
      enableReadyCheck: true,
    }) as RedisClient;
    redisClient.on("error", (err: unknown) => logger.error("[Redis]", \`Connection error: \${(err as Error).message}\`));
    redisClient.on("connect", () => logger.info("[Redis]", "Connected"));
    return redisClient;
  } catch (e) {
    logger.warn("[Redis]", "ioredis not installed — falling back to in-memory. Run: npm install ioredis");
    return null;
  }
}

// Cache helper with automatic JSON serialization
export const cache: CacheHelper = {
  async get<T = unknown>(key: string): Promise<T | null> {
    const redis = getRedis();
    if (!redis) return null;
    try {
      const val = await redis.get(key);
      return val ? (JSON.parse(val) as T) : null;
    } catch (e) {
      logger.warn("[Cache]", \`get failed: \${(e as Error).message}\`);
      return null;
    }
  },

  async set(key: string, value: unknown, ttlSeconds: number = 3600): Promise<boolean> {
    const redis = getRedis();
    if (!redis) return false;
    try {
      await redis.setex(key, ttlSeconds, JSON.stringify(value));
      return true;
    } catch (e) {
      logger.warn("[Cache]", \`set failed: \${(e as Error).message}\`);
      return false;
    }
  },

  async del(key: string): Promise<boolean> {
    const redis = getRedis();
    if (!redis) return false;
    try {
      await redis.del(key);
      return true;
    } catch (e) {
      return false;
    }
  },
};

// TTL constants (seconds)
export const TTL = {
  SCAN_RESULT: 24 * 3600,      // 24h — competitor data
  AI_ANALYSIS: 48 * 3600,      // 48h — AI product analysis
  KEYWORD_DATA: 12 * 3600,     // 12h — keyword research
  RATE_LIMIT: 60,              // 1min — rate limit window
  SESSION: 7 * 24 * 3600,      // 7 days — user session
} as const;

export type TTLKey = keyof typeof TTL;
`;

// ═══════════════════════════════════════
// 2. queue.ts
// ═══════════════════════════════════════
const QUEUE_TS = `// queue.ts — Job queue for background processing at scale
// Phase 3: Move scans, AI analysis, and campaigns to background jobs
// Install: npm install bullmq
//
// USAGE:
//   import { scanQueue, addScanJob } from "../utils/queue.js";
//   await addScanJob({ shop: "store.myshopify.com", products: [...] });
//
// WORKER (separate process):
//   import { scanQueue } from "../utils/queue.js";
//   scanQueue.process(async (job) => { ... });

import { logger } from "./logger.js";

// Types for BullMQ (avoids hard dependency on @types/bullmq)
interface BullMQJob {
  id: string;
  name: string;
  data: unknown;
}

interface BullMQQueue {
  add(name: string, data: unknown, opts?: Record<string, unknown>): Promise<BullMQJob>;
  getJobCounts(): Promise<Record<string, number>>;
}

interface BullMQConstructor {
  new (name: string, opts: Record<string, unknown>): BullMQQueue;
}

interface JobResult {
  queued: boolean;
  jobId?: string;
}

interface QueueHealthEntry {
  status: "ok" | "error" | "not_available";
  message?: string;
  [key: string]: unknown;
}

interface ScanJobData {
  shop: string;
  products?: unknown[];
  priority?: number;
}

interface CampaignJobData {
  shop: string;
  campaignConfig?: unknown;
  priority?: number;
}

let QueueClass: BullMQConstructor | null = null;

try {
  const bullmq = require("bullmq");
  QueueClass = bullmq.Queue as BullMQConstructor;
} catch (e) {
  logger.warn("[Queue]", "bullmq not installed — jobs run synchronously. Run: npm install bullmq");
}

const REDIS_CONN: { host: string; port: number } = {
  host: process.env.REDIS_HOST || "localhost",
  port: parseInt(process.env.REDIS_PORT || "6379"),
};

// Queue name constants
export const QUEUES = {
  SCAN: "smart-ads-scan",
  AI_ANALYSIS: "smart-ads-ai",
  CAMPAIGN: "smart-ads-campaign",
} as const;

export type QueueName = typeof QUEUES[keyof typeof QUEUES];

// Create queue (lazy — only if bullmq available)
function createQueue(name: string): BullMQQueue | null {
  if (!QueueClass) return null;
  return new QueueClass(name, {
    connection: REDIS_CONN,
    defaultJobOptions: {
      attempts: 3,
      backoff: { type: "exponential", delay: 2000 },
      removeOnComplete: { age: 3600 },
      removeOnFail: { age: 24 * 3600 },
    },
  });
}

export const scanQueue: BullMQQueue | null = createQueue(QUEUES.SCAN);
export const aiQueue: BullMQQueue | null = createQueue(QUEUES.AI_ANALYSIS);
export const campaignQueue: BullMQQueue | null = createQueue(QUEUES.CAMPAIGN);

// Helper to add jobs (falls back to sync execution if no queue)
export async function addScanJob(data: ScanJobData): Promise<JobResult> {
  if (scanQueue) {
    const job = await scanQueue.add("scan", data, { priority: data.priority || 5 });
    logger.info("[Queue]", \`Scan job added: \${job.id}\`);
    return { queued: true, jobId: job.id };
  }
  // Fallback: return null so caller knows to run synchronously
  return { queued: false };
}

export async function addCampaignJob(data: CampaignJobData): Promise<JobResult> {
  if (campaignQueue) {
    const job = await campaignQueue.add("campaign", data, { priority: data.priority || 5 });
    logger.info("[Queue]", \`Campaign job added: \${job.id}\`);
    return { queued: true, jobId: job.id };
  }
  return { queued: false };
}

// Status check for health endpoint
export async function getQueueHealth(): Promise<Record<string, QueueHealthEntry>> {
  const result: Record<string, QueueHealthEntry> = {};
  const queues: Record<string, BullMQQueue | null> = { scan: scanQueue, ai: aiQueue, campaign: campaignQueue };

  for (const [name, queue] of Object.entries(queues)) {
    if (!queue) {
      result[name] = { status: "not_available" };
      continue;
    }
    try {
      const counts = await queue.getJobCounts();
      result[name] = { status: "ok", ...counts };
    } catch (e) {
      result[name] = { status: "error", message: (e as Error).message };
    }
  }
  return result;
}
`;

// ═══════════════════════════════════════
// 3. retry.ts
// ═══════════════════════════════════════
const RETRY_TS = `// retry.ts — Exponential backoff retry + Circuit Breaker
// For external API calls: Google Ads, Anthropic, SerpAPI

import { logger } from "./logger.js";

// ── Circuit Breaker types ──
type CircuitState = "closed" | "open" | "half-open";

interface CircuitBreaker {
  failures: number;
  lastFailure: number;
  state: CircuitState;
}

export interface RetryOptions {
  maxRetries?: number;
  baseDelayMs?: number;
  maxDelayMs?: number;
  circuitName?: string | null;
  circuitThreshold?: number;
  circuitResetMs?: number;
  retryableErrors?: ((error: Error) => boolean) | null;
}

interface CircuitStatus {
  state: CircuitState;
  failures: number;
  lastFailure: number;
}

// ── Circuit Breaker state (in-memory) ──
const circuits: Map<string, CircuitBreaker> = new Map();

function getCircuit(name: string): CircuitBreaker {
  if (!circuits.has(name)) {
    circuits.set(name, {
      failures: 0,
      lastFailure: 0,
      state: "closed",
    });
  }
  return circuits.get(name)!;
}

const DEFAULT_OPTIONS: Required<RetryOptions> = {
  maxRetries: 3,
  baseDelayMs: 1000,
  maxDelayMs: 30000,
  circuitName: null,
  circuitThreshold: 5,
  circuitResetMs: 300000,
  retryableErrors: null,
};

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Retry a function with exponential backoff.
 * Optionally uses a circuit breaker to stop calling a dead service.
 */
export async function withRetry<T>(fn: () => Promise<T>, options: RetryOptions = {}): Promise<T> {
  const opts: Required<RetryOptions> = { ...DEFAULT_OPTIONS, ...options };
  const { maxRetries, baseDelayMs, maxDelayMs, circuitName, circuitThreshold, circuitResetMs, retryableErrors } = opts;

  // ── Circuit Breaker check ──
  if (circuitName) {
    const circuit = getCircuit(circuitName);

    if (circuit.state === "open") {
      const elapsed = Date.now() - circuit.lastFailure;
      if (elapsed < circuitResetMs) {
        const waitSec = Math.ceil((circuitResetMs - elapsed) / 1000);
        logger.warn("retry.circuit", \`Circuit OPEN for "\${circuitName}" — blocking call. Retry in \${waitSec}s\`);
        throw new Error(\`Circuit breaker OPEN for \${circuitName}. Service unavailable. Retry after \${waitSec}s.\`);
      }
      circuit.state = "half-open";
      logger.info("retry.circuit", \`Circuit HALF-OPEN for "\${circuitName}" — testing one request\`);
    }
  }

  let lastError: Error | undefined;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = await fn();

      // Success → reset circuit breaker
      if (circuitName) {
        const circuit = getCircuit(circuitName);
        if (circuit.failures > 0 || circuit.state !== "closed") {
          logger.info("retry.circuit", \`Circuit CLOSED for "\${circuitName}" — service recovered\`);
        }
        circuit.failures = 0;
        circuit.state = "closed";
      }

      return result;

    } catch (error) {
      lastError = error as Error;

      // Check if this error is retryable
      if (retryableErrors && !retryableErrors(lastError)) {
        logger.warn("retry", \`Non-retryable error on attempt \${attempt + 1}: \${lastError.message}\`);
        throw lastError;
      }

      if (attempt < maxRetries) {
        const delay = Math.min(baseDelayMs * Math.pow(2, attempt) + Math.random() * 500, maxDelayMs);
        logger.warn("retry", \`Attempt \${attempt + 1}/\${maxRetries + 1} failed for \${circuitName || "unknown"}. Retrying in \${Math.round(delay)}ms\`, {
          error: lastError.message,
        });
        await sleep(delay);
      }
    }
  }

  // All retries exhausted → update circuit breaker
  if (circuitName) {
    const circuit = getCircuit(circuitName);
    circuit.failures++;
    circuit.lastFailure = Date.now();

    if (circuit.failures >= circuitThreshold) {
      circuit.state = "open";
      logger.error("retry.circuit", \`Circuit OPENED for "\${circuitName}" after \${circuit.failures} consecutive failures. Blocking for \${circuitResetMs / 1000}s\`);
    }
  }

  logger.error("retry", \`All \${maxRetries + 1} attempts failed for \${circuitName || "unknown"}\`, {
    error: lastError?.message,
  });
  throw lastError!;
}

/**
 * Get current circuit breaker status for a service.
 * Useful for health checks.
 */
export function getCircuitStatus(name: string): CircuitStatus {
  if (!circuits.has(name)) {
    return { state: "closed", failures: 0, lastFailure: 0 };
  }
  const c = circuits.get(name)!;
  return { state: c.state, failures: c.failures, lastFailure: c.lastFailure };
}

/**
 * Reset a circuit breaker (e.g. after manual recovery).
 */
export function resetCircuit(name: string): void {
  if (circuits.has(name)) {
    circuits.set(name, { failures: 0, lastFailure: 0, state: "closed" });
    logger.info("retry.circuit", \`Circuit manually reset for "\${name}"\`);
  }
}
`;

// ═══════════════════════════════════════
// 4. rate-limiter.ts
// ═══════════════════════════════════════
const RATE_LIMITER_TS = `// rate-limiter.ts — In-memory rate limiter (Map-based, auto-cleanup)
// Per-shop limits per route. Returns 429 with Retry-After.
// Future: replace Map with Redis for multi-instance deployments.

// ── Types ──
interface RateBucket {
  windowStart: number;
  count: number;
  windowMs: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds?: number;
}

type RateLimitChecker = (shop: string) => RateLimitResult;

export interface RateLimitPresets {
  state: RateLimitChecker;
  scan: RateLimitChecker;
  campaign: RateLimitChecker;
  subscription: RateLimitChecker;
  aiEngine: RateLimitChecker;
  aiImprove: RateLimitChecker;
  keywords: RateLimitChecker;
  marketIntel: RateLimitChecker;
  storeAnalytics: RateLimitChecker;
  campaignManage: RateLimitChecker;
  campaignStatus: RateLimitChecker;
  sync: RateLimitChecker;
}

// ── Redis integration (Phase 3 activation) ──
// When USE_REDIS=true, rate limiting will use Redis instead of in-memory Map.
// This enables multi-instance deployments with shared rate limit state.
// For now, falls back to in-memory if Redis is not available.
const buckets: Map<string, RateBucket> = new Map();

// Auto-cleanup: remove expired entries every 5 minutes
setInterval((): void => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (now - bucket.windowStart > bucket.windowMs * 2) {
      buckets.delete(key);
    }
  }
}, 5 * 60 * 1000);

/**
 * Check rate limit for a shop+route combination.
 */
export function checkRateLimit(
  shop: string,
  route: string,
  maxRequests: number = 60,
  windowMs: number = 60000
): RateLimitResult {
  const key = \`\${shop}:\${route}\`;
  const now = Date.now();

  let bucket = buckets.get(key);

  // Create new bucket or reset if window expired
  if (!bucket || now - bucket.windowStart > windowMs) {
    bucket = { windowStart: now, count: 0, windowMs };
    buckets.set(key, bucket);
  }

  bucket.count++;

  if (bucket.count > maxRequests) {
    const retryAfterSeconds = Math.ceil((bucket.windowStart + windowMs - now) / 1000);
    return { allowed: false, remaining: 0, retryAfterSeconds: Math.max(1, retryAfterSeconds) };
  }

  return { allowed: true, remaining: maxRequests - bucket.count };
}

/**
 * Create a 429 Too Many Requests response.
 */
export function rateLimitResponse(retryAfterSeconds: number): Response {
  return new Response(
    JSON.stringify({
      success: false,
      error: "Too many requests. Please slow down.",
      retryAfter: retryAfterSeconds,
    }),
    {
      status: 429,
      headers: {
        "Content-Type": "application/json",
        "Retry-After": String(retryAfterSeconds),
      },
    }
  );
}

// ── Route-specific presets ──
export const rateLimit: RateLimitPresets = {
  state:          (shop: string): RateLimitResult => checkRateLimit(shop, "state", 60, 60000),
  scan:           (shop: string): RateLimitResult => checkRateLimit(shop, "scan", 10, 60000),
  campaign:       (shop: string): RateLimitResult => checkRateLimit(shop, "campaign", 20, 60000),
  subscription:   (shop: string): RateLimitResult => checkRateLimit(shop, "subscription", 20, 60000),
  aiEngine:       (shop: string): RateLimitResult => checkRateLimit(shop, "ai-engine", 20, 60000),
  aiImprove:      (shop: string): RateLimitResult => checkRateLimit(shop, "ai-improve", 20, 60000),
  keywords:       (shop: string): RateLimitResult => checkRateLimit(shop, "keywords", 20, 60000),
  marketIntel:    (shop: string): RateLimitResult => checkRateLimit(shop, "market-intel", 15, 60000),
  storeAnalytics: (shop: string): RateLimitResult => checkRateLimit(shop, "store-analytics", 15, 60000),
  campaignManage: (shop: string): RateLimitResult => checkRateLimit(shop, "campaign-manage", 30, 60000),
  campaignStatus: (shop: string): RateLimitResult => checkRateLimit(shop, "campaign-status", 60, 60000),
  sync:           (shop: string): RateLimitResult => checkRateLimit(shop, "sync", 10, 60000),
};
`;

// ═══════════════════════════════════════
// 5. request-logger.ts
// ═══════════════════════════════════════
const REQUEST_LOGGER_TS = `// request-logger.ts — Request/Response logging middleware
// Wraps API route handlers to log: method, route, shop, duration, status
// Future: pipe to Datadog / CloudWatch / LogRocket

import { logger } from "./logger.js";

// Remix route handler args type
interface RouteHandlerArgs {
  request: Request;
  params?: Record<string, string>;
  context?: unknown;
}

type RouteHandler = (args: RouteHandlerArgs) => Promise<Response> | Response;

/**
 * Wrap an API route handler with request logging.
 * Works with both loader (GET) and action (POST/PUT/DELETE).
 */
export function withRequestLogging(routeName: string, handler: RouteHandler): RouteHandler {
  return async function loggedHandler(args: RouteHandlerArgs): Promise<Response> {
    const start = Date.now();
    const request = args.request;
    const method = request.method;
    const url = new URL(request.url);

    let status = 200;
    let response: Response | undefined;

    try {
      response = await handler(args);

      // Extract status from Response object if possible
      if (response && typeof response.status === "number") {
        status = response.status;
      }

      return response;
    } catch (error) {
      status = 500;
      logger.error(routeName, "Unhandled error in route handler", {
        error: (error as Error).message || String(error),
        extra: { method, path: url.pathname },
      });
      throw error;
    } finally {
      const duration = Date.now() - start;

      // Log level based on status
      const logLevel: "error" | "warn" | "info" = status >= 500 ? "error" : status >= 400 ? "warn" : "info";
      logger[logLevel](routeName, \`\${method} \${url.pathname} → \${status} (\${duration}ms)\`, {
        extra: { method, path: url.pathname, status, duration },
      });
    }
  };
}
`;

// ═══════════════════════════════════════
// 6. db-health.ts
// ═══════════════════════════════════════
const DB_HEALTH_TS = `// db-health.ts — Database connection health monitoring
// For scale: monitors connection pool, query latency, and connection count
// Integrates with health endpoint for monitoring dashboards

import { logger } from "./logger.js";
import { SCALE } from "./scale-config.js";

// ── Types ──
interface DbHealthStats {
  totalQueries: number;
  slowQueries: number;
  errors: number;
  poolConfig: {
    min: number;
    max: number;
    timeoutMs: number;
  };
}

// ── State ──
let queryCount = 0;
let slowQueryCount = 0;
let errorCount = 0;
const SLOW_QUERY_THRESHOLD_MS = 2000;

/**
 * Wrap a Prisma operation with monitoring.
 * Tracks latency, counts errors and slow queries.
 */
export async function monitoredQuery<T>(label: string, queryFn: () => Promise<T>): Promise<T> {
  const start = Date.now();
  queryCount++;

  try {
    const result = await queryFn();
    const duration = Date.now() - start;

    if (duration > SLOW_QUERY_THRESHOLD_MS) {
      slowQueryCount++;
      logger.warn("[DB]", \`Slow query "\${label}": \${duration}ms\`);
    }

    return result;
  } catch (error) {
    errorCount++;
    const duration = Date.now() - start;
    logger.error("[DB]", \`Query "\${label}" failed after \${duration}ms: \${(error as Error).message}\`);
    throw error;
  }
}

/**
 * Get DB health stats for the health endpoint.
 */
export function getDbHealthStats(): DbHealthStats {
  return {
    totalQueries: queryCount,
    slowQueries: slowQueryCount,
    errors: errorCount,
    poolConfig: {
      min: SCALE.DB_POOL_MIN,
      max: SCALE.DB_POOL_MAX,
      timeoutMs: SCALE.DB_TIMEOUT_MS,
    },
  };
}

/**
 * Reset stats (for testing).
 */
export function resetDbStats(): void {
  queryCount = 0;
  slowQueryCount = 0;
  errorCount = 0;
}
`;

// ═══════════════════════════════════════
// EXECUTION
// ═══════════════════════════════════════
const CONTENT = {
  "redis.ts": REDIS_TS,
  "queue.ts": QUEUE_TS,
  "retry.ts": RETRY_TS,
  "rate-limiter.ts": RATE_LIMITER_TS,
  "request-logger.ts": REQUEST_LOGGER_TS,
  "db-health.ts": DB_HEALTH_TS,
};

let created = 0;
let errors = 0;

console.log("╔══════════════════════════════════════════════╗");
console.log("║   Phase 9b: Server/Infra → TypeScript       ║");
console.log("╚══════════════════════════════════════════════╝");
console.log("");

for (const [tsFile, content] of Object.entries(CONTENT)) {
  const jsFile = tsFile.replace(".ts", ".js");
  try {
    // Verify original JS file exists
    if (!fs.existsSync(jsFile)) {
      console.error(`❌ Source not found: ${jsFile}`);
      errors++;
      continue;
    }

    // Write new TS file
    fs.writeFileSync(tsFile, content, "utf8");
    console.log(`✅ Created: ${tsFile}`);

    // Remove old JS file
    fs.unlinkSync(jsFile);
    console.log(`   🗑️  Removed: ${jsFile}`);

    created++;
  } catch (e) {
    console.error(`❌ Error converting ${jsFile}: ${e.message}`);
    errors++;
  }
}

console.log("");
console.log("────────────────────────────────────────────────");
console.log(`  ✅ Converted: ${created}/6 files`);
if (errors > 0) console.log(`  ❌ Errors: ${errors}`);
console.log("────────────────────────────────────────────────");
console.log("");

// ═══════════════════════════════════════
// VERIFY: Count .ts files in project
// ═══════════════════════════════════════
const allFiles = fs.readdirSync(".").filter(f => f.endsWith(".ts") || f.endsWith(".tsx"));
console.log(`📊 Total TypeScript files: ${allFiles.length}`);
allFiles.forEach(f => console.log(`   📄 ${f}`));

// Verify no .js versions left
const jsLeftovers = Object.keys(FILES).filter(js => fs.existsSync(js));
if (jsLeftovers.length > 0) {
  console.log(`\n⚠️  WARNING: Original .js files still exist: ${jsLeftovers.join(", ")}`);
} else {
  console.log("\n✅ All original .js files removed successfully");
}

console.log("\n🎉 Phase 9b complete! Run preflight.cjs + test-flows.cjs to verify.");
