// session32-update-preflight.cjs
// Update preflight.cjs baseline numbers for Zustand migration
const fs = require("fs");
const path = require("path");

const filePath = path.join(process.cwd(), "preflight.cjs");
let content = fs.readFileSync(filePath, "utf8");

// 1. Update expected import count: 26 → 21
content = content.replace(
  '// ─── CHECK 3: All 26 imports ───',
  '// ─── CHECK 3: All 21 imports (post-Zustand) ───'
);
content = content.replace(
  'if (importCount !== 26) fail(`Expected 26 imports, found ${importCount}`);',
  'if (importCount !== 21) fail(`Expected 21 imports, found ${importCount}`);'
);

// 2. Update required imports list — remove ones that moved to DashboardView, add useAppStore
const oldRequiredImports = `const requiredImports = [
  "react",
  "react-router",
  "shopify.server",
  "sync.server",
  "license.server",
  "Modals.jsx",
  "styles.index",
  "SmallWidgets.jsx",
  "SmallComponents.jsx",
  "CollectingDataScreen.jsx",
  "AdPreviewPanel.jsx",
  "CompetitorModal.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LivePulse.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "MarketAlert.jsx",
  "StoreAnalytics.jsx",
  "useGoogleAdsData",
];`;

const newRequiredImports = `const requiredImports = [
  "react",
  "react-router",
  "shopify.server",
  "sync.server",
  "license.server",
  "styles.index",
  "SmallWidgets.jsx",
  "SmallComponents.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "useGoogleAdsData",
  "useAppStore",
];`;

if (!content.includes(oldRequiredImports)) {
  console.error("❌ Could not find requiredImports block in preflight.cjs");
  process.exit(1);
}
content = content.replace(oldRequiredImports, newRequiredImports);

// 3. Update hooks count warning threshold (was 50 → now 10 since Zustand replaced useState)
content = content.replace(
  'if (hookCount < 50) warn(`Only ${hookCount} hooks found before early return (expected ~66)`);',
  'if (hookCount < 10) warn(`Only ${hookCount} hooks found before early return (expected ~21)`);'
);
content = content.replace(
  'else pass(`${hookCount} hooks found before early return`);',
  'else pass(`${hookCount} hooks found before early return (Zustand baseline)`);'
);

// 4. Update pass message
content = content.replace(
  "else pass(`All 21 imports present`);",
  "else pass(`All imports present`);"
);

fs.writeFileSync(filePath, content.replace(/\r\n/g, "\n"), "utf8");
console.log("✅ Updated preflight.cjs for Zustand baseline");
