// preflight.cjs
// ═══════════════════════════════════════════════════════════════
// Smart Ads AI — Preflight Safety Check
// Run BEFORE every deploy or after any code change.
// Checks: hook safety, line count, imports, syntax, architecture
// ═══════════════════════════════════════════════════════════════

const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const INDEX_FILE = path.join(ROOT, "app", "routes", "app._index.jsx");
const STYLES_FILE = path.join(ROOT, "app", "routes", "styles.index.js");

let passed = 0;
let failed = 0;
let warnings = 0;

function pass(msg) { console.log(`  ✅ ${msg}`); passed++; }
function fail(msg) { console.log(`  ❌ ${msg}`); failed++; }
function warn(msg) { console.log(`  ⚠️  ${msg}`); warnings++; }

console.log("═══════════════════════════════════════════════════");
console.log("  Smart Ads AI — Preflight Safety Check");
console.log("═══════════════════════════════════════════════════\n");

// ─── CHECK 1: File exists ───
console.log("📁 FILE STRUCTURE:");
if (!fs.existsSync(INDEX_FILE)) {
  fail("app._index.jsx NOT FOUND"); process.exit(1);
}
pass("app._index.jsx exists");

// ─── CHECK 2: Line count ───
console.log("\n📏 LINE COUNT:");
const code = fs.readFileSync(INDEX_FILE, "utf8");
const lines = code.split("\n");
const lineCount = lines.length;

if (lineCount > 800) fail(`app._index.jsx is ${lineCount} lines — EXCEEDS 800 LIMIT! Something was inlined!`);
else if (lineCount > 750) warn(`app._index.jsx is ${lineCount} lines — getting close to 800 limit`);
else pass(`app._index.jsx is ${lineCount} lines (limit: 800)`);

// ─── CHECK 3: All 21 imports (post-Zustand) ───
console.log("\n📦 IMPORTS:");
const importLines = lines.filter(l => l.startsWith("import "));
const importCount = importLines.length;

const requiredImports = [
  "react",
  "react-router",
  "shopify.server",
  "sync.server",
  "license.server",
  "styles.index",
  "SmallWidgets.jsx",
  "SmallComponents.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "useGoogleAdsData",
  "useAppStore",
];

let missingImports = [];
for (const req of requiredImports) {
  const found = importLines.some(l => l.includes(req));
  if (!found) missingImports.push(req);
}

if (importCount !== 20) fail(`Expected 20 imports, found ${importCount}`);
else pass(`All imports present`);

if (missingImports.length > 0) fail(`Missing imports: ${missingImports.join(", ")}`);
else pass("All required modules imported");

// ─── CHECK 4: Hooks before first early return ───
console.log("\n🪝 HOOKS SAFETY:");

// Find Index() function start
const indexStart = lines.findIndex(l => l.includes("export default function Index()"));
if (indexStart === -1) { fail("Could not find 'export default function Index()'"); }
else {
  // Find first early return (if (...) return)
  let firstEarlyReturn = -1;
  for (let i = indexStart; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    // Match patterns like: if (scanError) return (
    // But NOT: if (!res.ok) return; (inside nested functions)
    // We look for return statements at Index() scope level
    if (trimmed.match(/^if\s*\(.*\)\s*return\s*\(/) && !trimmed.includes("=>")) {
      firstEarlyReturn = i;
      break;
    }
  }

  if (firstEarlyReturn === -1) {
    warn("Could not find first early return — manual check needed");
  } else {
    pass(`Index() starts at line ${indexStart + 1}, first early return at line ${firstEarlyReturn + 1}`);

    // Check for hooks AFTER early return
    const hookPatterns = /\b(useState|useEffect|useRef|useMemo|useCallback|useContext|useReducer|useLayoutEffect)\b/;
    let hooksAfterReturn = [];
    let insideNestedFunc = 0;

    for (let i = firstEarlyReturn + 1; i < lines.length; i++) {
      const line = lines[i];
      // Track nested function depth (rough)
      if (line.includes("function ") || line.includes("=>")) insideNestedFunc++;
      
      // Only check at Index() top level
      if (hookPatterns.test(line) && !line.trim().startsWith("//") && !line.trim().startsWith("*")) {
        // Check if this is a real hook call, not just a mention
        if (line.includes("use") && (line.includes("useState(") || line.includes("useEffect(") || 
            line.includes("useRef(") || line.includes("useMemo(") || line.includes("useCallback(") ||
            line.includes("useGoogleAdsData("))) {
          hooksAfterReturn.push({ line: i + 1, code: line.trim().slice(0, 80) });
        }
      }
    }

    if (hooksAfterReturn.length > 0) {
      fail(`Found ${hooksAfterReturn.length} hooks AFTER first early return (line ${firstEarlyReturn + 1}):`);
      hooksAfterReturn.slice(0, 5).forEach(h => console.log(`      Line ${h.line}: ${h.code}`));
    } else {
      pass("No hooks found after first early return");
    }
  }

  // Count hooks
  let hookCount = 0;
  for (let i = indexStart; i < (firstEarlyReturn > 0 ? firstEarlyReturn : lines.length); i++) {
    const line = lines[i];
    const matches = line.match(/\b(useState|useEffect|useRef|useMemo|useCallback)\s*\(/g);
    if (matches) hookCount += matches.length;
  }
  if (hookCount < 10) warn(`Only ${hookCount} hooks found before early return (expected ~21)`);
  else pass(`${hookCount} hooks found before early return (Zustand baseline)`);
}

// ─── CHECK 5: No component definitions inside Index() ───
console.log("\n🏗️  ARCHITECTURE:");

const indexStartLine = lines.findIndex(l => l.includes("export default function Index()"));
if (indexStartLine >= 0) {
  let componentInsideIndex = [];
  for (let i = indexStartLine + 1; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    // Look for function Component patterns that return JSX
    if (trimmed.match(/^(const|function)\s+[A-Z][a-zA-Z]+\s*[=(]/) && 
        !trimmed.startsWith("//") &&
        !trimmed.includes("const REAL_STEPS") &&
        !trimmed.includes("const FREE_SCAN") &&
        !trimmed.includes("const INTRO_PHASES") &&
        !trimmed.includes("const BATCH") &&
        // Only flag if it looks like a React component (returns JSX)
        (trimmed.includes("return (") || trimmed.includes("=> (") || trimmed.includes("=> <"))) {
      componentInsideIndex.push({ line: i + 1, code: trimmed.slice(0, 80) });
    }
  }
  
  if (componentInsideIndex.length > 0) {
    fail(`Found ${componentInsideIndex.length} possible component definitions INSIDE Index():`);
    componentInsideIndex.forEach(c => console.log(`      Line ${c.line}: ${c.code}`));
  } else {
    pass("No component definitions inside Index()");
  }
}

// Check WidgetErrorBoundary + LockedOverlay are OUTSIDE Index()
if (indexStartLine >= 0) {
  const widgetEB = lines.findIndex(l => l.includes("class WidgetErrorBoundary"));
  const lockedOL = lines.findIndex(l => l.includes("function LockedOverlay"));
  
  if (widgetEB >= 0 && widgetEB < indexStartLine) pass("WidgetErrorBoundary is OUTSIDE Index() (line " + (widgetEB + 1) + ")");
  else fail("WidgetErrorBoundary should be OUTSIDE Index()");
  
  if (lockedOL >= 0 && lockedOL < indexStartLine) pass("LockedOverlay is OUTSIDE Index() (line " + (lockedOL + 1) + ")");
  else fail("LockedOverlay should be OUTSIDE Index()");
}

// ─── CHECK 6: Slider CSS safety ───
console.log("\n🎚️  SLIDER CSS:");
if (fs.existsSync(STYLES_FILE)) {
  const css = fs.readFileSync(STYLES_FILE, "utf8");
  
  const sliderZindex = css.includes(".budget-sim-slider") && css.includes("z-index:9999") || css.includes("z-index: 9999");
  const sliderTouch = css.includes("touch-action:none") || css.includes("touch-action: none");
  
  if (sliderZindex) pass("Slider z-index:9999 present");
  else warn("Could not verify slider z-index:9999 — check manually");
  
  if (sliderTouch) pass("Slider touch-action:none present");
  else warn("Could not verify slider touch-action:none — check manually");
} else {
  warn("styles.index.js not found");
}

// ─── CHECK 7: No .jsx backup files in routes ───
console.log("\n🧹 CLEANUP:");
const routesDir = path.join(ROOT, "app", "routes");
if (fs.existsSync(routesDir)) {
  const routeFiles = fs.readdirSync(routesDir);
  const backupFiles = routeFiles.filter(f => f.includes(".bak") || f.includes(".backup") || f.includes(".old") || (f.endsWith(".jsx") && f.includes("_copy")));
  
  if (backupFiles.length > 0) {
    fail(`Found backup files in app/routes/ — Vite will pick these up as routes:`);
    backupFiles.forEach(f => console.log(`      ${f}`));
  } else {
    pass("No backup files in app/routes/");
  }
  
  // Check for .bak-pre-serper files in app/
  const appDir = path.join(ROOT, "app");
  const appFiles = fs.readdirSync(appDir);
  const bakFiles = appFiles.filter(f => f.includes(".bak-"));
  if (bakFiles.length > 0) {
    warn(`Found ${bakFiles.length} .bak files in app/ — safe to delete after confirming stability:`);
    bakFiles.forEach(f => console.log(`      ${f}`));
  } else {
    pass("No .bak files in app/");
  }
}

// ─── CHECK 8: .env keys ───
console.log("\n🔑 ENV KEYS:");
const envPath = path.join(ROOT, ".env");
if (fs.existsSync(envPath)) {
  const env = fs.readFileSync(envPath, "utf8");
  
  const keys = [
    ["ANTHROPIC_API_KEY", true],
    ["SERPER_API_KEY", true],
    ["SERPAPI_KEY", false], // optional fallback
    ["NEWSAPI_KEY", false],
    ["DATABASE_URL", true],
    ["GOOGLE_ADS_DEVELOPER_TOKEN", true],
  ];
  
  for (const [key, required] of keys) {
    const match = env.match(new RegExp(`${key}=(.+)`));
    if (match && match[1].trim()) {
      const val = match[1].trim();
      pass(`${key} = ${val.slice(0, 8)}...${val.slice(-4)} (${val.length} chars)`);
    } else if (required) {
      fail(`${key} is MISSING or EMPTY`);
    } else {
      warn(`${key} not set (optional)`);
    }
  }
} else {
  fail(".env file not found — make sure you're running from project root");
}

// ─── CHECK 9: shopify.app.v.toml sections ───
console.log("\n⚙️  SHOPIFY CONFIG:");
const tomlPath = path.join(ROOT, "shopify.app.v.toml");
if (fs.existsSync(tomlPath)) {
  const toml = fs.readFileSync(tomlPath, "utf8");
  const requiredSections = ["[auth]", "[access_scopes]", "[build]"];
  
  for (const section of requiredSections) {
    if (toml.includes(section)) pass(`${section} section present in shopify.app.v.toml`);
    else fail(`${section} section MISSING from shopify.app.v.toml`);
  }
} else {
  warn("shopify.app.v.toml not found (not in ZIP)");
}

// ─── CHECK 10: Syntax check (brace/paren/bracket balance) ───
console.log("\n🔧 SYNTAX CHECK:");
{
  let braceCount = 0, parenCount = 0, bracketCount = 0;
  let inString = false, stringChar = "", inTemplate = false, inComment = false, inLineComment = false;
  for (let i = 0; i < code.length; i++) {
    const ch = code[i];
    const prev = i > 0 ? code[i-1] : "";
    const next = i < code.length - 1 ? code[i+1] : "";
    if (!inString && !inTemplate && !inComment && ch === "/" && next === "/") { inLineComment = true; continue; }
    if (inLineComment && ch === "\n") { inLineComment = false; continue; }
    if (inLineComment) continue;
    if (!inString && !inTemplate && ch === "/" && next === "*") { inComment = true; continue; }
    if (inComment && ch === "*" && next === "/") { inComment = false; i++; continue; }
    if (inComment) continue;
    if (!inString && !inTemplate && (ch === '"' || ch === "'") && prev !== "\\") { inString = true; stringChar = ch; continue; }
    if (inString && ch === stringChar && prev !== "\\") { inString = false; continue; }
    if (inString) continue;
    if (!inString && ch === "`" && prev !== "\\") { inTemplate = !inTemplate; continue; }
    if (inTemplate) continue;
    if (ch === "{") braceCount++;
    else if (ch === "}") braceCount--;
    else if (ch === "(") parenCount++;
    else if (ch === ")") parenCount--;
    else if (ch === "[") bracketCount++;
    else if (ch === "]") bracketCount--;
  }
  if (braceCount === 0) pass("Brace balance: OK");
  else fail("Brace imbalance: " + (braceCount > 0 ? braceCount + " unclosed {" : Math.abs(braceCount) + " extra }"));
  if (parenCount === 0) pass("Paren balance: OK");
  else fail("Paren imbalance: " + (parenCount > 0 ? parenCount + " unclosed (" : Math.abs(parenCount) + " extra )"));
  if (bracketCount === 0) pass("Bracket balance: OK");
  else fail("Bracket imbalance: " + (bracketCount > 0 ? bracketCount + " unclosed [" : Math.abs(bracketCount) + " extra ]"));
}

// ─── CHECK 11: ErrorBoundary coverage ───
console.log("\n🛡️  ERROR BOUNDARIES:");
const widgetNames = ["Market Intelligence", "Store Performance", "Top Missed Opportunity", "Health & Pulse", "Competitor Gap Finder", "Budget Simulator", "Ad Preview"];
let wrappedCount = 0;
for (const name of widgetNames) {
  // Check if there's a WidgetErrorBoundary wrapping near this widget
  const searchName = name.replace("&", "&amp;").replace("&", "&");
  if (code.includes(`label="${name}"`) || code.includes(`label="${searchName}"`)) {
    wrappedCount++;
  }
}
// Also count by WidgetErrorBoundary occurrences
const ebCount = (code.match(/WidgetErrorBoundary/g) || []).length;
pass(`${Math.floor(ebCount / 2)} WidgetErrorBoundary instances found (open+close tags)`);

// ─── CHECK 12: No debug console.log in production code ───
console.log("\n🔍 PRODUCTION READINESS:");
{
  const debugLines = lines.filter((l,i) => 
    (l.includes("console.log") && (l.includes("[DEBUG") || l.includes("[debug"))) &&
    !l.trim().startsWith("//")  
  );
  if (debugLines.length > 0) {
    fail("Found " + debugLines.length + " debug console.log statements");
    debugLines.slice(0,3).forEach(l => console.log("      " + l.trim().substring(0,80)));
  } else {
    pass("No debug console.log statements in production code");
  }
}

// ─── CHECK 13: No sessionStorage in useState initializers ───
{
  const badLines = [];
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes("useState") && lines[i].includes("sessionStorage")) {
      badLines.push(i + 1);
    }
  }
  if (badLines.length > 0) {
    fail("sessionStorage inside useState() at lines: " + badLines.join(", ") + " (hydration mismatch)");
  } else {
    pass("No sessionStorage in useState initializers");
  }
}

// ─── CHECK 14: Syntax check ALL .jsx component files ───
console.log("\n🔧 MULTI-FILE SYNTAX CHECK:");
{
  const componentFiles = [
    "app/components/ScanningScreen.jsx",
    "app/components/AutoScreens.jsx",
    "app/components/GlobalModals.jsx",
    "app/components/DashboardView.jsx",
    "app/components/SubscriberHome.jsx",
    "app/components/Modals.jsx",
    "app/components/ProductModal.jsx",
    "app/components/CompetitorModal.jsx",
    "app/components/LaunchChoiceDialog.jsx",
    "app/components/dashboard/LivePulse.jsx",
    "app/routes/DashboardWidgets.jsx",
    "app/routes/CompetitorComponents.jsx",
    "app/routes/LandingComponents.jsx",
    "app/routes/SmallComponents.jsx",
    "app/routes/AdPreviewPanel.jsx",
    "app/routes/MarketAlert.jsx",
    "app/routes/StoreAnalytics.jsx",
    "app/routes/CollectingDataScreen.jsx",
    "app/stores/useAppStore.js",
  ];
  
  function checkBalance(src) {
    // Simple raw character count — works for well-formed JSX
    // (string literals and comments contain balanced braces in practice)
    let braceCount = 0, parenCount = 0, bracketCount = 0;
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      if (ch === "{") braceCount++;
      else if (ch === "}") braceCount--;
      else if (ch === "(") parenCount++;
      else if (ch === ")") parenCount--;
      else if (ch === "[") bracketCount++;
      else if (ch === "]") bracketCount--;
    }
    return { braceCount, parenCount, bracketCount };
  }
  
  let allGood = true;
  let checkedCount = 0;
  for (const file of componentFiles) {
    const fullPath = path.join(ROOT, file);
    if (!fs.existsSync(fullPath)) {
      warn(file + " not found — skipping");
      continue;
    }
    const src = fs.readFileSync(fullPath, "utf8");
    const { braceCount, parenCount, bracketCount } = checkBalance(src);
    checkedCount++;
    const fileShort = file.split("/").pop();
    if (braceCount !== 0 || parenCount !== 0 || bracketCount !== 0) {
      const issues = [];
      if (braceCount !== 0) issues.push("braces:" + braceCount);
      if (parenCount !== 0) issues.push("parens:" + parenCount);
      if (bracketCount !== 0) issues.push("brackets:" + bracketCount);
      fail(fileShort + " has balance issues: " + issues.join(", "));
      allGood = false;
    }
  }
  if (allGood) pass("All " + checkedCount + " component files have balanced syntax");
}

// ─── CHECK 15: Zustand store contract — verify all used state keys exist in store ───
console.log("\n🔗 ZUSTAND CONTRACT:");
{
  const storePath = path.join(ROOT, "app/stores/useAppStore.js");
  if (fs.existsSync(storePath)) {
    const storeCode = fs.readFileSync(storePath, "utf8");
    
    // Extract all top-level keys from store (state + actions)
    const storeKeys = new Set();
    const keyPattern = /^\s+(\w+)\s*[:=]/gm;
    let m;
    while ((m = keyPattern.exec(storeCode)) !== null) {
      storeKeys.add(m[1]);
    }
    
    // Files that use useAppStore
    const zustandConsumers = [
      "app/components/ScanningScreen.jsx",
      "app/components/AutoScreens.jsx",
      "app/components/GlobalModals.jsx",
      "app/components/DashboardView.jsx",
      "app/routes/app._index.jsx",
    ];
    
    let contractOk = true;
    for (const file of zustandConsumers) {
      const fullPath = path.join(ROOT, file);
      if (!fs.existsSync(fullPath)) continue;
      const src = fs.readFileSync(fullPath, "utf8");
      
      // Find destructured keys from useAppStore()
      const destructurePattern = /}\s*=\s*useAppStore\(/;
      if (!destructurePattern.test(src)) continue;
      
      // Extract destructured variable names
      const blockMatch = src.match(/const\s*\{([^}]+)\}\s*=\s*useAppStore/);
      if (!blockMatch) continue;
      
      const destructured = blockMatch[1]
        .split(",")
        .map(s => s.trim().split(":")[0].trim().replace(/\.\.\./, ""))
        .filter(s => s && !s.startsWith("//"));
      
      const fileShort = file.split("/").pop();
      const missing = destructured.filter(k => !storeKeys.has(k));
      if (missing.length > 0) {
        fail(fileShort + " reads keys not in store: " + missing.join(", "));
        contractOk = false;
      }
    }
    if (contractOk) pass("All Zustand consumers read only valid store keys");
  } else {
    fail("useAppStore.js not found");
  }
}

// ─── CHECK 16: Component files that use useAppStore must import it ───
console.log("\n📦 ZUSTAND IMPORTS:");
{
  const jsxFiles = [];
  function scanDir(dir) {
    if (!fs.existsSync(dir)) return;
    for (const f of fs.readdirSync(dir)) {
      const full = path.join(dir, f);
      const stat = fs.statSync(full);
      if (stat.isDirectory()) scanDir(full);
      else if (f.endsWith(".jsx") || f.endsWith(".js")) jsxFiles.push(full);
    }
  }
  scanDir(path.join(ROOT, "app/components"));
  scanDir(path.join(ROOT, "app/routes"));
  
  let importOk = true;
  for (const file of jsxFiles) {
    const src = fs.readFileSync(file, "utf8");
    // If file uses useAppStore() but doesn't import it
    if (src.includes("useAppStore()") && !src.includes("import") && !src.includes("useAppStore")) {
      // Actually double check: import useAppStore or require useAppStore
      if (!src.includes("from") || !src.includes("useAppStore")) {
        const fileShort = path.relative(ROOT, file);
        fail(fileShort + " uses useAppStore() without importing it");
        importOk = false;
      }
    }
  }
  if (importOk) pass("All useAppStore consumers have correct imports");
}

// ─── CHECK 17: No duplicate GlobalModals rendering ───
console.log("\n🎭 GLOBAL MODALS:");
{
  const indexSrc = fs.readFileSync(path.join(ROOT, "app/routes/app._index.jsx"), "utf8");
  const gmCount = (indexSrc.match(/<GlobalModals/g) || []).length;
  
  // Check child components don't render GlobalModals
  const childFiles = [
    "app/components/DashboardView.jsx",
    "app/components/SubscriberHome.jsx",
    "app/components/ScanningScreen.jsx",
    "app/components/AutoScreens.jsx",
  ];
  
  let childGM = false;
  for (const file of childFiles) {
    const fullPath = path.join(ROOT, file);
    if (!fs.existsSync(fullPath)) continue;
    const src = fs.readFileSync(fullPath, "utf8");
    if (src.includes("<GlobalModals")) {
      fail(file.split("/").pop() + " renders GlobalModals (should only be in app._index.jsx)");
      childGM = true;
    }
  }
  
  if (!childGM) pass("GlobalModals only rendered in app._index.jsx (" + gmCount + " instances for " + gmCount + " code paths)");
}

// ─── SUMMARY ───
console.log("\n═══════════════════════════════════════════════════");
console.log(`  RESULTS: ${passed} passed, ${failed} failed, ${warnings} warnings`);
console.log("═══════════════════════════════════════════════════");

if (failed > 0) {
  console.log("\n🚨 PREFLIGHT FAILED — DO NOT DEPLOY");
  console.log("   Fix the issues above before making any changes.\n");
  process.exit(1);
} else if (warnings > 0) {
  console.log("\n⚠️  PREFLIGHT PASSED WITH WARNINGS");
  console.log("   Review warnings above. Safe to proceed with caution.\n");
  process.exit(0);
} else {
  console.log("\n🎉 PREFLIGHT PASSED — ALL CLEAR!");
  console.log("   Safe to proceed with changes.\n");
  process.exit(0);
}
