// app/routes/app.api.state.js
// ════════════════════════════════════════════
// Persistent user state API (replaces sessionStorage)
// GET  → Load user state from DB
// POST → Save user state to DB
// ════════════════════════════════════════════
import { authenticate } from "../shopify.server";
import prisma from "../db.server.js";

// GET: Load state
export const loader = async ({ request }) => {
  try {
    const { session } = await authenticate.admin(request);
    const shop = session.shop;

    const state = await prisma.userState.findUnique({ where: { shop } });
    if (!state) {
      return Response.json({ success: true, state: null });
    }

    // Parse JSON fields
    return Response.json({
      success: true,
      state: {
        selectedPlan: state.selectedPlan,
        scanCredits: state.scanCredits,
        aiCredits: state.aiCredits,
        campaignId: state.campaignId,
        campaignIntent: state.campaignIntent,
        lastScanProducts: state.lastScanProducts ? JSON.parse(state.lastScanProducts) : null,
        lastAiResults: state.lastAiResults ? JSON.parse(state.lastAiResults) : null,
        autoScanMode: state.autoScanMode,
        showDashboard: state.showDashboard,
        justSubscribed: state.justSubscribed,
      },
    });
  } catch (err) {
    console.error("[SmartAds] State GET error:", err.message);
    return Response.json({ success: false, error: err.message }, { status: 500 });
  }
};

// POST: Save state (partial update — only saves fields that are sent)
export const action = async ({ request }) => {
  try {
    const { session } = await authenticate.admin(request);
    const shop = session.shop;
    const body = await request.json();

    // Build update data — only include fields that were sent
    const data = {};
    if (body.selectedPlan !== undefined) data.selectedPlan = body.selectedPlan;
    if (body.scanCredits !== undefined) data.scanCredits = Number(body.scanCredits) || 0;
    if (body.aiCredits !== undefined) data.aiCredits = Number(body.aiCredits) || 0;
    if (body.campaignId !== undefined) data.campaignId = body.campaignId;
    if (body.campaignIntent !== undefined) data.campaignIntent = body.campaignIntent;
    if (body.lastScanProducts !== undefined) data.lastScanProducts = JSON.stringify(body.lastScanProducts);
    if (body.lastAiResults !== undefined) data.lastAiResults = JSON.stringify(body.lastAiResults);
    if (body.autoScanMode !== undefined) data.autoScanMode = body.autoScanMode;
    if (body.showDashboard !== undefined) data.showDashboard = Boolean(body.showDashboard);
    if (body.justSubscribed !== undefined) data.justSubscribed = Boolean(body.justSubscribed);

    await prisma.userState.upsert({
      where: { shop },
      create: { shop, ...data },
      update: data,
    });

    return Response.json({ success: true });
  } catch (err) {
    console.error("[SmartAds] State POST error:", err.message);
    return Response.json({ success: false, error: err.message }, { status: 500 });
  }
};
