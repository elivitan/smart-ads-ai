import { useLoaderData } from "react-router";
import { authenticate } from "../shopify.server";
import { useState, useCallback } from "react";

export const loader = async ({ request }) => {
  await authenticate.admin(request);
  const mockCampaigns = [
    {
      id: "camp_001", name: "Summer Bedding Collection", type: "auto", status: "PENDING_REVIEW",
      createdAt: "2026-03-05T10:00:00Z", budget: 25,
      products: [
        { id:"p1", title:"Luxury Cotton Duvet Cover", image:null },
        { id:"p2", title:"Bamboo Pillow Set", image:null },
        { id:"p3", title:"Microfiber Sheet Set", image:null }
      ],
      keywords: [
        { text:"luxury bedding sets", bid:1.20 },
        { text:"cotton duvet cover queen", bid:0.95 },
        { text:"bamboo pillow case", bid:0.80 },
        { text:"microfiber sheets king", bid:0.75 },
        { text:"soft bedding online", bid:0.60 }
      ],
      headlines: ["Premium Bedding — Shop Now","Luxury Cotton Sheets & Covers","Free Shipping on All Orders"],
      descriptions: [
        "Transform your bedroom with our luxury bedding collection. Soft, durable, and beautiful.",
        "Shop premium cotton duvets, bamboo pillows & more. Fast US shipping."
      ],
      performance: { impressions:4200, clicks:180, roas:2.8, spend:312, today_clicks:12, today_spend:18 },
    },
    {
      id: "camp_002", name: "Winter Pillows — Manual", type: "manual", status: "ENABLED",
      createdAt: "2026-03-01T08:00:00Z", budget: 40,
      products: [
        { id:"p4", title:"Memory Foam Pillow King", image:null },
        { id:"p5", title:"Down Alternative Pillow", image:null }
      ],
      keywords: [
        { text:"memory foam pillow", bid:1.50 },
        { text:"best pillow for neck pain", bid:1.10 },
        { text:"king size pillow set", bid:0.90 },
        { text:"down alternative pillow", bid:0.70 }
      ],
      headlines: ["Best Pillows for Deep Sleep","Memory Foam King Pillows","Free US Shipping Over $50"],
      descriptions: [
        "Wake up refreshed with our premium memory foam pillows. Designed for all sleep positions.",
        "Shop our full pillow collection. Trusted by 10,000+ sleepers. Fast delivery."
      ],
      performance: { impressions:8900, clicks:410, roas:3.4, spend:520, today_clicks:28, today_spend:31 },
    },
  ];
  return { campaigns: mockCampaigns };
};

/* ── helpers ── */
function roasColor(roas) {
  if (roas >= 3) return { color:"#10b981", bg:"rgba(16,185,129,.12)", label:"Excellent" };
  if (roas >= 2) return { color:"#f59e0b", bg:"rgba(245,158,11,.12)", label:"Good" };
  if (roas > 0)  return { color:"#ef4444", bg:"rgba(239,68,68,.12)", label:"Low" };
  return { color:"#94a3b8", bg:"rgba(148,163,184,.1)", label:"No data" };
}

function statusDot(status) {
  if (status === "ENABLED") return "#10b981";
  if (status === "PENDING_REVIEW") return "#f59e0b";
  if (status === "PAUSED") return "#94a3b8";
  return "#ef4444";
}

/* ── Launch Dialog ── */
function LaunchDialog({ onClose }) {
  return (
    <div style={{ position:"fixed",inset:0,background:"rgba(10,10,26,.75)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",backdropFilter:"blur(4px)" }} onClick={onClose}>
      <div style={{ background:"#fff",borderRadius:24,padding:36,maxWidth:500,width:"90%",boxShadow:"0 24px 80px rgba(0,0,0,.25)" }} onClick={e => e.stopPropagation()}>
        <div style={{ width:48,height:48,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,marginBottom:16 }}>{"\u{1F680}"}</div>
        <h2 style={{ fontSize:22,fontWeight:800,color:"#1a1a2e",marginBottom:6,marginTop:0 }}>Create New Campaign</h2>
        <p style={{ fontSize:14,color:"#64748b",marginBottom:24 }}>Choose how you want to build your next campaign:</p>
        <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
          <div style={{ display:"flex",alignItems:"center",gap:16,padding:"20px",borderRadius:16,border:"2px solid #6366f1",background:"linear-gradient(135deg,#f5f3ff,#ede9fe)",cursor:"pointer" }} onClick={onClose}>
            <div style={{ width:44,height:44,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>{"⚡"}</div>
            <div><div style={{ fontSize:15,fontWeight:700,color:"#1a1a2e",marginBottom:2 }}>Auto Launch</div><div style={{ fontSize:13,color:"#64748b" }}>AI scans, builds and launches campaigns instantly</div></div>
            <div style={{ marginLeft:"auto",color:"#6366f1",fontSize:18 }}>{"→"}</div>
          </div>
          <div style={{ display:"flex",alignItems:"center",gap:16,padding:"20px",borderRadius:16,border:"2px solid #e2e8f0",background:"#f8fafc",cursor:"pointer" }} onClick={onClose}>
            <div style={{ width:44,height:44,background:"linear-gradient(135deg,#0891b2,#0284c7)",borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0 }}>{"🔍"}</div>
            <div><div style={{ fontSize:15,fontWeight:700,color:"#1a1a2e",marginBottom:2 }}>Review & Edit</div><div style={{ fontSize:13,color:"#64748b" }}>Check keywords, headlines & images before launching</div></div>
            <div style={{ marginLeft:"auto",color:"#64748b",fontSize:18 }}>{"→"}</div>
          </div>
        </div>
        <button onClick={onClose} style={{ marginTop:16,width:"100%",padding:"11px",background:"none",border:"1px solid #e2e8f0",borderRadius:12,color:"#94a3b8",fontSize:14,cursor:"pointer",fontFamily:"inherit" }}>Cancel</button>
      </div>
    </div>
  );
}

/* ── Sidebar ── */
function CampaignSidebar({ campaigns, selectedId, onSelect, onNew }) {
  return (
    <div style={{ background:"#fafafa",borderRight:"1px solid #f1f5f9",padding:"16px",overflowY:"auto",display:"flex",flexDirection:"column",gap:8 }}>
      <div style={{ fontSize:10,fontWeight:700,color:"#cbd5e1",letterSpacing:2,marginBottom:6,textTransform:"uppercase",paddingLeft:2 }}>Campaigns</div>
      {campaigns.map(c => {
        const sel = c.id === selectedId;
        const rc = roasColor(c.performance.roas);
        return (
          <div key={c.id} onClick={() => onSelect(c.id)} style={{ background:sel?"#fff":"transparent",border:sel?"1.5px solid #e2e8f0":"1.5px solid transparent",borderRadius:14,padding:"14px",cursor:"pointer",transition:"all .15s",boxShadow:sel?"0 2px 8px rgba(0,0,0,.06)":"none" }}>
            <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:8 }}>
              <span style={{ width:8,height:8,borderRadius:"50%",background:statusDot(c.status),display:"inline-block",flexShrink:0 }} />
              <span style={{ fontSize:13,fontWeight:700,color:"#1a1a2e",flex:1,lineHeight:1.3 }}>{c.name}</span>
              <span style={{ fontSize:10,fontWeight:700,color:c.type==="auto"?"#6366f1":"#0891b2",background:c.type==="auto"?"#ede9fe":"#e0f2fe",padding:"2px 7px",borderRadius:5 }}>{c.type==="auto"?"AUTO":"MANUAL"}</span>
            </div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6 }}>
              <div style={{ background:rc.bg,borderRadius:8,padding:"7px 8px",textAlign:"center" }}>
                <div style={{ fontSize:15,fontWeight:800,color:rc.color }}>{c.performance.roas>0?(c.performance.roas+"x"):"—"}</div>
                <div style={{ fontSize:9,color:rc.color,fontWeight:600,textTransform:"uppercase",letterSpacing:.3 }}>ROAS</div>
              </div>
              <div style={{ background:"#f8fafc",borderRadius:8,padding:"7px 8px",textAlign:"center" }}>
                <div style={{ fontSize:15,fontWeight:800,color:"#1a1a2e" }}>{c.performance.clicks>0?c.performance.clicks.toLocaleString():"—"}</div>
                <div style={{ fontSize:9,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:.3 }}>Clicks</div>
              </div>
              <div style={{ background:"#f8fafc",borderRadius:8,padding:"7px 8px",textAlign:"center" }}>
                <div style={{ fontSize:15,fontWeight:800,color:"#1a1a2e" }}>{c.performance.spend>0?("$"+c.performance.spend):"—"}</div>
                <div style={{ fontSize:9,color:"#94a3b8",fontWeight:600,textTransform:"uppercase",letterSpacing:.3 }}>Spend</div>
              </div>
            </div>
          </div>
        );
      })}
      <button onClick={onNew} style={{ display:"flex",alignItems:"center",justifyContent:"center",gap:6,width:"100%",fontSize:13,color:"#6366f1",fontWeight:600,marginTop:4,padding:"11px",borderRadius:12,border:"2px dashed #c7d2fe",background:"none",cursor:"pointer",fontFamily:"inherit" }}>{"＋"} New campaign</button>
    </div>
  );
}

/* ── Budget Slider (custom div-based for Shopify iframe) ── */
function BudgetSlider({ value, onChange }) {
  const min = 5, max = 500;
  const pct = ((value - min) / (max - min)) * 100;
  const markers = [5, 25, 50, 100, 200, 500];

  const handleTrackClick = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const newVal = Math.round(min + (x / rect.width) * (max - min));
    onChange(Math.max(min, Math.min(max, newVal)));
  }, [onChange]);

  const handleDrag = useCallback((e) => {
    e.preventDefault();
    const track = e.currentTarget.closest('.budget-sim-slider');
    if (!track) return;
    const move = (ev) => {
      const rect = track.getBoundingClientRect();
      const clientX = ev.touches ? ev.touches[0].clientX : ev.clientX;
      const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
      const newVal = Math.round(min + (x / rect.width) * (max - min));
      onChange(Math.max(min, Math.min(max, newVal)));
    };
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('touchend', up);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
    document.addEventListener('touchmove', move, { passive: false });
    document.addEventListener('touchend', up);
  }, [onChange]);

  return (
    <div style={{ marginTop:8 }}>
      <div className="budget-sim-slider" onClick={handleTrackClick}
        style={{ position:"relative",height:8,background:"#e2e8f0",borderRadius:4,cursor:"pointer",zIndex:9999,touchAction:"none",userSelect:"none" }}>
        <div style={{ position:"absolute",left:0,top:0,height:"100%",width:pct+"%",background:"linear-gradient(90deg,#6366f1,#8b5cf6)",borderRadius:4 }} />
        <div onMouseDown={handleDrag} onTouchStart={handleDrag}
          style={{ position:"absolute",top:"50%",left:pct+"%",transform:"translate(-50%,-50%)",width:22,height:22,borderRadius:"50%",background:"#fff",border:"3px solid #6366f1",boxShadow:"0 2px 8px rgba(99,102,241,.3)",cursor:"grab",zIndex:10000,touchAction:"none" }} />
      </div>
      <div className="budget-sim-input-row" style={{ display:"flex",justifyContent:"space-between",marginTop:10,zIndex:9999,touchAction:"none" }}>
        {markers.map(m => (
          <button key={m} onClick={() => onChange(m)}
            style={{ fontSize:11,fontWeight:m===value?700:500,color:m===value?"#6366f1":"#94a3b8",background:m===value?"#ede9fe":"transparent",border:"none",borderRadius:6,padding:"3px 8px",cursor:"pointer",fontFamily:"inherit" }}>
            {"$"+m}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── CharCounter input ── */
/* ── CharCounter input (improved) ── */
function CharInput({ defaultValue, maxLen, tag, placeholder }) {
  const [val, setVal] = useState(defaultValue || "");
  const remaining = maxLen - val.length;
  const isClose = remaining <= 5;
  const isOver = remaining < 0;
  const Tag = tag || "input";
  const pct = Math.min(100, (val.length / maxLen) * 100);
  return (
    <div style={{ position:"relative",marginBottom:10 }}>
      <Tag
        value={val}
        onChange={e => setVal(e.target.value)}
        maxLength={maxLen}
        placeholder={placeholder || ""}
        rows={tag === "textarea" ? 3 : undefined}
        style={{
          width:"100%",fontSize:14,color:"#1a1a2e",
          border:"2px solid "+(isOver?"#ef4444":isClose?"#f59e0b":"#e2e8f0"),
          borderRadius:12,padding:tag==="textarea"?"12px 14px":"12px 14px",
          fontFamily:"inherit",boxSizing:"border-box",
          outline:"none",fontWeight:500,resize:"none",lineHeight:1.5,
          background:"#fff",
          transition:"border-color .15s,box-shadow .15s"
        }}
        onFocus={e => { e.target.style.borderColor = isOver?"#ef4444":"#6366f1"; e.target.style.boxShadow = "0 0 0 3px rgba(99,102,241,.1)"; }}
        onBlur={e => { e.target.style.borderColor = isOver?"#ef4444":isClose?"#f59e0b":"#e2e8f0"; e.target.style.boxShadow = "none"; }}
      />
      <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:6,padding:"0 2px" }}>
        <div style={{ flex:1,height:3,background:"#f1f5f9",borderRadius:2,overflow:"hidden" }}>
          <div style={{ width:pct+"%",height:"100%",background:isOver?"#ef4444":isClose?"#f59e0b":pct>50?"#6366f1":"#10b981",borderRadius:2,transition:"width .2s" }} />
        </div>
        <span style={{
          fontSize:12,fontWeight:700,marginLeft:10,
          color:isOver?"#ef4444":isClose?"#f59e0b":"#94a3b8"
        }}>
          {val.length}/{maxLen}
        </span>
      </div>
    </div>
  );
}

/* ── Campaign Detail (main panel) ── */
function CampaignDetail({ campaign, onSwitchMode, mode }) {
  const p = campaign.performance;
  const rc = roasColor(p.roas);
  const [paused, setPaused] = useState(campaign.status === "PAUSED");
  const [keywords, setKeywords] = useState(campaign.keywords);
  const [budget, setBudget] = useState(campaign.budget);
  const [newKw, setNewKw] = useState("");
  const [headlines, setHeadlines] = useState(campaign.headlines);
  const [descriptions, setDescriptions] = useState(campaign.descriptions);

  const addKeyword = () => {
    const text = newKw.trim();
    if (!text) return;
    setKeywords([...keywords, { text, bid: 0.50 }]);
    setNewKw("");
  };

  const updateBid = (index, newBid) => {
    const updated = [...keywords];
    updated[index] = { ...updated[index], bid: parseFloat(newBid) || 0 };
    setKeywords(updated);
  };

  const removeKeyword = (index) => {
    setKeywords(keywords.filter((_, i) => i !== index));
  };

  return (
    <div style={{ padding:"24px",overflowY:"auto",display:"flex",flexDirection:"column",gap:18 }}>

      {/* ── HERO PANEL ── */}
      <div style={{ background:"linear-gradient(135deg,#0f172a 0%,#1e293b 100%)",borderRadius:20,padding:"28px 32px",color:"#fff",position:"relative",overflow:"hidden" }}>
        <div style={{ position:"absolute",top:-30,right:-30,width:160,height:160,borderRadius:"50%",background:"rgba(99,102,241,.08)" }} />
        <div style={{ position:"absolute",bottom:-40,right:80,width:120,height:120,borderRadius:"50%",background:"rgba(99,102,241,.05)" }} />

        <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",flexWrap:"wrap",gap:16,position:"relative",zIndex:1 }}>
          <div>
            <div style={{ fontSize:11,fontWeight:700,color:"rgba(255,255,255,.4)",letterSpacing:2,textTransform:"uppercase",marginBottom:10 }}>{campaign.name}</div>
            <div style={{ display:"flex",alignItems:"baseline",gap:10,marginBottom:6 }}>
              <span style={{ fontSize:60,fontWeight:900,letterSpacing:"-3px",color:rc.color,lineHeight:1 }}>
                {p.roas > 0 ? (p.roas + "x") : "—"}
              </span>
              <span style={{ fontSize:18,fontWeight:700,color:"rgba(255,255,255,.4)" }}>ROAS</span>
              <span style={{
                fontSize:12,fontWeight:700,color:rc.color,background:rc.bg,
                padding:"4px 10px",borderRadius:20,marginLeft:4
              }}>{rc.label}</span>
            </div>
            <div style={{ fontSize:13,color:"rgba(255,255,255,.45)",fontWeight:500 }}>
              {"$"}{p.spend} total spend {"·"} {"$"}{campaign.budget}/day {"·"} {campaign.products.length} products
            </div>
          </div>
          <div style={{ display:"flex",gap:8,alignItems:"center" }}>
            <button onClick={() => setPaused(!paused)} style={{ fontSize:13,fontWeight:700,color:"#fff",background:paused?"#10b981":"rgba(255,255,255,.12)",border:"1px solid "+(paused?"#10b981":"rgba(255,255,255,.15)"),borderRadius:10,padding:"10px 18px",cursor:"pointer",fontFamily:"inherit",transition:"all .2s" }}>
              {paused ? "▶ Resume" : "⏸ Pause"}
            </button>
            <button onClick={onSwitchMode} style={{ fontSize:13,fontWeight:700,color:"#fff",background:"rgba(255,255,255,.08)",border:"1px solid rgba(255,255,255,.15)",borderRadius:10,padding:"10px 18px",cursor:"pointer",fontFamily:"inherit" }}>
              {mode === "auto" ? "✏️ Manual" : "🤖 Auto"}
            </button>
          </div>
        </div>

        {/* TODAY STATS STRIP */}
        <div style={{ display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:8,marginTop:24,paddingTop:20,borderTop:"1px solid rgba(255,255,255,.06)" }}>
          {[
            { value: p.today_clicks, label: "Today Clicks" },
            { value: "$" + p.today_spend, label: "Today Spend" },
            { value: p.clicks.toLocaleString(), label: "Total Clicks" },
            { value: p.impressions.toLocaleString(), label: "Impressions" },
            { value: p.clicks > 0 ? (p.clicks / p.impressions * 100).toFixed(1) + "%" : "—", label: "CTR" },
          ].map(m => (
            <div key={m.label} style={{ textAlign:"center" }}>
              <div style={{ fontSize:22,fontWeight:800,color:"#fff",marginBottom:3 }}>{m.value}</div>
              <div style={{ fontSize:9,color:"rgba(255,255,255,.35)",fontWeight:600,textTransform:"uppercase",letterSpacing:.5 }}>{m.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* PENDING REVIEW BANNER */}
      {campaign.status === "PENDING_REVIEW" && (
        <div style={{ background:"linear-gradient(135deg,#fffbeb,#fef3c7)",border:"1px solid #fcd34d",borderRadius:14,padding:"14px 18px",display:"flex",alignItems:"center",gap:12 }}>
          <span style={{ fontSize:20 }}>⏳</span>
          <div>
            <div style={{ fontSize:14,fontWeight:700,color:"#92400e" }}>Pending Google Review</div>
            <div style={{ fontSize:13,color:"#b45309" }}>Awaiting Google Ads approval — usually 1–2 business days.</div>
          </div>
        </div>
      )}

      {/* ═══════════════ MANUAL MODE ═══════════════ */}
      {mode === "manual" && (
        <>
          {/* Manual Control Banner */}
          <div style={{ background:"linear-gradient(135deg,#fff7ed,#ffedd5)",border:"2px solid #fed7aa",borderRadius:14,padding:"14px 20px",display:"flex",alignItems:"center",gap:12 }}>
            <div style={{ width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,#f97316,#ea580c)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,color:"#fff",fontWeight:800 }}>✏️</div>
            <div>
              <div style={{ fontSize:14,fontWeight:700,color:"#c2410c" }}>Manual Control Mode</div>
              <div style={{ fontSize:12,color:"#ea580c" }}>You control budget, keywords, bids & ad copy directly</div>
            </div>
          </div>

          {/* 1. DAILY BUDGET */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"22px 24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:14 }}>💰 Daily Budget</div>
            <div style={{ display:"flex",alignItems:"baseline",gap:6 }}>
              <span style={{ fontSize:20,fontWeight:700,color:"#6366f1" }}>$</span>
              <span style={{ fontSize:48,fontWeight:900,color:"#1a1a2e",letterSpacing:"-2px",lineHeight:1 }}>{budget}</span>
              <span style={{ fontSize:14,color:"#94a3b8",marginLeft:8 }}>/ day</span>
              <span style={{ fontSize:13,color:"#cbd5e1",marginLeft:4 }}>· ~{"$"}{(budget * 30).toLocaleString()}/mo</span>
            </div>
            <BudgetSlider value={budget} onChange={setBudget} />
          </div>

          {/* 2. KEYWORDS */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"22px 24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:14 }}>🔑 Keywords ({keywords.length})</div>
            <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
              {keywords.map((kw, i) => (
                <div key={i} style={{ display:"flex",alignItems:"center",gap:12,padding:"10px 14px",background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:12 }}>
                  <span style={{ flex:1,fontSize:14,color:"#1a1a2e",fontWeight:600 }}>{kw.text}</span>
                  <div style={{ display:"flex",alignItems:"center",gap:6,background:"#fff",border:"1px solid #e2e8f0",borderRadius:8,padding:"4px 8px" }}>
                    <span style={{ fontSize:12,color:"#94a3b8",fontWeight:600 }}>CPC $</span>
                    <input
                      type="number" step="0.05" min="0.05" max="50"
                      value={kw.bid}
                      onChange={e => updateBid(i, e.target.value)}
                      style={{ width:55,fontSize:14,fontWeight:700,color:"#6366f1",border:"none",background:"transparent",textAlign:"center",fontFamily:"inherit",outline:"none" }}
                    />
                  </div>
                  <button onClick={() => removeKeyword(i)} style={{ width:28,height:28,borderRadius:8,background:"#fee2e2",color:"#ef4444",border:"none",cursor:"pointer",fontSize:16,fontFamily:"inherit",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontWeight:700 }}>×</button>
                </div>
              ))}
            </div>
            {/* Add keyword */}
            <div style={{ display:"flex",gap:8,marginTop:12 }}>
              <input
                value={newKw}
                onChange={e => setNewKw(e.target.value)}
                onKeyDown={e => e.key === "Enter" && addKeyword()}
                placeholder="Add new keyword..."
                style={{ flex:1,fontSize:14,border:"2px dashed #e2e8f0",borderRadius:12,padding:"10px 14px",fontFamily:"inherit",outline:"none",color:"#374151",background:"#fafafa" }}
              />
              <button onClick={addKeyword} style={{ fontSize:13,fontWeight:700,color:"#fff",background:"linear-gradient(135deg,#6366f1,#8b5cf6)",border:"none",borderRadius:12,padding:"10px 20px",cursor:"pointer",fontFamily:"inherit",whiteSpace:"nowrap" }}>＋ Add</button>
            </div>
          </div>

          {/* 3. HEADLINES */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"22px 24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14 }}>
              <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase" }}>📢 Headlines ({campaign.headlines.length})</div>
              <div style={{ fontSize:11,color:"#94a3b8" }}>Max 30 characters each</div>
            </div>
            {campaign.headlines.map((h, i) => (
              <CharInput key={"h"+i} defaultValue={h} maxLen={30} placeholder={"Headline " + (i+1)} />
            ))}
          </div>

          {/* 4. DESCRIPTIONS */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"22px 24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14 }}>
              <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase" }}>📄 Descriptions ({campaign.descriptions.length})</div>
              <div style={{ fontSize:11,color:"#94a3b8" }}>Max 90 characters each</div>
            </div>
            {campaign.descriptions.map((d, i) => (
              <CharInput key={"d"+i} defaultValue={d} maxLen={90} tag="textarea" placeholder={"Description " + (i+1)} />
            ))}
          </div>
        </>
      )}

      {/* ═══════════════ AUTO MODE ═══════════════ */}
      {mode === "auto" && (
        <>
          {/* AI Managed Banner */}
          <div style={{ background:"linear-gradient(135deg,#ede9fe,#e0e7ff)",border:"2px solid #c7d2fe",borderRadius:14,padding:"16px 22px",display:"flex",alignItems:"center",gap:14 }}>
            <div style={{ width:42,height:42,borderRadius:12,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,color:"#fff",flexShrink:0 }}>🤖</div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:15,fontWeight:700,color:"#4338ca" }}>AI-Managed Campaign</div>
              <div style={{ fontSize:13,color:"#6366f1",marginTop:2 }}>Smart Ads AI continuously optimizes your keywords, bids & ad copy for maximum ROAS</div>
            </div>
            <div style={{ background:"#6366f1",color:"#fff",fontSize:11,fontWeight:700,padding:"5px 12px",borderRadius:20,whiteSpace:"nowrap" }}>✓ Active</div>
          </div>

          {/* Campaign Assets Summary - 4 cards */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:18 }}>📊 Campaign Assets</div>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:12 }}>
              <div style={{ background:"linear-gradient(135deg,#f5f3ff,#ede9fe)",borderRadius:14,padding:"18px 16px",textAlign:"center" }}>
                <div style={{ fontSize:28,fontWeight:900,color:"#6366f1",marginBottom:4 }}>{campaign.keywords.length}</div>
                <div style={{ fontSize:11,fontWeight:600,color:"#8b5cf6",textTransform:"uppercase",letterSpacing:.5 }}>Keywords</div>
                <div style={{ fontSize:11,color:"#a78bfa",marginTop:4 }}>Auto-optimized</div>
              </div>
              <div style={{ background:"linear-gradient(135deg,#eff6ff,#dbeafe)",borderRadius:14,padding:"18px 16px",textAlign:"center" }}>
                <div style={{ fontSize:28,fontWeight:900,color:"#3b82f6",marginBottom:4 }}>{campaign.headlines.length}</div>
                <div style={{ fontSize:11,fontWeight:600,color:"#3b82f6",textTransform:"uppercase",letterSpacing:.5 }}>Headlines</div>
                <div style={{ fontSize:11,color:"#60a5fa",marginTop:4 }}>AI-generated</div>
              </div>
              <div style={{ background:"linear-gradient(135deg,#f0fdf4,#dcfce7)",borderRadius:14,padding:"18px 16px",textAlign:"center" }}>
                <div style={{ fontSize:28,fontWeight:900,color:"#16a34a",marginBottom:4 }}>{campaign.descriptions.length}</div>
                <div style={{ fontSize:11,fontWeight:600,color:"#16a34a",textTransform:"uppercase",letterSpacing:.5 }}>Descriptions</div>
                <div style={{ fontSize:11,color:"#4ade80",marginTop:4 }}>AI-crafted</div>
              </div>
              <div style={{ background:"linear-gradient(135deg,#fff7ed,#ffedd5)",borderRadius:14,padding:"18px 16px",textAlign:"center" }}>
                <div style={{ fontSize:28,fontWeight:900,color:"#ea580c",marginBottom:4 }}>{"$"}{campaign.budget}</div>
                <div style={{ fontSize:11,fontWeight:600,color:"#ea580c",textTransform:"uppercase",letterSpacing:.5 }}>Daily Budget</div>
                <div style={{ fontSize:11,color:"#fb923c",marginTop:4 }}>{"~$"}{(campaign.budget*30).toLocaleString()}/mo</div>
              </div>
            </div>
          </div>

          {/* AI Performance Insights */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:18 }}>✨ AI Performance Insights</div>
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              <div style={{ display:"flex",alignItems:"center",gap:12,padding:"14px 16px",background:"linear-gradient(135deg,#f0fdf4,#dcfce7)",borderRadius:12,border:"1px solid #bbf7d0" }}>
                <div style={{ width:32,height:32,borderRadius:8,background:"#16a34a",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:"#fff",flexShrink:0 }}>🎯</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13,fontWeight:700,color:"#15803d" }}>Top Performing Keyword</div>
                  <div style={{ fontSize:13,color:"#16a34a",marginTop:2 }}>{campaign.keywords[0]?.text || "Analyzing..."} {"—"} {"$"}{campaign.keywords[0]?.bid.toFixed(2)} CPC</div>
                </div>
              </div>
              <div style={{ display:"flex",alignItems:"center",gap:12,padding:"14px 16px",background:"linear-gradient(135deg,#eff6ff,#dbeafe)",borderRadius:12,border:"1px solid #bfdbfe" }}>
                <div style={{ width:32,height:32,borderRadius:8,background:"#3b82f6",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:"#fff",flexShrink:0 }}>📝</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13,fontWeight:700,color:"#1d4ed8" }}>Best Headline</div>
                  <div style={{ fontSize:13,color:"#3b82f6",marginTop:2 }}>{campaign.headlines[0] || "Testing variations..."}</div>
                </div>
              </div>
              <div style={{ display:"flex",alignItems:"center",gap:12,padding:"14px 16px",background:"linear-gradient(135deg,#fefce8,#fef9c3)",borderRadius:12,border:"1px solid #fde68a" }}>
                <div style={{ width:32,height:32,borderRadius:8,background:"#eab308",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,color:"#fff",flexShrink:0 }}>🕒</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:13,fontWeight:700,color:"#a16207" }}>Optimization Status</div>
                  <div style={{ fontSize:13,color:"#ca8a04",marginTop:2 }}>Last optimized: 2 hours ago {"·"} Next review: Tomorrow 9:00 AM</div>
                </div>
              </div>
            </div>
          </div>

          {/* Recent AI Actions */}
          <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
            <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:18 }}>📋 Recent AI Actions</div>
            <div style={{ display:"flex",flexDirection:"column",gap:0 }}>
              {[
                { time:"2 hours ago", action:"Adjusted bid for \"luxury bedding sets\" from $1.10 to $1.20", icon:"💰" },
                { time:"Yesterday", action:"Added new headline: \"Premium Bedding — Shop Now\"", icon:"📝" },
                { time:"2 days ago", action:"Paused low-performing keyword: \"cheap bedding\"", icon:"⏸️" },
                { time:"3 days ago", action:"Increased daily budget recommendation to $30/day", icon:"📈" },
              ].map((item, i) => (
                <div key={i} style={{ display:"flex",alignItems:"flex-start",gap:12,padding:"12px 0",borderBottom:i < 3 ? "1px solid #f8fafc" : "none" }}>
                  <div style={{ width:28,height:28,borderRadius:7,background:"#f8fafc",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,flexShrink:0,marginTop:1 }}>{item.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:13,color:"#374151",fontWeight:500 }}>{item.action}</div>
                    <div style={{ fontSize:11,color:"#94a3b8",marginTop:3 }}>{item.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* PRODUCTS (always read-only) */}
      <div style={{ background:"#fff",border:"1px solid #f1f5f9",borderRadius:16,padding:"20px 24px",boxShadow:"0 1px 4px rgba(0,0,0,.04)" }}>
        <div style={{ fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1.5,textTransform:"uppercase",marginBottom:14 }}>🛍️ Products ({campaign.products.length})</div>
        <div style={{ display:"flex",gap:12,flexWrap:"wrap" }}>
          {campaign.products.map(prod => (
            <div key={prod.id} style={{ display:"flex",alignItems:"center",gap:10,background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:12,padding:"10px 16px" }}>
              <div style={{ width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,#ede9fe,#e0e7ff)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16 }}>🛏️</div>
              <span style={{ fontSize:13,fontWeight:600,color:"#374151" }}>{prod.title}</span>
            </div>
          ))}
        </div>
      </div>

      {/* SAVE CHANGES (manual only) */}
      {mode === "manual" && (
        <div style={{ display:"flex",justifyContent:"flex-end",paddingBottom:12 }}>
          <button style={{
            fontSize:15,fontWeight:700,color:"#fff",
            background:"linear-gradient(135deg,#6366f1,#8b5cf6)",
            border:"none",borderRadius:14,padding:"14px 32px",
            cursor:"pointer",fontFamily:"inherit",
            boxShadow:"0 4px 20px rgba(99,102,241,.3)",
            transition:"transform .1s,box-shadow .1s"
          }}>
            💾 Save Changes
          </button>
        </div>
      )}
    </div>
  );
}

/* ── Main Component ── */
export default function Campaigns() {
  const { campaigns } = useLoaderData();
  const [selectedId, setSelectedId] = useState(campaigns[0]?.id || null);
  const [viewMode, setViewMode] = useState({});
  const [showLaunchDialog, setShowLaunchDialog] = useState(false);

  const selected = campaigns.find(c => c.id === selectedId);
  const currentMode = viewMode[selectedId] !== undefined ? viewMode[selectedId] : (selected?.type || "auto");

  if (!campaigns || campaigns.length === 0) {
    return (
      <div style={{ padding:"40px",maxWidth:600,margin:"0 auto",fontFamily:"'DM Sans',system-ui,sans-serif",textAlign:"center" }}>
        <div style={{ width:72,height:72,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",borderRadius:20,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,margin:"0 auto 20px" }}>{"🚀"}</div>
        <h1 style={{ fontSize:28,fontWeight:800,color:"#1a1a2e",marginBottom:8 }}>No campaigns yet</h1>
        <p style={{ fontSize:15,color:"#64748b",marginBottom:32,lineHeight:1.6 }}>Create your first Google Ads campaign and start driving traffic to your store.</p>
        <button onClick={() => setShowLaunchDialog(true)} style={{ display:"inline-flex",alignItems:"center",gap:8,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff",fontSize:15,fontWeight:700,padding:"14px 28px",border:"none",borderRadius:12,cursor:"pointer",fontFamily:"inherit",boxShadow:"0 4px 20px rgba(99,102,241,.3)" }}>{"＋"} Create First Campaign</button>
        {showLaunchDialog && <LaunchDialog onClose={() => setShowLaunchDialog(false)} />}
      </div>
    );
  }

  return (
    <div style={{ fontFamily:"'DM Sans',system-ui,sans-serif",minHeight:"100vh",height:"auto",display:"flex",flexDirection:"column" }}>
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        .camp-fade{animation:fadeUp .25s ease forwards}
        ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:#e2e8f0;border-radius:4px}
        .budget-sim-slider{z-index:9999!important;touch-action:none!important;user-select:none!important}
        .budget-sim-input-row{z-index:9999!important;touch-action:none!important}
      `}</style>

      <div style={{ background:"#fff",borderBottom:"1px solid #f1f5f9",padding:"14px 24px",display:"flex",alignItems:"center",justifyContent:"space-between",flexShrink:0 }}>
        <div>
          <h1 style={{ fontSize:20,fontWeight:800,color:"#1a1a2e",margin:0,letterSpacing:"-0.5px" }}>Campaigns</h1>
          <p style={{ fontSize:12,color:"#94a3b8",margin:"2px 0 0",fontWeight:500 }}>{campaigns.length} active {"·"} Google Ads</p>
        </div>
        <button onClick={() => setShowLaunchDialog(true)} style={{ display:"inline-flex",alignItems:"center",gap:7,background:"linear-gradient(135deg,#6366f1,#8b5cf6)",color:"#fff",fontSize:13,fontWeight:700,padding:"9px 18px",borderRadius:10,border:"none",cursor:"pointer",fontFamily:"inherit",boxShadow:"0 2px 10px rgba(99,102,241,.3)" }}>{"＋"} New Campaign</button>
      </div>

      <div className="camp-fade" style={{ display:"grid",gridTemplateColumns:"280px 1fr",flex:1,minHeight:0,overflow:"auto" }}>
        <CampaignSidebar campaigns={campaigns} selectedId={selectedId} onSelect={setSelectedId} onNew={() => setShowLaunchDialog(true)} />
        {selected && (
          <CampaignDetail
            key={selectedId}
            campaign={selected}
            mode={currentMode}
            onSwitchMode={() => setViewMode(v => ({...v,[selectedId]:currentMode==="auto"?"manual":"auto"}))}
          />
        )}
      </div>

      {showLaunchDialog && <LaunchDialog onClose={() => setShowLaunchDialog(false)} />}
    </div>
  );
}
