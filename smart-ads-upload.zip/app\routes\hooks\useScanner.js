export function useScanner() {
  return {};
}
