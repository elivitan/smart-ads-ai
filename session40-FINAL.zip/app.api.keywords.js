import { authenticate } from "../shopify.server";
import { exploreKeywords, scanWebsite } from "../keyword-research.server";
import { z } from "zod";
import { logger } from "../utils/logger.js";
import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";

export const action = async ({ request }) => {
  let session;
  try {
    ({ session } = await authenticate.admin(request));
  } catch (authErr) {
    logger.error("keywords.action", "Auth failed", { error: authErr.message });
    return Response.json({ success: false, error: "Authentication failed" }, { status: 401 });
  }
  const shop = session.shop;

  // Rate limit check
  const rl = rateLimit.keywords(shop);
  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);
  const formData = await request.formData();
  const actionType = formData.get("actionType");

  try {
    if (actionType === "explore") {
      const keyword = formData.get("keyword");
      const location = formData.get("location") || "United States";
      if (!keyword) {
        return Response.json({ success: false, error: "Please enter a keyword" }, { status: 400 });
      }
      const result = await exploreKeywords(keyword, location);
      return Response.json({ success: true, ...result });
    }

    if (actionType === "scan") {
      const url = formData.get("url");
      if (!url) {
        return Response.json({ success: false, error: "Please enter a URL" }, { status: 400 });
      }
      const result = await scanWebsite(url);
      return Response.json({ success: true, ...result });
    }

    return Response.json({ success: false, error: "Unknown action" }, { status: 400 });
  } catch (err) {
    logger.error("keywords.action", "Keyword research error", { shop, error: err.message });
    return Response.json(
      { success: false, error: err.message || "Something went wrong" },
      { status: 500 }
    );
  }
};
