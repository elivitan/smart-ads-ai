// app/routes/app.api.store-analytics.js
// ══════════════════════════════════════════════
// Store Analytics API — pre-campaign intelligence
// Returns store performance data + AI readiness assessment
// ══════════════════════════════════════════════

import { authenticate } from "../shopify.server";
import { getShopifyAnalytics, analyzeCampaignReadiness } from "../store-analytics.server.js";
import { z } from "zod";
import { logger } from "../utils/logger.js";
import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";

export const action = async ({ request }) => {
  let admin, session;
  try {
    ({ admin, session } = await authenticate.admin(request));
  } catch (authErr) {
    logger.error("store-analytics.action", "Auth failed", { error: authErr.message });
    return Response.json({ success: false, error: "Authentication failed" }, { status: 401 });
  }

  const shop = session.shop;

  // Rate limit check
  const rl = rateLimit.storeAnalytics(shop);
  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);

  try {
    const formData = await request.formData();
    const mode = formData.get("mode") || "full"; // "data" = just data, "full" = data + AI analysis

    // Fetch Shopify analytics
    const analytics = await getShopifyAnalytics(admin, shop);

    if (analytics.error) {
      return Response.json(
        { success: false, error: analytics.error },
        { status: 500 }
      );
    }

    let aiAnalysis = null;
    if (mode === "full") {
      aiAnalysis = await analyzeCampaignReadiness(analytics);
    }

    return Response.json({
      success: true,
      analytics,
      readiness: aiAnalysis,
    });
  } catch (err) {
    logger.error("store-analytics.action", "Store analytics error", { shop, error: err.message });
    return Response.json(
      { success: false, error: "Store analytics failed: " + err.message },
      { status: 500 }
    );
  }
};
