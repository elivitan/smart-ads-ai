// app/routes/app.api.ai-engine.js
// ═══════════════════════════════════════════════════════════════
// Smart Ads AI Engine v2 — Powered by AI Brain
// All endpoints collect real data first, then let Claude decide.
// ═══════════════════════════════════════════════════════════════
import { authenticate } from "../shopify.server";
import { getQuickMarketSignal } from "../market-intel.server.js";
import {
  collectCompetitorData,
  analyzeMarket,
  buildCampaignStrategy,
  getDailyAdvice,
  improveAdCopy,
} from "../ai-brain.server.js";
import { checkLicense } from "../license.server.js";
import { z } from "zod";
import { logger } from "../utils/logger.js";
import { rateLimit, rateLimitResponse } from "../utils/rate-limiter.js";

// Helper: get holidays + seasonal from market-intel
async function getSeasonalContext(category) {
  try {
    const mod = await import("../market-intel.server.js");
    const holidays = typeof mod.getUpcomingHolidays === "function"
      ? mod.getUpcomingHolidays(["US"], 30) : [];
    const seasonal = typeof mod.getSeasonalInsight === "function"
      ? mod.getSeasonalInsight(category, new Date().getMonth() + 1) : null;
    return { month: new Date().getMonth() + 1, holidays, seasonal };
  } catch {
    return { month: new Date().getMonth() + 1, holidays: [], seasonal: null };
  }
}

// ─── Main action handler ───
export const action = async ({ request }) => {
  let session;
  try {
    ({ session } = await authenticate.admin(request));
  } catch (authErr) {
    return Response.json({ success: false, error: "Auth failed" }, { status: 401 });
  }
  const shop = session.shop;

  // Rate limit check
  const rl = rateLimit.aiEngine(shop);
  if (!rl.allowed) return rateLimitResponse(rl.retryAfterSeconds);

  const formData = await request.formData();
  const actionType = formData.get("action");

  try {
    // ══════════════════════════════════════════
    // MARKET ANALYSIS — "Should I advertise?"
    // Collects real data → Claude analyzes
    // ══════════════════════════════════════════
    if (actionType === "market-analysis") {
      const category = formData.get("category") || "bedding";
      const productsJson = formData.get("products") || "[]";
      const products = JSON.parse(productsJson);

      // Step 1: Collect real data
      const searchTerms = products.length > 0
        ? products.slice(0, 3).flatMap(p => [p.title, "buy " + p.title]).slice(0, 5)
        : ["buy " + category, "best " + category, category + " online"];

      const competitorData = await collectCompetitorData(searchTerms, shop);

      // Step 2: Get seasonal context
      const seasonalContext = await getSeasonalContext(category);

      // Step 3: Claude analyzes everything
      const analysis = await analyzeMarket({
        competitorData,
        products,
        storeInfo: { domain: shop, category, size: "small" },
        seasonalContext,
      });

      return Response.json({
        success: true,
        analysis,
        _raw: {
          competitorCount: competitorData.competitorCount,
          bigPlayerCount: competitorData.bigPlayerCount,
          bigPlayers: competitorData.bigPlayers,
          trends: competitorData.trends,
          storeRankings: competitorData.storeRankings,
          shoppingPrices: competitorData.shopping?.slice(0, 5),
          competitorAds: competitorData.ads?.slice(0, 5),
          analyzedAt: new Date().toISOString(),
        },
      });
    }

    // ══════════════════════════════════════════
    // QUICK SIGNAL — lightweight, no AI cost
    // ══════════════════════════════════════════
    if (actionType === "quick-signal") {
      const category = formData.get("category") || "bedding";
      const signal = await getQuickMarketSignal({
        regions: ["US"],
        productCategory: category,
      });
      return Response.json({ success: true, ...signal });
    }

    // ══════════════════════════════════════════
    // CAMPAIGN BUILD — "Design my campaign"
    // Real data → Claude builds optimal campaign
    // ══════════════════════════════════════════
    if (actionType === "build-campaign") {
      const products = JSON.parse(formData.get("products") || "[]");
      const goal = formData.get("goal") || "sales";
      const category = formData.get("category") || "bedding";

      // Step 1: Collect competitor data for these products
      let searchTerms = products.slice(0, 3)
        .flatMap(p => [p.title, "buy " + p.title])
        .slice(0, 5);

      if (searchTerms.length === 0) {
        searchTerms = ["buy " + category, "best " + category];
      }

      const competitorData = await collectCompetitorData(searchTerms, shop);

      // Step 2: Claude designs the campaign
      const campaign = await buildCampaignStrategy({
        products,
        competitorData,
        goal,
        storeInfo: { domain: shop, category },
      });

      return Response.json({
        success: true,
        campaign,
        competitorData: {
          count: competitorData.competitorCount,
          bigPlayers: competitorData.bigPlayers,
          trends: competitorData.trends,
          ads: competitorData.ads?.slice(0, 5),
          shopping: competitorData.shopping?.slice(0, 5),
        },
      });
    }

    // ══════════════════════════════════════════
    // DAILY ADVICE — "What should I do today?"
    // ══════════════════════════════════════════
    if (actionType === "daily-advice") {
      const category = formData.get("category") || "bedding";
      const campaignsJson = formData.get("campaigns") || "[]";
      const campaigns = JSON.parse(campaignsJson);

      // Get fresh competitor snapshot
      const searchTerms = ["buy " + category, "best " + category];
      const competitorData = await collectCompetitorData(searchTerms, shop);

      const advice = await getDailyAdvice({
        campaigns,
        competitorData,
        storeInfo: { domain: shop, category },
      });

      return Response.json({ success: true, advice });
    }

    // ══════════════════════════════════════════
    // IMPROVE COPY — "Make this headline better"
    // ══════════════════════════════════════════
    if (actionType === "improve-copy") {
      const license = await checkLicense(shop, "ai-improve");
      if (!license.allowed) {
        return Response.json({ success: false, error: license.reason }, { status: 403 });
      }

      const text = formData.get("text");
      const type = formData.get("type") || "headline";
      const productTitle = formData.get("productTitle") || "";
      const competitorAdsJson = formData.get("competitorAds") || "[]";
      const competitorAds = JSON.parse(competitorAdsJson);

      const improved = await improveAdCopy({
        text,
        type,
        productTitle,
        competitorAds,
      });

      if (!improved) {
        return Response.json({ success: false, error: "AI could not improve this text" }, { status: 500 });
      }

      return Response.json({ success: true, improved });
    }

    // ══════════════════════════════════════════
    // COMPETITOR SNAPSHOT — just the raw data
    // ══════════════════════════════════════════
    if (actionType === "competitor-snapshot") {
      const keywords = JSON.parse(formData.get("keywords") || "[]");
      const searchTerms = keywords.map(k => typeof k === "string" ? k : k.text || "").filter(Boolean);

      if (searchTerms.length === 0) {
        return Response.json({ success: false, error: "No keywords provided" }, { status: 400 });
      }

      const competitorData = await collectCompetitorData(searchTerms, shop);
      return Response.json({ success: true, data: competitorData });
    }

    return Response.json({ success: false, error: "Unknown action type" }, { status: 400 });

  } catch (err) {
    logger.error("ai-engine.action", "AI Engine error", { shop, error: err.message });
    return Response.json({ success: false, error: err.message }, { status: 500 });
  }
};
