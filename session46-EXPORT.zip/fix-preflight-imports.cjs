const fs = require("fs");
let c = fs.readFileSync("preflight.cjs", "utf8");

// Fix 1: Update import count from 20 to 21
c = c.replace(
  /if \(importCount !== \d+\) fail\(`Expected \d+ imports/,
  'if (importCount !== 21) fail(`Expected 21 imports'
);

// Fix 2: Replace required imports list
const oldList = c.match(/const requiredImports = \[[\s\S]*?\];/);
if (!oldList) { console.log("ERROR: could not find requiredImports"); process.exit(1); }

const newList = `const requiredImports = [
  "react",
  "react-router",
  "shopify.server",
  "sync.server",
  "license.server",
  "db.server",
  "styles.index",
  "SmallWidgets.jsx",
  "SmallComponents.jsx",
  "CollectingDataScreen.jsx",
  "CompetitorComponents.jsx",
  "DashboardWidgets.jsx",
  "LandingComponents.jsx",
  "ProductModal.jsx",
  "useGoogleAdsData",
  "SubscriberHome.jsx",
  "GlobalModals.jsx",
  "ScanningScreen.jsx",
  "AutoScreens.jsx",
  "DashboardView.jsx",
  "useAppStore",
];`;

c = c.replace(oldList[0], newList);
fs.writeFileSync("preflight.cjs", c);
console.log("Fixed: updated requiredImports to 21 current imports");
