// deploy-phase9c-batch1.cjs — Phase 9c Batch 1: Deploy 6 React components as .tsx
// Run: node deploy-phase9c-batch1.cjs

const fs = require("fs");
const path = require("path");

const COMPONENTS_DIR = path.join("app", "components");

const FILES_TO_DEPLOY = [
  "GlobalModals.tsx",
  "AutoScreens.tsx",
  "SmallWidgets.tsx",
  "ScanningScreen.tsx",
  "LaunchChoiceDialog.tsx",
  "LandingComponents.tsx",
];

const FILES_TO_REMOVE = [
  "GlobalModals.jsx",
  "AutoScreens.jsx",
  "SmallWidgets.jsx",
  "ScanningScreen.jsx",
  "LaunchChoiceDialog.jsx",
  "LandingComponents.jsx",
];

console.log("╔══════════════════════════════════════════════╗");
console.log("║   Deploy Phase 9c Batch 1 — React → TSX    ║");
console.log("╚══════════════════════════════════════════════╝\n");

// Also need to update global.d.ts with module declarations
const GLOBAL_DTS_ADDITIONS = `
// ═══ Module declarations for JS/JSX files not yet converted to TS ═══
// These allow .tsx files to import from .js/.jsx without TS errors
// Remove these as files get converted to .ts/.tsx

declare module "*/useAppStore.js" {
  const useAppStore: () => Record<string, any>;
  export default useAppStore;
}

declare module "*/SmallComponents.jsx" {
  import React from "react";
  export const Confetti: React.FC<{ active: boolean }>;
  export const TipRotator: React.FC;
}

declare module "*/Modals.jsx" {
  import React from "react";
  export const OnboardModal: React.FC<Record<string, any>>;
  export const BuyCreditsModal: React.FC<Record<string, any>>;
}
`;

// 1. Deploy new .tsx files
let deployed = 0;
for (const file of FILES_TO_DEPLOY) {
  const src = path.join(__dirname, file);
  const dest = path.join(COMPONENTS_DIR, file);
  if (!fs.existsSync(src)) {
    console.error("❌ Source not found: " + src);
    continue;
  }
  fs.copyFileSync(src, dest);
  console.log("✅ Deployed: " + dest);
  deployed++;
}

// 2. Remove old .jsx files
let removed = 0;
for (const file of FILES_TO_REMOVE) {
  const target = path.join(COMPONENTS_DIR, file);
  if (fs.existsSync(target)) {
    fs.unlinkSync(target);
    console.log("🗑️  Removed: " + target);
    removed++;
  } else {
    console.log("ℹ️  Already gone: " + target);
  }
}

// 3. Update global.d.ts with module declarations (if not already there)
const globalDtsPath = path.join("app", "types", "global.d.ts");
if (fs.existsSync(globalDtsPath)) {
  let dts = fs.readFileSync(globalDtsPath, "utf8");
  if (!dts.includes("useAppStore.js")) {
    dts += GLOBAL_DTS_ADDITIONS;
    fs.writeFileSync(globalDtsPath, dts, "utf8");
    console.log("\n✅ Updated global.d.ts with module declarations for unconverted JS files");
  } else {
    console.log("\nℹ️  global.d.ts already has module declarations");
  }
} else {
  console.log("\n⚠️  global.d.ts not found at " + globalDtsPath);
}

// 4. Update imports in files that import from these components
// Since Vite resolves .jsx to .tsx, no import changes needed!
// But preflight might need updating for .tsx resolution

// 5. Verify
console.log("\n═══ Verification ═══");
let ok = true;
for (const file of FILES_TO_DEPLOY) {
  const p = path.join(COMPONENTS_DIR, file);
  if (fs.existsSync(p)) {
    console.log("✅ " + file + " exists");
  } else {
    console.error("❌ " + file + " MISSING");
    ok = false;
  }
}
for (const file of FILES_TO_REMOVE) {
  const p = path.join(COMPONENTS_DIR, file);
  if (fs.existsSync(p)) {
    console.error("❌ " + file + " still exists!");
    ok = false;
  }
}

// Count all TS/TSX files
const utilsDir = path.join("app", "utils");
const tsUtils = fs.readdirSync(utilsDir).filter(f => f.endsWith(".ts"));
const tsxComponents = fs.readdirSync(COMPONENTS_DIR).filter(f => f.endsWith(".tsx"));
const tsComponents = fs.readdirSync(COMPONENTS_DIR).filter(f => f.endsWith(".ts"));
const dtsFiles = fs.readdirSync(path.join("app", "types")).filter(f => f.endsWith(".d.ts"));

console.log("\n📊 TypeScript files:");
console.log("   Utils (.ts): " + tsUtils.length);
console.log("   Components (.tsx): " + tsxComponents.length);
console.log("   Components (.ts): " + tsComponents.length);
console.log("   Type declarations: " + dtsFiles.length);
console.log("   Total: " + (tsUtils.length + tsxComponents.length + tsComponents.length + dtsFiles.length));

if (ok) {
  console.log("\n🎉 Deploy successful! Now run:");
  console.log("   node preflight.cjs");
  console.log("   node test-flows.cjs");
  console.log("   npx playwright test");
} else {
  console.error("\n❌ Deploy had issues — check output above");
}
